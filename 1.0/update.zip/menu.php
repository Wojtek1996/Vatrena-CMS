<?php
	$menu = new Menu();
	$menu->wyswietlanie();
	
	/**
	 * 
	 */
	class Menu {
		public $menu_jezyk = "";
		public function wyswietlanie(){
			if(isset($_POST['menu_lang'])){
				setcookie("menu_lang", $_POST['menu_lang']);
				$_COOKIE['menu_lang'] = $_POST['menu_lang'];
			} else {
				if(!isset($_COOKIE['menu_lang'])){
					setcookie("menu_lang", "PL");
					$_COOKIE['menu_lang'] = "PL";
				}
			}
			
			if(isset($_COOKIE['menu_lang'])){
				switch ($_COOKIE['menu_lang']) {
					case 'PL':
						$this->menu_jezyk = "menu_pl";
						break;
					case 'EN':
						$this->menu_jezyk = "menu_en";
						break;
					case 'DE':
						$this->menu_jezyk = "menu_de";
						break;
					default:
						$this->menu_jezyk = "menu_pl";
						break;
				}
			} else {
				$this->menu_jezyk = "menu_pl";
			}
			
			if(isset($_POST['nazwa'])){
				$this->zapis($_POST['nazwa'], $_POST['typ'], $_POST['artykul'], $_POST['odnosnik'], $_POST['kategoria'], $_POST['rodzic'], $_POST['status']);
			}
			
			if(isset($_POST['del'])){
				$this->usuwanie($_POST['del']);
			}
			
			if(isset($_POST['nowa_nazwa'])){
				$this->nowa_nazwa($_POST['nowa_nazwa'], $_POST['edit_rodzic'], $_POST['id']);
			}
			
			if(isset($_POST['typ_zmiana'])){
				$this->typ_zmiana($_POST['typ_zmiana'], $_POST['id'], $_POST['value']);
			}
			
			if(isset($_POST['change'])){
				$this->change($_POST['change']);
			}
			
			if(isset($_POST['home_new'])){
				$this->domowa($_POST['home_now'], $_POST['home_new']);
			}
			
			$menu_query = Index::$pdo->query("SELECT * FROM `".$this->menu_jezyk."`");
			
			$menu = array();
			while($menu_item = $menu_query->fetch(PDO::FETCH_ASSOC)){
				$menu[$menu_item['Rodzic']][] = $menu_item;
			}
			
			$query = Index::$pdo->query("SELECT `ID`, `Nazwa` FROM `kategorie`");
			$kats_list = $query->fetchAll(PDO::FETCH_ASSOC);
			
			$query = Index::$pdo->query("SELECT `ID`, `Nazwa` FROM `kategorie`");
			
			$kategorie_query = Index::$pdo->query("SELECT * FROM `kategorie`");
			
			$kategorie = array();
			while($kategorie_item = $kategorie_query->fetch(PDO::FETCH_ASSOC)){
				$kategorie[$kategorie_item['Rodzic']][] = $kategorie_item;
			}
			
			$query = Index::$pdo->query("SELECT `ID`, `Nazwa` FROM `artykuly`");
			$art = $query->fetchAll(PDO::FETCH_ASSOC);
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$header = array("Zarządzanie menu", "road");
				$tabela = array("ID", "Nazwa", "Status", "Start", "Typ", "ON", "OFF", "Usuń", "Anuluj", "Zapisz", "Kontener", "Link", "Artykuł", "Kategoria", "Edytuj");
				$dodawanie_text = array("Dodawanie pozycji menu", "Nazwa", "Typ", "Kontener", "Link", "Artykuł", "Kategoria", "Link", "Artykuł", "Kategoria", "Rodzic", "Brak", "Status", "Aktywna", "Nieaktywna", "Dodaj pozycję menu");
				$prompts = array("Edycja", "Wprowadź nazwę oraz wybierz rodzica", "Zapisz", "Anuluj", "Potwierdzenie usunięcia", "Czy na pewno chcesz usunąć element?", "Tak", "Nie");
				$jezyki = array("Polski", "Angielski", "Niemiecki");
			} elseif($_SESSION['jezyk'] == 'EN'){
				$header = array("Menu manegement", "road");
				$tabela = array("ID", "Name", "Status", "Home", "Type", "ON", "OFF", "Delete", "Cancel", "Save", "Contener", "Link", "Article", "Category", "Edit");
				$dodawanie_text = array("Add menu position", "Name", "Type", "Contener", "Link", "Article", "Category", "Link", "Article", "Category", "Parent", "None", "Status", "Active", "Not active", "Add menu position");
				$prompts = array("Edit", "Enter name and select parent", "Save", "Cancel", "Confirm the deletion", "Are you sure you want to delete an item?", "Yes", "No");
				$jezyki = array("Plish", "English", "German");
			} elseif($_SESSION['jezyk'] == 'DE'){
				$header = array("Zarządzanie menu", "road");
				$tabela = array("ID", "Nazwa", "Status", "Start", "Typ", "ON", "OFF", "Usuń", "Anuluj", "Zapisz", "Kontener", "Link", "Artykuł", "Kategoria", "Edytuj");
				$dodawanie_text = array("Dodawanie pozycji menu", "Nazwa", "Typ", "Kontener", "Link", "Artykuł", "Kategoria", "Link", "Artykuł", "Kategoria", "Rodzic", "Brak", "Status", "Aktywna", "Nieaktywna", "Dodaj pozycję menu");
				$prompts = array("Edycja", "Wprowadź nazwę oraz wybierz rodzica", "Zapisz", "Anuluj", "Potwierdzenie usunięcia", "Czy napewno chcesz usunąć element?", "Tak", "Nie");
				$jezyki = array("Polski", "Angielski", "Niemiecki");
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$header = array("Zarządzanie menu", "road");
				$tabela = array("ID", "Nazwa", "Status", "Start", "Typ", "ON", "OFF", "Usuń", "Anuluj", "Zapisz", "Kontener", "Link", "Artykuł", "Kategoria", "Edytuj");
				$dodawanie_text = array("Dodawanie pozycji menu", "Nazwa", "Typ", "Kontener", "Link", "Artykuł", "Kategoria", "Link", "Artykuł", "Kategoria", "Rodzic", "Brak", "Status", "Aktywna", "Nieaktywna", "Dodaj pozycję menu");
				$prompts = array("Edycja", "Wprowadź nazwę oraz wybierz rodzica", "Zapisz", "Anuluj", "Potwierdzenie usunięcia", "Czy napewno chcesz usunąć element?", "Tak", "Nie");
				$jezyki = array("Polski", "Angielski", "Niemiecki");
			}
			
			$menu_defaults = array("header" => $header,
									"tabela" => $tabela,
									"dodawanie_text" => $dodawanie_text,
									"prompt" => $prompts,
									"kats_list" => $kats_list,
									"kategorie" => $kategorie,
									"menu" => $menu,
									"news" => $art,
									"menu_lang" => $_COOKIE['menu_lang'],
									"jezyki" => $jezyki);
			
			Index::$smarty->assign("menu_default", $menu_defaults);
			
			Index::$smarty->assign('location', 'menu.tpl');
		}
		
		public function usuwanie($id){
			$access = $_SESSION['Dostep'];
			$access = $access[2];
			
			if($access == 3 || $access == 5){
				$nazwa = Index::$pdo->query("SELECT `Nazwa` FROM `".$this->menu_jezyk."` WHERE `ID` = ".$id);
				$nazwa = $nazwa->fetch(PDO::FETCH_ASSOC);
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 10, '".$nazwa['Nazwa']."|".$_SESSION['Email']."')");
				
				Index::$pdo->query("DELETE FROM `".$this->menu_jezyk."` WHERE `ID` = ".$id);
				
				$query = Index::$pdo->query("SELECT `ID` FROM `".$this->menu_jezyk."` WHERE `Rodzic` = ".$id);
				
				if($query != '')
					while($row = $query->fetch()){
						self::usuwanie($row['ID']);
					}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function nowa_nazwa($nazwa, $rodzic, $id){
			$access = $_SESSION['Dostep'];
			$access = $access[2];
			
			if($access == 2 || $access == 4 || $access == 5){
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 37, '".$nazwa."|".$_SESSION['Email']."')");
				Index::$pdo->query("UPDATE `".$this->menu_jezyk."` SET `Nazwa` = '".$nazwa."', `Rodzic` = ".$rodzic." WHERE `ID` = ".$id);
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function typ_zmiana($typ, $id, $value){
			$access = $_SESSION['Dostep'];
			$access = $access[2];
			
			if($access == 2 || $access == 4 || $access == 5){
				$nazwa = Index::$pdo->query("SELECT `Nazwa` FROM `".$this->menu_jezyk."` WHERE `ID` = ".$id);
				$nazwa = $nazwa->fetch(PDO::FETCH_ASSOC);
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 31, '".$nazwa['Nazwa']."|".$_SESSION['Email']."')");
				
				switch ($typ){
					case 'Kontener':
						Index::$pdo->query("UPDATE `".$this->menu_jezyk."` SET `Typ` = 0, `Artykul` = 0, `Odnosnik` = '', `Kategoria` = 0  WHERE `ID` = ".$id);
						break;
					case 'Link':
						Index::$pdo->query("UPDATE `".$this->menu_jezyk."` SET `Typ` = 1, `Artykul` = 0, `Odnosnik` = '".$value."', `Kategoria` = 0  WHERE `ID` = ".$id);
						break;
					case 'Artykuł':
						Index::$pdo->query("UPDATE `".$this->menu_jezyk."` SET `Typ` = 2, `Artykul` = ".$value.", `Odnosnik` = '', `Kategoria` = 0 WHERE `ID` = ".$id);
						break;
					case 'Kategoria':
						Index::$pdo->query("UPDATE `".$this->menu_jezyk."` SET `Typ` = 3, `Artykul` = 0, `Odnosnik` = '', `Kategoria` = ".$value." WHERE `ID` = ".$id);
						break;
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function change($array){
			$access = $_SESSION['Dostep'];
			$access = $access[2];
			
			if($access == 2 || $access == 4 || $access == 5){
				$items = explode("|", $array);
				
				$nazwa = Index::$pdo->query("SELECT `Nazwa` FROM `".$this->menu_jezyk."` WHERE `ID` = ".$items[0]);
				$nazwa = $nazwa->fetch(PDO::FETCH_ASSOC);
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 29, '".$nazwa['Nazwa']."|".$_SESSION['Email']."')");
				
				Index::$pdo->query("UPDATE `".$this->menu_jezyk."` SET `Status` = ".$items[1]." WHERE `ID` = ".$items[0]);
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function domowa($old, $new){
			$access = $_SESSION['Dostep'];
			$access = $access[2];
			
			if($access == 2 || $access == 4 || $access == 5){
				$nazwa = Index::$pdo->query("SELECT `Nazwa` FROM `".$this->menu_jezyk."` WHERE `ID` = ".$new);
				$nazwa = $nazwa->fetch(PDO::FETCH_ASSOC);
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 30, '".$nazwa['Nazwa']."|".$_SESSION['Email']."')");
				
				if($old != ''){
					Index::$pdo->query("UPDATE `".$this->menu_jezyk."` SET `Dom` = 0 WHERE `ID` = ".$old."; UPDATE `".$this->menu_jezyk."` SET `Dom` = 1 WHERE `ID` = ".$new.";");
				} else {
					Index::$pdo->query("UPDATE `".$this->menu_jezyk."` SET `Dom` = 1 WHERE `ID` = ".$new);
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function zapis($nazwa, $typ, $artykul, $odnosnik, $kategoria, $rodzic, $status){
			$access = $_SESSION['Dostep'];
			$access = $access[2];
			
			if($access == 1 || $access == 4 || $access == 5){
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 9, '".$nazwa."|".$_SESSION['Email']."')");
				
				if($artykul == ''){
					$artykul = 0;
				}
				
				Index::$pdo->query("INSERT INTO `".$this->menu_jezyk."`(`ID`, `Nazwa`, `Typ`, `Artykul`, `Odnosnik`, `Kategoria`, `Rodzic`, `Status`) VALUES (null, '".$nazwa."', ".$typ.", ".$artykul.", '".$odnosnik."', ".$kategoria.", ".$rodzic.", ".$status.")");
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
	}
?>