<?php
	$update = new Update();
	
	class Update {
		
		function __construct() {
			file_put_contents("../tmp/last_version.info", fopen("https://www.dropbox.com/s/orsz7qy6yl1yokn/latest_version.info?dl=1", 'r'));
			$last_version =  fopen("../tmp/last_version.info", "r");
			$version = fread($last_version, filesize("../tmp/last_version.info"));
			
			$version = explode("|--|", $version);
			
			$version = array("wersja" => $version[0], "link" => $version[1], "query" => $version[2]);
			
			$wersja = Index::$pdo->query("SELECT `Nazwa`, `Wartosc` FROM `ustawienia` WHERE `Nazwa` = 'Wersja'")->fetch(PDO::FETCH_ASSOC);
			
			if(isset($_POST['update'])){
				$url = "http://sourceforge.net/projects/vatrenacms/files/".$version['wersja']."/admin.zip/download";
				$dest = "../tmp/new_version.zip";
				$this->download($url, $dest);
				$this->backup("../admin/", "../backup/backup_".$wersja['Wartosc']."/");
				
				unlink(".htaccess");
				unlink("errors/.htaccess");
				$this->delete("../admin/");
				
				$file_to_open = "../tmp/new_version.zip";
				$target = "../admin/";
				
				$zip = new ZipArchive();
			    $zip->open($file_to_open);
		        $zip->extractTo($target);
		        $zip->close();
				
				Index::$pdo->query("UPDATE `ustawienia` SET `Wartosc` = ".$version['wersja']." WHERE `Nazwa` = 'Wersja'");
			}
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$header = array("Aktualizacje", "cloud-download");
				$teksty = array("Alert" => array("Uwaga!", "Podczas aktualizacji nie należy wyłączać bierzącego okna!"),
								"Aktual" => array("Aktualna wersja: ", $wersja['Wartosc']),
								"Najnowsza" => array("Najnowsza wersja:", $version['wersja']),
								"Up" => array("Aktualizuj"));
			} elseif($_SESSION['jezyk'] == 'EN'){
				$header = array("Aktualizacje", "cloud-download");
				$teksty = array("Alert" => array("Uwaga!", "Podczas aktualizacji nie należy wyłączać bierzącego okna!"));
			} elseif($_SESSION['jezyk'] == 'DE'){
				$header = array("Aktualizacje", "cloud-download");
				$teksty = array("Alert" => array("Uwaga!", "Podczas aktualizacji nie należy wyłączać bierzącego okna!"));
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$header = array("Aktualizacje", "cloud-download");
				$teksty = array("Alert" => array("Uwaga!", "Podczas aktualizacji nie należy wyłączać bierzącego okna!"));
			}
			
			Index::$smarty->assign("header", $header);
			Index::$smarty->assign("teksty", $teksty);
			Index::$smarty->assign("location", "update.tpl");
		}
		
		function delete($dirPath){
			if(is_dir($dirPath)){
		    if (! is_dir($dirPath)) {
		        throw new InvalidArgumentException("$dirPath must be a directory");
		    }
		    if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
		        $dirPath .= '/';
		    }
		    $files = glob($dirPath . '*', GLOB_MARK);
		    foreach ($files as $file) {
		        if (is_dir($file)) {
		            $this->delete($file);
		        } else {
		            unlink($file);
		        }
		    }
	    	rmdir($dirPath);
		}
		}
		
		function download($url, $dest){
			file_put_contents($dest, fopen($url, 'r'));
		}
		
		function backup($src, $dst){
		    if(is_dir($src)){ 
			    $dir = opendir($src); 
			    mkdir($dst); 
			    while(false !== ( $file = readdir($dir)) ) { 
			        if (( $file != '.' ) && ( $file != '..' )) { 
			            if ( is_dir($src . '/' . $file) ) { 
			                $this->backup($src . '/' . $file,$dst . '/' . $file); 
			            } 
			            else { 
			                copy($src . '/' . $file,$dst . '/' . $file); 
			            } 
			        } 
			    } 
			    closedir($dir); 
			}
		}
	}
?>