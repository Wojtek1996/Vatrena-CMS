<?php
	$slider = new Slider();
	
	/**
	 * 
	 */
	class Slider {
		public $slider_lang = "";
		function __construct() {
			if(isset($_POST['slider_lang'])){
				setcookie("slider_lang", $_POST['slider_lang']);
				$_COOKIE['slider_lang'] = $_POST['slider_lang'];
			} else {
				if(!isset($_COOKIE['slider_lang'])){
					setcookie("slider_lang", "PL");
					$_COOKIE['slider_lang'] = "PL";
				}
			}
			
			if(isset($_COOKIE['slider_lang'])){
				switch ($_COOKIE['slider_lang']) {
					case 'PL':
						$this->slider_lang = "PL";
						break;
					case 'EN':
						$this->slider_lang = "EN";
						break;
					case 'DE':
						$this->slider_lang = "DE";
						break;
					default:
						$this->slider_lang = "PL";
						break;
				}
			} else {
				$this->slider_lang = "menu_pl";
			}
			
			if(isset($_POST['slide_del'])){
				$this->usuwanie($_POST['slide_del'], $_POST['slide_name']);
			}
			
			if(isset($_FILES['plik'])){
				$this->uplad($_FILES['plik']);
			}
			
			if(isset($_POST['slider_status'])){
				$this->zapis($_POST['slider_status']);
			}
			
			if(isset($_POST['add_nazwa'])){
				if(!isset($_POST['lang'])){
					$lng = "";
				} else {
					$lng = $_POST['lang'];
				}
				$this->dodawanie($_POST['add_nazwa'], $_POST['add_opis'], $_POST['add_obrazek'], $_POST['add_lang']);
			}
			
			if(isset($_POST['nowy_mini'])){
				$this->mini($_POST['nowy_mini'], $_POST['stary_mini']);
			}
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$header = array("Zarządzanie sliderem", "photo");
				$teksty = array("Zarządzanie sliderem", "Slider włączony", "Tak", "Nie", "Zapisz", "Zarządzanie slajdami", "Prześlij slajd", "Nazwa", "Akcje");
				$prompt = array("Przesylanie" => array("Podaj tytuł", "Podaj nazwę", "Prześlij", "Anuluj", "Wprowadź opis", "Podaj link do obrazka", "Język", "Polski",
								"Angielski", "Niemicki"), "Usuwanie" => array("Usuwanie slajdu", "Czy jesteś pewien że chcesz usunąć slajd?", "Usuń", "Anuluj"),
								"Modal" => array("Zamknij", "Podgląd obrazka"));
				$done = "Zmiany zostały zapisane";
				$slide_added = 'Slajd został dodany';
			} elseif($_SESSION['jezyk'] == 'EN'){
				$header = array("Slider configuration", "photo");
				$teksty = array("Slider configuration", "Slider on", "Yes", "No", "Save", "Slide manegement", "Send slide", "Name", "Actions");
				$prompt = array("Przesylanie" => array("Sending slide", "Enter name", "Send", "Cancel", "Enter description", "Enter image link"),
								"Usuwanie" => array("Removing slide", "Are you sure you want to delete this slide?", "Delete", "Cancel"),
								"Modal" => array("Close", "Image preview"));
				$done = "Settings have been saved";
				$slide_added = 'Slide has been added';
			} elseif($_SESSION['jezyk'] == 'DE'){
				$header = array("Zarządzanie sliderem", "photo");
				$teksty = array("Zarządzanie sliderem", "Slider włączony", "Tak", "Nie", "Zapisz", "Zarządzanie slajdami", "Prześlij plik", "Nazwa", "Akcje");
				$prompt = array("Przesylanie" => array("Podaj tytuł", "Podaj nazwę", "Prześlij", "Anuluj", "Wprowadź opis", "Podaj link do obrazka"),
								"Usuwanie" => array("Usuwanie pliku", "Czy jesteś pewien że chcesz usunąć plik?", "Usuń", "Anuluj"),
								"Modal" => array("Zamknij", "Podgląd obrazka"));
				$done = "Zmiany zostały zapisane";
				$slide_added = 'Slajd został dodany';
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$header = array("Zarządzanie sliderem", "photo");
				$teksty = array("Zarządzanie sliderem", "Slider włączony", "Tak", "Nie", "Zapisz", "Zarządzanie slajdami", "Prześlij plik", "Nazwa", "Akcje");
				$prompt = array("Przesylanie" => array("Podaj tytuł", "Podaj nazwę", "Prześlij", "Anuluj", "Wprowadź opis", "Podaj link do obrazka"),
								"Usuwanie" => array("Usuwanie pliku", "Czy jesteś pewien że chcesz usunąć plik?", "Usuń", "Anuluj"),
								"Modal" => array("Zamknij", "Podgląd obrazka"));
				$done = "Zmiany zostały zapisane";
				$slide_added = 'Slajd został dodany';
			}
			
			
			
			$query = Index::$pdo->query("SELECT `Nazwa`, `Wartosc` FROM ustawienia WHERE `Nazwa` = 'Slider_aktywny'");
			
			$sett_default = array();
			foreach($query as $item){
				$sett_default[$item['Nazwa']] = $item['Wartosc'];
			}
			
			$slide_query = Index::$pdo->query("SELECT `Nazwa`, `Mini`, `Obrazek`, `ID` FROM `slider` WHERE `jezyk` LIKE '%".$this->slider_lang."%'");
			$slide_query = $slide_query->fetchAll(PDO::FETCH_ASSOC);
			
			$sliders = array();
			foreach($slide_query as $item){
				$sliders[$item['Nazwa']] = array("Obrazek" => $item['Obrazek'], "ID" => $item['ID'], "Mini" => $item['Mini']);
			}
			
			$domyslne = array("Slides" => $sliders,
								"Wartosci" => $sett_default,
								"Teksty" => $teksty,
								"Prompt" => $prompt,
								"Header" => $header,
								"done" => $done,
								"slide_added" => $slide_added,
								"slider_lang" => $_COOKIE['slider_lang']
							);
			
			Index::$smarty->assign("domyslne", $domyslne);
			Index::$smarty->assign("location", "slider_sett.tpl");
		}
		
		public function mini($new, $old){
			$access = $_SESSION['Dostep'];
			$access = $access[3];
			
			if($access == 2 || $access == 4 || $access == 5){
				Index::$pdo->query("UPDATE `slider` SET `Mini` = 0 WHERE `ID` = ".$old);
				Index::$pdo->query("UPDATE `slider` SET `Mini` = 1 WHERE `ID` = ".$new);
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function dodawanie($nazwa, $opis, $obrazek, $lang){
			$access = $_SESSION['Dostep'];
			$access = $access[3];	
			
			if($access == 5){
				if($lang != ""){
					$i = 0;
					$jezyk = "";
					$len = count($lang);
					foreach($lang as $item){
						if($i == $len - 1){
							$jezyk .= $item;
						} else {
							$jezyk .= $item."|";
						}
						
						++$i;
					}
				} else {
					$jezyk = "PL";
				}
				
				$statement = Index::$pdo->prepare("INSERT INTO `slider`(`ID`, `Nazwa`, `Obrazek`, `Text`, `jezyk`) VALUES (null, :nazwa, :obrazek, :opis, :jezyk)");
				$statement->bindValue(":nazwa", $nazwa, PDO::PARAM_STR);
				$statement->bindValue(":obrazek", $obrazek, PDO::PARAM_STR);
				$statement->bindValue(":opis", $opis, PDO::PARAM_STR);
				$statement->bindValue(":jezyk", $jezyk, PDO::PARAM_STR);
				$statement->execute();
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function zapis($status){
			$access = $_SESSION['Dostep'];
			$access = $access[3];
			
			if($access == 5){
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 18, '".$_SESSION['Email']."')");
				Index::$pdo->query("UPDATE `ustawienia` SET `Wartosc` = '".$status."' WHERE `Nazwa` = 'Slider_aktywny'");
				header("Location: slider");
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function usuwanie($id, $nazwa){
			$access = $_SESSION['Dostep'];
			$access = $access[4];
			
			if($access == 5){
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 20, '".$nazwa."|".$_SESSION['Email']."')");
				
				Index::$pdo->query("DELETE FROM `slider` WHERE `ID` = ".$id);
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
	}
	
?>