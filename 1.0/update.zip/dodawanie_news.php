<?php
	dodawanie_kompozycji::start();
	
	/**
	 * 
	 */
	class dodawanie_kompozycji {
		
		public static function start(){
			
			if(isset($_POST['tytul'])){
				if(!isset($_POST['lang'])){
					$lng = "";
				} else {
					$lng = $_POST['lang'];
				}
				self::zapisz($_POST['tytul'], $_POST['obrazek'], $_POST['kategoria'], $_POST['tagi'], $_POST['status'], $_POST['opis'], $_POST['data_publikacji'], $lng);
			}
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$header = array("Dodawanie treści", "keyboard-o");
				$teksty = array("Tytuł", "Url", "Zapisz", "Anuluj", "Data publikacji:", date("Y-m-d"), "Status:", "Opublikowany", "Nieopublikowany", "Kategoria:", "Własne ID",
								"Języki", "Polski", "Angielski", "Niemiecki", "Włoski");
				$lng = "pl";
			} elseif($_SESSION['jezyk'] == 'EN'){
				$header = array("Add composition", "keyboard-o");
				$teksty = array("Title", "Url", "Save", "Anuluj", "Publication date:", date("Y-m-d"), "Status:", "Published", "Not published", "Category:", "Custom ID",
								"Languages", "Polish", "English", "German", "Italian");
				$lng = "en";
			} elseif($_SESSION['jezyk'] == 'DE'){
				$header = array("Dodawanie kompozycji", "keyboard-o");
				$teksty = array("Tytuł", "Url", "Zapisz", "Anuluj", "Data publikacji:", date("Y-m-d"), "Status:", "Opublikowany", "Nieopublikowany", "Kategoria:", "Własne ID",
								"Języki", "Polski", "Angielski", "Niemiecki", "Włoski");
				$lng = "pl";
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$header = array("Dodawanie kompozycji", "keyboard-o");
				$teksty = array("Tytuł", "Url", "Zapisz", "Anuluj", "Data publikacji:", date("Y-m-d"), "Status:", "Opublikowany", "Nieopublikowany", "Kategoria:", "Własne ID",
								"Języki", "Polski", "Angielski", "Niemiecki", "Włoski");
				$lng = "it";
			}
			
			$query = Index::$pdo->query("SELECT * FROM `kategorie` ORDER BY `ID`");
			$query = $query->fetchall(PDO::FETCH_ASSOC);
			
			$kategorie = array();
			
			foreach($query as $item){
				$kategorie[$item['ID']] = $item['Nazwa'];
			}
			
			$new_news_default = array("lng" => $lng,
										"teksty" => $teksty,
										"kategorie" => $kategorie,
										"header" => $header);
			
			Index::$smarty->assign("new_news_default", $new_news_default);
			
			Index::$smarty->assign('location', 'dodawanie_news.tpl');
		}
		
		public static function zapisz($nazwa, $url, $kategoria, $tagi, $status, $opis, $data, $lang){
			$access = $_SESSION['Dostep'];
			$access = $access[0];
			if($access == 1 || $access == 4 || $access == 5){
				$nazwa = strip_tags($nazwa);
				$url = strip_tags($url);
				$kategoria = strip_tags($kategoria);
				$tagi = strip_tags($tagi);
				$status = strip_tags($status);
				$data = strip_tags($data);
				$imie = strip_tags($_SESSION['Imie']);
				
				if($lang != ""){
					$i = 0;
					$jezyk = "";
					$len = count($lang);
					foreach($lang as $item){
						if($i == $len - 1){
							$jezyk .= $item;
						} else {
							$jezyk .= $item."|";
						}
						
						++$i;
					}
				} else {
					$jezyk = "PL";
				}
				
				$statement = Index::$pdo->prepare("INSERT INTO `artykuly`(`ID`, `Nazwa`, `Obrazek`, `Opis`, `Kategoria`, `Tagi`, `Status`, `Data_publikacji`, `Autor`, `jezyk`) VALUES
				(null, :nazwa, :url, :opis, :kategoria, :tagi, :status, :data, :autor, :jezyk)");
				$statement->bindValue(":nazwa", $nazwa, PDO::PARAM_STR);
				$statement->bindValue(":url", $url, PDO::PARAM_STR);
				$statement->bindValue(":opis", $opis, PDO::PARAM_STR);
				$statement->bindValue(":kategoria", $kategoria, PDO::PARAM_INT);
				$statement->bindValue(":tagi", $tagi, PDO::PARAM_STR);
				$statement->bindValue(":status", $status, PDO::PARAM_INT);
				$statement->bindValue(":data", $data, PDO::PARAM_STR);
				$statement->bindValue(":autor", $imie, PDO::PARAM_STR);
				$statement->bindValue(":jezyk", $jezyk, PDO::PARAM_STR);
				$statement->execute();
				
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 2, '".$nazwa."|".$imie."')");
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
	}
?>