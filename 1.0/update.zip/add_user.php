<?php
	$add_user = new Add_user();
	
	/**
	 * 
	 */
	class Add_user {
		
		function __construct() {
			if(isset($_POST['add_nazwa'])){
				$this->dodawanie($_POST['add_nazwa'], $_POST['add_nazwisko'], $_POST['add_email'], $_POST['add_haslo'], $_POST['add_kraj'], $_POST['add_miasto'], $_POST['add_dostep'], $_POST['add_status']);
			}
			
			Index::$smarty->assign("location", "add_user.tpl");
			
			$domyslne = array();
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$Header = array("Dodawanie użytkownika", "user");
				$status = array("Aktywne" => 0, "Nieaktywne" => 1);
				$teksty = array("Dodawanie użytkownika", " Podaj Imię", " Podaj Nazwisko", "Podaj email", "Podaj hasło", "Wybierz kraj", "Podaj miasto", "Wybierz grupę dostępu",
								"Status", "Dodaj", "Adres e-mail musi być w formacie e@mail.pl");
				$informacja = array("Informacja", "Po zatwierdzeniu na podany email zostanie wysłana wiadomość z danymi do logowania.");
				$error = array("Niewypelnione" => array("Błąd", "Musisz wypełnić wszystkie pola!", "Zamknij"),
								"Istnieje" => array("Błąd", "Musisz wprowadzić adres Email na który nie jest zarejestrowane inne konto.", "Zamknij"));
			} elseif($_SESSION['jezyk'] == 'EN'){
				$Header = array("Add user", "user");
				$status = array("Active" => 0, "Not active" => 1);
				$teksty = array("Adding User", " Enter first name", "Enter last name", "Enter email", "Enter password", "Select country", "Enter city name",
								"Enter access group", "Status", "Add", "Email address must be like e@mail.pl");
				$informacja = array("Information", "After approval of the given email will be sent with the data logging");
				$error = array("Niewypelnione" => array("Error", "You must fill in all fields!", "Close"),
								"Istnieje" => array("Error", "You must enter an email address which is not registered to a different account", "Close"));
			} elseif($_SESSION['jezyk'] == 'DE'){
				$Header = array("Dodawanie użytkownika", "user");
				$status = array("Aktywne" => 0, "Nieaktywne" => 1);
				$teksty = array("Dodawanie użytkownika", " Podaj Imię", " Podaj Nazwisko", "Podaj email", "Podaj hasło", "Wybierz kraj", "Podaj miasto", "Wybierz grupę dostępu",
								"Status", "Dodaj", "Adres e-mail musi być w formacie e@mail.pl");
				$informacja = array("Informacja", "Po zatwierdzeniu na podany email zostanie wysłana wiadomość z danymi do logowania.");
				$error = array("Niewypelnione" => array("Błąd", "Musisz wypełnić wszystkie pola!", "Zamknij"),
								"Istnieje" => array("Błąd", "Musisz wprowadzić adres Email na który nie jest zarejestrowane inne konto.", "Zamknij"));
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$Header = array("Dodawanie użytkownika", "user");
				$status = array("Aktywne" => 0, "Nieaktywne" => 1);
				$teksty = array("Dodawanie użytkownika", " Podaj Imię", " Podaj Nazwisko", "Podaj email", "Podaj hasło", "Wybierz kraj", "Podaj miasto", "Wybierz grupę dostępu",
								"Status", "Dodaj", "Adres e-mail musi być w formacie e@mail.pl");
				$informacja = array("Informacja", "Po zatwierdzeniu na podany email zostanie wysłana wiadomość z danymi do logowania.");
				$error = array("Niewypelnione" => array("Błąd", "Musisz wypełnić wszystkie pola!", "Zamknij"),
								"Istnieje" => array("Błąd", "Musisz wprowadzić adres Email na który nie jest zarejestrowane inne konto.", "Zamknij"));
			}
			
			$query = Index::$pdo->query("SELECT `ID`, `Nazwa` FROM `grupy_dostepu`");
			$query = $query->fetchAll(PDO::FETCH_ASSOC);
			
			foreach($query as $item){
				$dostep[$item['Nazwa']] = $item['ID'];
			}
			
			$kraje = array('ANDORRA', 'UNITED ARAB EMIRATES', 'AFGHANISTAN', 'ANTIGUA AND BARBUDA', 'ANGUILLA', 'ALBANIA', 'ARMENIA', 'NETHERLANDS ANTILLES','ANGOLA',
						'ANTARCTICA', 'ARGENTINA', 'AMERICAN SAMOA', 'AUSTRIA', 'AUSTRALIA', 'ARUBA', 'AZERBAIJAN', 'BOSNIA AND HERZEGOVINA', 'BARBADOS', 'BANGLADESH',
						'BELGIUM', 'BURKINA FASO', 'BULGARIA', 'BAHRAIN', 'BURUNDI', 'BENIN', 'SAINT BARTHELEMY', 'BERMUDA', 'BRUNEI DARUSSALAM', 'BOLIVIA', 'BRAZIL',
						'BAHAMAS', 'BHUTAN', 'BOTSWANA', 'BELARUS', 'BELIZE', 'CANADA', 'COCOS', 'CONGO', 'CENTRAL AFRICAN REPUBLIC', 'CONGO', 'SWITZERLAND', 'COTE D IVOIRE',
						'COOK ISLANDS', 'CHILE', 'CAMEROON', 'CHINA', 'COLOMBIA', 'COSTA RICA', 'CUBA', 'CAPE VERDE', 'CHRISTMAS ISLAND', 'CYPRUS', 'CZECH REPUBLIC',
						'GERMANY', 'DJIBOUTI', 'DENMARK', 'DOMINICA', 'DOMINICAN REPUBLIC', 'ALGERIA', 'ECUADOR', 'ESTONIA', 'EGYPT', 'ERITREA', 'SPAIN', 'ETHIOPIA',
						'FINLAND', 'FIJI', 'FALKLAND', 'MICRONESIA', 'FAROE ISLANDS', 'FRANCE', 'GABON', 'UNITED KINGDOM', 'GRENADA', 'GEORGIA', 'GHANA', 'GIBRALTAR',
						'GREENLAND', 'GAMBIA', 'GUINEA', 'EQUATORIAL GUINEA', 'GREECE', 'GUATEMALA', 'GUAM', 'GUINEA-BISSAU', 'GUYANA', 'HONG KONG', 'HONDURAS', 'CROATIA',
						'HAITI', 'HUNGARY', 'INDONESIA', 'IRELAND', 'ISRAEL', 'ISLE OF MAN', 'INDIA', 'IRAQ', 'IRAN', 'ICELAND', 'ITALY', 'JAMAICA', 'JORDAN', 'JAPAN',
						'KENYA', 'KYRGYZSTAN', 'CAMBODIA', 'KIRIBATI', 'COMOROS', 'SAINT KITTS AND NEVIS', 'KOREA DEMOCRATIC PEOPLES REPUBLIC OF', 'KOREA REPUBLIC OF',
						'KUWAIT', 'CAYMAN ISLANDS', 'KAZAKSTAN', 'LAO PEOPLES DEMOCRATIC REPUBLIC', 'LEBANON', 'SAINT LUCIA', 'LIECHTENSTEIN', 'SRI LANKA', 'LIBERIA',
						'LESOTHO', 'LITHUANIA', 'LUXEMBOURG', 'LATVIA', 'LIBYAN ARAB JAMAHIRIYA', 'MOROCCO', 'MONACO', 'MOLDOVA', 'MONTENEGRO', 'SAINT MARTIN', 'MADAGASCAR',
						'MARSHALL ISLAND', 'MACEDONIA', 'MALI', 'MYANMAR', 'MONGOLIA', 'MACAU', 'NORTHERN MARIANA ISLANDS', 'MAURITANIA', 'MONTSERRAT', 'MALTA', 'MAURITIUS',
						'MALDIVES', 'MALAWI', 'MEXICO', 'MALAYSIA', 'MOZAMBIQUE', 'NAMIBIA', 'NEW CALEDONIA', 'NIGER', 'NIGERIA', 'NICARAGUA', 'NETHERLANDS', 'NORWAY',
						'NEPAL', 'NAURU', 'NIUE', 'NEW ZEALAND', 'OMAN', 'PANAMA', 'PERU', 'FRENCH POLYNESIA', 'PAPUA NEW GUINEA', 'PHILIPPINES', 'PAKISTAN', 'POLSKA', 
						'SAINT PIERRE AND MIQUELON', 'PITCAIRN', 'PUERTO RICO', 'PORTUGAL', 'PALAU', 'PARAGUAY', 'QATAR', 'ROMANIA', 'SERBIA', 'RUSSIAN FEDERATION',
						'RWANDA', 'SAUDI ARABIA', 'SOLOMON ISLANDS', 'SEYCHELLES', 'SUDAN', 'SWEDEN', 'SINGAPORE', 'SAINT HELENA', 'SLOVENIA', 'SLOVAKIA', 'SIERRA LEONE',
						'SAN MARINO', 'SENEGAL', 'SOMALIA', 'SURINAME', 'SAO TOME AND PRINCIPE', 'EL SALVADOR', 'SYRIAN ARAB REPUBLIC', 'SWAZILAND', 'TURKS AND CAICOS ISLANDS',
						'CHAD', 'TOGO', 'THAILAND', 'TAJIKISTAN', 'TOKELAU', 'TIMOR-LESTE', 'TURKMENISTAN', 'TUNISIA', 'TONGA', 'TURKEY', 'TRINIDAD AND TOBAGO', 'TUVALU',
						'TAIWAN', 'TANZANIA', 'UKRAINE', 'UGANDA', 'UNITED STATES', 'URUGUAY', 'UZBEKISTAN', 'HOLY SEE', 'SAINT VINCENT AND THE GRENADINES', 'VENEZUELA',
						'VIRGIN ISLANDS, BRITISH', 'VIRGIN ISLANDS, U.S.', 'VIETNAM', 'VANUATU', 'WALLIS AND FUTUNA', 'SAMOA', 'KOSOVO', 'YEMEN', 'MAYOTTE', 'SOUTH AFRICA',
						'ZAMBIA', 'ZIMBABWE');
			
			$domyslne = array("Header" => $Header,
								"Kraje" => $kraje,
								"Status" => $status,
								"Dostep" => $dostep,
								"Teksty" => $teksty,
								"Informacja" => $informacja,
								"Error" => $error);
			
			Index::$smarty->assign("domyslne", $domyslne);
		}
		
		function dodawanie($imie, $nazwisko, $email, $haslo, $kraj, $miasto, $dostep, $status){
			$access = $_SESSION['Dostep'];
			$access = $access[5];
			
			if($access == 1 || $access == 4 || $access == 5){
				if($imie != '' && $nazwisko != '' && $email != '' && $haslo != '' && $kraj != '' && $miasto != '' && $dostep != '' && $status != ''){
					$em = Index::$pdo->query("SELECT COUNT(*) FROM `uzytkownicy` WHERE `Email` = '".$email."'");
					$em = $em->fetch(PDO::FETCH_ASSOC);
					
					if($em['COUNT(*)'] == 0){
						$haslo_dlugosc = strlen($haslo) / 2; #Wyznaczenie połowy wyrazu
						$haslo_1z2 = ceil($haslo_dlugosc); #Wyznaczenie 1 połowy wyrazu(zaokrąglenie)
						$haslo_2z2 = strlen($haslo) - $haslo_1z2; #Wyznaczenie 2 połowy wyrazu
						
						$haslo_a = substr($haslo, 0, $haslo_1z2); #Przypisanie 1 połowy wyrazu
						$haslo_b = substr($haslo, $haslo_1z2, $haslo_2z2); #Przypisanie 2 połowy wyrazu
						
						$haslo_a = sha1($haslo_a); #Hashowanie 1 części hasła
						$haslo_b = sha1($haslo_b); #Hashowanie 2 części hasła
						
						$url = $_SERVER['HTTP_HOST'];
						
						if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
							$email_text = array("header" => array("Strona główna", "Panel administracyjny", "Napędzany przez Vatrena CMS"),
												"Naglowki" => array("Rejestracja nowego użytkownika", "Dane użytkownika"),
												"Tresc" => array("Na twój adres Email zostało zarejestrowane konto użytkownika", "w Vatrena CMS na stronie"),
												"Dane" => array("Login", "Hasło", "Adres logowania", "Imię", "Nazwisko", "Kraj", "Miasto"),
												"Stopka" => "Jeśli nie wiesz dlaczego otrzymałeś tą wiadomość zignoruj ją lub skontaktuj się z administratorem",
												"Message_header" => "Vatrena CMS - Rejestracja nowego użytkownika",
												"Kontakt" => "Email kontaktowy do administratora");
						} elseif($_SESSION['jezyk'] == 'EN'){
							$email_text = array("header" => array("Homepage", "Admin panel", "Powered by Vatrena CMS"),
												"Naglowki" => array("New user registration", "User data"),
												"Tresc" => array("On your email address has been registered account of user", "in Vatrena CMS on page"),
												"Dane" => array("Login", "Password", "Login address", "First name", "Last name", "Countrny", "City"),
												"Stopka" => "If you do not know why you received this message please ignore it, or contact the administrator",
												"Message_header" => "Vatrena CMS - News user register",
												"Kontakt" => "Contact e-mail to head admin");
						} elseif($_SESSION['jezyk'] == 'DE'){
							$email_text = array("header" => array("Strona główna", "Panel administracyjny", "Napędzany przez Vatrena CMS"),
												"Naglowki" => array("Rejestracja nowego użytkownika", "Dane użytkownika"),
												"Tresc" => array("Na twój adres Email zostało zarejetrowane konto użytkownika", "w Vatrena CMS na stronie"),
												"Dane" => array("Login", "Hasło", "Adres logowania", "Imię", "Nazwisko", "Kraj", "Miasto"),
												"Stopka" => "Jeśli nie wiesz dlaczego otrzymałeś tą wiadomość zignoruj ją lub skontaktuj się z administratorem",
												"Message_header" => "Vatrena CMS - Rejestracja nowego użytkownika",
												"Kontakt" => "Email kontaktowy do administratora");
						} elseif($_SESSION['jezyk'] == 'ITA'){
							$email_text = array("header" => array("Strona główna", "Panel administracyjny", "Napędzany przez Vatrena CMS"),
												"Naglowki" => array("Rejestracja nowego użytkownika", "Dane użytkownika"),
												"Tresc" => array("Na twój adres Email zostało zarejetrowane konto użytkownika", "w Vatrena CMS na stronie"),
												"Dane" => array("Login", "Hasło", "Adres logowania", "Imię", "Nazwisko", "Kraj", "Miasto"),
												"Stopka" => "Jeśli nie wiesz dlaczego otrzymałeś tą wiadomość zignoruj ją lub skontaktuj się z administratorem",
												"Message_header" => "Vatrena CMS - Rejestracja nowego użytkownika",
												"Kontakt" => "Email kontaktowy do administratora");
						}
						
						$wiadomosc = '<div style="width: 100%; background-color: #4C4E4E; padding-top: 50px; padding-bottom: 50px;">
<table style="font-family: HelveticaNeue,sans-serif; border-collapse: collapse" align="center">
	<tbody style="background: #E2E2E2">
		<tr>
			<td style="background: #2780CB; width: 600px; padding: 5px 0px;;">
				<p style="color: #fff; font-size: 12px; padding: 10px; width: 580px;"><a href="http://'.$url.'/" style="color: #fff; text-decoration: none; font-weight: bold;">'.$email_text['header'][0].'</a> | <a href="http://'.$url.'/admin" style="color: #fff; text-decoration: none; font-weight: bold;">'.$email_text['header'][1].'</a></p>
			</td>
		</tr>
		<tr>
			<td style="width: 600px; text-align: center; padding-top: 10px;">
				<p style="font-size: 36px; margin: 0; color: #000;">'.$url.'</p>
				<p style="font-size: 15px; color: #000; ">'.$email_text['header'][2].'</p>
			</td>
		</tr>
		<tr>
			<td style="width: 600px;">&nbsp;</td>
		</tr>
		<tr style="width: 600px;">
			<td style="padding: 10px; width: 550px; background: #fff; display: block; margin: auto;">
				<p style="color: #526F92; font-weight: bold; font-size: 18px;">'.$email_text['Naglowki'][0].'</p>
				<p>'.$email_text['Tresc'][0].' '.$imie.' '.$nazwisko.' '.$email_text['Tresc'][1].' <a href="http://'.$url.'/">link</a></p>
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr style="width: 600px;">
			<td style="padding: 10px; width: 550px; background: #fff; display: block; margin: auto;">
				<p style="color: #526F92; font-weight: bold; font-size: 18px;">'.$email_text['Naglowki'][1].'</p>
				<ul style="list-style: none; padding-left: 5px;">
					<li style="margin-bottom: 10px">'.$email_text['Dane'][0].': '.$email.'</li>
					<li style="margin-bottom: 10px">'.$email_text['Dane'][1].': '.$haslo.'</li>
					<li style="margin-bottom: 10px">'.$email_text['Dane'][2].': <a href="http://'.$url.'/admin/">Link</a></li>
					<li style="margin-bottom: 10px">'.$email_text['Dane'][3].': '.$imie.'</li>
					<li style="margin-bottom: 10px">'.$email_text['Dane'][4].': '.$nazwisko.'</li>
					<li style="margin-bottom: 10px">'.$email_text['Dane'][5].': '.$kraj.'</li>
					<li>'.$email_text['Dane'][6].': '.$miasto.'</li>
				</ul>
			</td>
		</tr>
		<tr style="width: 600px;">
			<td>&nbsp;</td>
		</tr>
		<tr style="width: 600px;">
			<td style="padding: 20px; background: #2780CB; text-align: center;">
				<p style="color: #fff; font-size: 14px;">'.$email_text['Kontakt'].' <a href="mailto:'.$_SESSION['Email'].'" style="color: #afefff;">'.$_SESSION['Email'].'</a></p>
				<p style="color: #fff; font-size: 14px;">'.$email_text['Stopka'].'</p>
			</td>
		</tr>
	</tbody>
</table>
</div>';
						$headers  = 'From: '.$_SESSION['Email'].'' . "\r\n" .
						            'Reply-To: '.$_SESSION['Email']. "\r\n" .
						            'MIME-Version: 1.0' . "\r\n" .
						            'Content-type: text/html; charset=utf-8' . "\r\n" .
						            'X-Mailer: PHP/' . phpversion();
						
						$title = $temat= "=?UTF-8?B?".base64_encode($email_text['Message_header'])."?=";
						
						$imie = strip_tags($imie);
						$nazwisko = strip_tags($nazwisko);
						$kraj = strip_tags($kraj);
						$miasto = strip_tags($miasto);
						
						Index::$pdo->query("INSERT INTO `uzytkownicy`(`ID`, `Haslo_a`, `Haslo_b`, `Email`, `Imie`, `Nazwisko`, `Kraj`, `Miasto`, `Status`, `Dostep`, `Ostatnie_logowanie`) VALUES (null, '".$haslo_a."', '".$haslo_b."', '".$email."', '".$imie."', '".$nazwisko."', '".$kraj."', '".$miasto."', ".$status.", ".$dostep.", null)");
						
						Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 21, '".$email."|".$_SESSION['Email']."')");
						
						mail($email, $title, $wiadomosc, $headers);
					} else {
						header("Uzywane: 1");
					}
				} else {
					header("Pusto: 1");
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
	}
?>