<?php
	Kategorie::start();
	
	
	class Kategorie {
		private static $strona_obecna;
		private static $liczba_na_strone = 10;
		
		public static function start(){
			if(isset($_POST['nowa_nazwa'])){
				self::nowa_nazwa($_POST['id'], $_POST['nowa_nazwa'], $_POST['rodzic']);
			}
			
			if(isset($_POST['usuwanie'])){
				self::usuwanie($_POST['usuwanie']);
			}
			
			if(isset($_POST['status'])){
				$string = explode("|", $_POST['status']);
				self::status($string[0], $string[1]);
			}
			
			if(isset($_POST['nazwa'])){
				self::nowy($_POST['status_add'], $_POST['nazwa'], $_POST['rodzic']);
			}
			
			$wszystkie = Index::$pdo->query("SELECT COUNT(*) FROM `kategorie`");
			$wszystkie = $wszystkie -> fetch();
			$wszystkie = $wszystkie['COUNT(*)'];
			
			self::paginacja($wszystkie);
			
			$query = Index::$pdo->query("SELECT * FROM `kategorie` ORDER BY `ID` LIMIT ".self::$strona_obecna.", ".self::$liczba_na_strone);
			
			$kategorie = $query->fetchAll(PDO::FETCH_ASSOC);
			
			$ilosc = array();
			
			foreach ($kategorie as $item) {
				$q = Index::$pdo->query("SELECT COUNT(*) FROM `artykuly` WHERE `Kategoria` = ".$item['ID']);
				$q = $q->fetch();
				$ilosc[$item['ID']] = $q['COUNT(*)'];
			}
			
			$kat = array();
			$kat_query = Index::$pdo->query("SELECT * FROM `kategorie`");
			
			while($kat_item = $kat_query->fetch(PDO::FETCH_ASSOC)){
				$kat[$kat_item['Rodzic']][] = $kat_item;
			}
			
			Index::$smarty->assign("kats", $kat);
			
			Index::$smarty->assign("ilosc_news", $ilosc);
			Index::$smarty->assign("kategorie", $kategorie);
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$kategorie_text = array("ID", "Nazwa", "Status", "Posty");
				$dodawanie_text = array("Dodawanie kategorii", "Nazwa:", "Nazwa jest tym czym kategoria przedstawia się na twojej witrynie.",
										"Rodzic:", "Brak", "Rodzic jest kategorią nadrzędną dla nowo utworzonej kategori.",
										"Status:", "Opublikowany", "Niepublikowane", "Status wskazuje na to czy kategoria jest aktywna lub nie.", "Dodaj kategorię");
				$header = array("Zarządzanie kategoriami", "clipboard");
				$prompts = array("Edycja", "Wprowadź nazwę i wybierz rodzica", "Zapisz", "Anuluj", "Potwierdzenie usunięcia", "Czy napewno chcesz usunąć element?", "Tak", "Nie", "Brak");
				$btns = array("Usuń", "Edytuj");
			} elseif($_SESSION['jezyk'] == 'EN'){
				$kategorie_text = array("ID", "Name", "Status", "Posts");
				$dodawanie_text = array("Add category", "Name:", "The name is what shows the category on your site",
										"Parent:", "None", "The parent is the parent category for the newly created category",
										"Status:", "Published", "Not published", "Status indicates whether the category is active or not", "Add category");
				$header = array("Category manegement", "clipboard");
				$prompts = array("Edit", "Enter name and select parent", "Save", "Cancel", "Confirm the deletion", "Are you sure you want to delete this item?", "Yes", "No", "None");
				$btns = array("Delete", "Edit");
				} elseif($_SESSION['jezyk'] == 'DE'){
				$kategorie_text = array("ID", "Nazwa", "Status", "Posty");
				$dodawanie_text = array("Dodawanie kategorii", "Nazwa:", "Nazwa jest tym czym kategoria przedstawia się na twojej witrynie.",
										"Rodzic:", "Brak", "Rodzic jest kategorią nadrzędną dla nowo utwożonej kategori.",
										"Status:", "Opublikowany", "Niepublikowane", "Status wskazuje na to czy kategoria jest aktywna lub nie.", "Dodaj kategorię");
				$header = array("Zarządzanie kategoriami", "clipboard");
				$prompts = array("Zmiana nazwy", "Wprowadź nazwę", "Zapisz", "Anuluj", "Potwierdzenie usunięcia", "Czy napewno chcesz usunąć element?", "Tak", "Nie", "Brak");
				$btns = array("Usuń", "Zmień nazwę");
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$kategorie_text = array("ID", "Nazwa", "Status", "Posty");
				$dodawanie_text = array("Dodawanie kategorii", "Nazwa:", "Nazwa jest tym czym kategoria przedstawia się na twojej witrynie.",
										"Rodzic:", "Brak", "Rodzic jest kategorią nadrzędną dla nowo utwożonej kategori.",
										"Status:", "Opublikowany", "Niepublikowane", "Status wskazuje na to czy kategoria jest aktywna lub nie.", "Dodaj kategorię");
				$header = array("Zarządzanie kategoriami", "clipboard");
				$prompts = array("Zmiana nazwy", "Wprowadź nazwę", "Zapisz", "Anuluj", "Potwierdzenie usunięcia", "Czy napewno chcesz usunąć element?", "Tak", "Nie", "Brak");
				$btns = array("Usuń", "Zmień nazwę");
			}
			
			$kategorie_domyslne = array("przyciski" => $btns,
										"modal" => $prompts,
										"kategorie_text" => $kategorie_text,
										"dodawanie" => $dodawanie_text,
										"header" => $header);
			
			Index::$smarty->assign("kategorie_default", $kategorie_domyslne);
			
			Index::$smarty->assign('location', 'kategorie.tpl');
		}
		
		/*====================================================================================================================================================================*/
		
		public static function nowa_nazwa($id, $new, $rodzic){
			$access = $_SESSION['Dostep'];
			$access = $access[1];
			
			if($access == 2 || $access == 4 || $access == 5){
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 36, '".$new."|".$_SESSION['Email']."')");
				
				Index::$pdo->query("UPDATE `kategorie` SET `Nazwa` = '".$new."', `Rodzic` = ".$rodzic." WHERE `ID` = ".$id);
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		/*====================================================================================================================================================================*/
		
		public static function status($id, $string){
			$access = $_SESSION['Dostep'];
			$access = $access[1];
			
			if($access == 2 || $access == 4 || $access == 5){
				$nazwa = Index::$pdo->query("SELECT `Nazwa` FROM `kategorie` WHERE `ID` = ".$id);
				$nazwa = $nazwa->fetch(PDO::FETCH_ASSOC);
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 7, '".$nazwa['Nazwa']."|".$_SESSION['Email']."')");
				
				Index::$pdo->query("UPDATE `kategorie` SET `Status` = ".$string." WHERE `ID` = ".$id);
				
				Index::$pdo->query("UPDATE `artykuly` SET `Status`= ".$string." WHERE `Kategoria` = ".$id);
				
				$query = Index::$pdo->query("SELECT `ID` FROM `kategorie` WHERE `Rodzic` = ".$id);
				
				if($query != '')
					while($row = $query->fetch()){
						self::status($row['ID'], $string);
					}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		/*====================================================================================================================================================================*/
		
		public static function paginacja($liczba){
			if(!isset($_POST['strona'])){
				self::$strona_obecna = 0;
			} else {
				self::$strona_obecna = $_POST['strona'];
			}
			
			$liczba_stron = ceil($liczba/self::$liczba_na_strone);
			
			Index::$smarty->assign("ostatnia", $liczba_stron - 1);
			Index::$smarty->assign("obecna", self::$strona_obecna);
			Index::$smarty->assign("paginacja", $liczba_stron);
		}
		
		/*====================================================================================================================================================================*/
		
		public static function usuwanie($id){
			$access = $_SESSION['Dostep'];
			$access = $access[1];
			
			if($access == 3 || $access == 5){
				$nazwa = Index::$pdo->query("SELECT `Nazwa` FROM `kategorie` WHERE `ID` = ".$id);
				$nazwa = $nazwa->fetch(PDO::FETCH_ASSOC);
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 8, '".$nazwa['Nazwa']."|".$_SESSION['Email']."')");
				
				Index::$pdo->query("UPDATE `artykuly` SET `Kategoria`= 1 WHERE `Kategoria` = ".$id);
				
				Index::$pdo->query("DELETE FROM `kategorie` WHERE `ID` = ".$id);
				
				$query = Index::$pdo->query("SELECT `ID` FROM `kategorie` WHERE `Rodzic` = ".$id);
				
				Index::$pdo->query("UPDATE `menu` SET `Typ` = 0, `Kategoria`= 0 WHERE `Kategoria` = ".$id);
				
				if($query != '')
					while($row = $query->fetch()){
						self::usuwanie($row['ID']);
					}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		/*====================================================================================================================================================================*/
		
		public static function nowy($status, $nazwa, $rodzic){
			$access = $_SESSION['Dostep'];
			$access = $access[1];
			
			if($access == 1 || $access == 4 || $access == 5){
				Index::$pdo->query("INSERT INTO `kategorie`(`ID`, `Status`, `Nazwa`, `Rodzic`) VALUES (null, ".$status.", '".$nazwa."', ".$rodzic.")");
				
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 6, '".$_POST['nazwa']."|".$_SESSION['Email']."')");
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
	}
?>