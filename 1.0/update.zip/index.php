<?php
	Index::laczenie();
	
	/**
	 * 
	 */
	class Index {
		public static $smarty;
		public static $pdo;
		public static $kodowanie;
		public static $strefa;
		public static $time;
		
		public static function laczenie(){
			ob_start();
			include '../libs/Smarty.class.php';
			
			self::$smarty = new Smarty();
			
			self::$smarty->template_dir = 'templates/';
			self::$smarty->compile_dir = '../compile/';
			
			$host = "localhost";
			$user = "root";
			$haslo = "";
			$database = "szkola";
			
			/*$host = "mysql.1freehosting.com";
			$user = "u531035526_zse";
			$haslo = "Wojtek12";
			$database = "u531035526_zse";*/
			
			self::$pdo = new PDO('mysql:host='.$host.';dbname='.$database, $user, $haslo);
			self::$pdo->query("SET NAMES utf8; SET CHARACTER_SET utf8_unicode_ci");
			$query = self::$pdo->query("SELECT `Wartosc` FROM `ustawienia` WHERE `Nazwa` = 'Kodowanie_znakow'");
			$query = $query->fetch();
			self::$kodowanie = $query['Wartosc'];
			self::$smarty->assign('Kodowanie', self::$kodowanie);
			$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$actual_link = explode("admin", $actual_link);
			$actual_link = $actual_link[0];
			self::$smarty->assign("url", $actual_link);
			
			$query = self::$pdo->query("SELECT `Wartosc` FROM `ustawienia` WHERE `Nazwa` = 'Strefa_czasowa'");
			$query = $query->fetch();
			self::$strefa = $query['Wartosc'];
			
			self::$pdo -> query ('SET NAMES '.self::$kodowanie);
			self::$pdo -> query ('SET CHARACTER_SET '.self::$kodowanie);
			
			$gzip_query = self::$pdo->query("SELECT `Wartosc`, `Nazwa` FROM `ustawienia` WHERE `Nazwa` = 'gzip' OR `Nazwa` = 'gzip_poziom'");
			
			$gzip = array();
			foreach($gzip_query as $item){
				$gzip[$item['Nazwa']] = $item['Wartosc'];
			}
			
			self::$time = new DateTime(null, new DateTimeZone(Index::$strefa));
			self::$time = self::$time -> format("Y-m-d H:i:s");
			
			if($gzip['gzip'] == 1){
				if (!ini_get ('zlib.output_compression')) {
					if (substr_count ($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) {
						ini_set ('zlib.output_compression_level', $gzip['gzip_poziom']);
						ob_start ('ob_gzhandler');
					}
				}
			}
			session_start();
			
			include 'login.php';
			self::srodek();
			
			ob_end_flush();
			
			if(isset($_POST['lang_change'])){
				switch ($_POST['lang_change']) {
					case 'PL':
						$_SESSION['jezyk'] = 'PL';
						break;
					case 'EN':
						$_SESSION['jezyk'] = 'EN';
						break;
					case 'ITA':
						$_SESSION['jezyk'] = 'ITA';
						break;
					case 'DE':
						$_SESSION['jezyk'] = 'DE';
						break;
					default:
						$_SESSION['jezyk'] = 'PL';
						break;
				}
			}
		}
		
		private static $blad;
		private static $lokacja;
		private static $lang;
		
		private static function srodek(){
			if(!isset($_SESSION['Zalogowany']) || $_SESSION == 1){
				self::$blad = 0;
				
				if(isset($_GET['error'])){
					self::$blad = $_GET['error'];
				}
				
				$query = self::$pdo->query("SELECT `Wartosc` FROM `ustawienia` WHERE `Nazwa` = 'Jezyk_wyswietlania_panel'");
				$query = $query->fetch();
				
				if($query['Wartosc'] == "PL"){
					$login = array("Teksty" => array("Wprowadź swój Email oraz hasło", "Zaloguj"),
									"Blad" => array("Błąd", "Nie znaleziono użytkownika o takiej kombinacji loginu i hasła", "Zamknij"),
									"Pusto" => array("Błąd", "Musisz wypełnić wszystkie pola!", "Zamknij"),
									"Placeholder" => array("Email", "Hasło"));
					$_SESSION['jezyk'] = 'PL';
				} elseif($query['Wartosc'] == "EN"){
					$login = array("Teksty" => array("Enter your Email and password", "Login"),
									"Blad" => array("No user was found with that combination of username and password", "Close"),
									"Pusto" => array("You must fill in all fields!", "Close"),
									"Placeholder" => array("Email", "Password"));
					$_SESSION['jezyk'] = 'EN';
				} elseif($query['Wartosc'] == "DE"){
					$login = array("Teksty" => array("Wprowadź swój Email oraz hasło", "Zaloguj"),
									"Blad" => array("Nie znaleziono użytkownika o takiej kombinacji loginu i hasła", "Zamknij"),
									"Pusto" => array("Musisz wypełnić wszystkie pola!", "Zamknij"),
									"Placeholder" => array("Email", "Hasło"));
					$_SESSION['jezyk'] = 'ITA';
				} elseif($query['Wartosc'] == "ITA"){
					$login = array("Teksty" => array("Wprowadź swój Email oraz hasło", "Zaloguj"),
									"Blad" => array("Nie znaleziono użytkownika o takiej kombinacji loginu i hasła", "Zamknij"),
									"Pusto" => array("Musisz wypełnić wszystkie pola!", "Zamknij"),
									"Placeholder" => array("Email", "Hasło"));
					$_SESSION['jezyk'] = 'ITA';
				}
				
				self::$smarty->assign("login_teksty", $login);
				self::$lokacja = 'login.tpl';
				self::$smarty->assign("location", self::$lokacja);
			} else {
				self::$smarty->assign('user', $_SESSION['Email']);
				
				$user = Index::$pdo->query("SELECT `Ostatnie_logowanie` FROM `uzytkownicy` WHERE `Email` = '".$_SESSION['Email']."'");
				$user = $user->fetch(PDO::FETCH_ASSOC);
				
				if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
					$title = "Panel administracyjny";
					$menu_top = array("Strona główna" => "general", "Zarządzanie plikami" => "ftp", 'Konfiguracja profilu' => 'profil');
					$menu_left = array("Statystyki|fa-tachometer" => 'general',
										"Zarządzanie zawartością|fa-quote-right" => array("Dodawanie treści" => "add_news", "Przegląd treści" => "news", "Zarządzanie kategoriami" => "category"),
										"Zarządzanie menu|fa-road" => "menu",
										"Komponenty|fa-tasks" => array("Lista ikon" => "icon", "Lista przycisków" => "button"),
										"Strony błędów|fa-exclamation-triangle" => array("Error 403" => "errors/403/403.php\" target=\"_blank", "Error 404" => "errors/404/404.php\" target=\"_blank",
																						"Error 405" => "errors/405/405.php\" target=\"_blank", "Error 500" => "errors/500/500.php\" target=\"_blank",
																						"Error 503" => "errors/503/503.php\" target=\"_blank", 
																						"Strona wyłączona" => "errors/offline/offline.php\" target=\"_blank",
																						"Strona w przebudowie" => "errors/under construction/under construction.php\" target=\"_blank"),
										"Zarządzanie plikami|fa-cloud" => "ftp",
										"Konfiguracja|fa-sliders" => array("System" => "system", "Strona" => 'page', "Slider" => "slider"),
										"Zarządzanie użytkownikami|fa-users" => array("Dodawanie użytkownika" => "add_user", "Przegląd użytkowników" => "users",
																						"Zarządzanie dostępem" => "access"),
										"Logi|fa-book" => "logs",
										"Aktualizacje|fa-cloud-download" => "update");
					$top_icons = array("Wyczyść cache", "Poradnik", "Odśwież stronę", 'Przełącz menu', "Wyloguj", "Zmień język", "Przejdź do serwisu", "Done" => "Cache został usunięty");
					$access = $_SESSION['Grupa'];
					$user_menu = array($_SESSION['Imie'], $access, 'Ostatnie logowanie', $user['Ostatnie_logowanie']);
					$pomoc = array("Pomoc", "W budowie");
					$lang_chng = array("Zmiana języka", "Wybierz swój język", array("Polski" => array("PL", 0, 0), "English" => array("EN", 60, 0), "Deutschi" => array("DE", 30, 0), "Italiano" => array("ITA", 90, 0)));
					$access_denied = array("Dostęp wzbroniony", "Nie możesz wykonać tej czynności ponieważ nie masz wystarczającego poziomu dostępu", "Zamknij");
				} elseif($_SESSION['jezyk'] == 'EN'){
					$title = "Admin panel";
					$menu_top = array("Homepage" => "general", "File management" => "ftp", 'Profil configuration' => 'profil');
					$menu_left = array("Stats|fa-tachometer" => 'general',
										"Content management|fa-quote-right" => array("Add compositions" => "add_news", "Compositions list" => "news", "Category manegement" => "category"),
										"Menu management|fa-road" => "menu",
										"Components|fa-tasks" => array("Icon list" => "icon", "Buttons list" => "button"),
										"Errors pages|fa-exclamation-triangle" => array("Error 403" => "errors/403/403.php\" target=\"_blank", "Error 404" => "errors/404/404.php\" target=\"_blank",
																"Error 405" => "errors/405/405.php\" target=\"_blank", "Error 500" => "errors/500/500.php\" target=\"_blank",
																"Error 503" => "errors/503/503.php\" target=\"_blank",
																"Website offline" => "errors/offline/offline.php\" target=\"_blank",
																"Page reconstruction" => "errors/under construction/under construction.php\" target=\"_blank"),
										"File management|fa-cloud" => "ftp",
										"Configuration|fa-sliders" => array("System" => "system", "Page" => 'page', "Slider" => "slider"),
										"User management|fa-users" => array("Add user" => "add_user", "Users list" => "users",
																						"Access management" => "access"),
										"Logs|fa-book" => "logs",
										"Updates|fa-cloud-download" => "update");
					$top_icons = array("Clear cache", "Tutorial", "Refresh", 'Switch menu', "Logout", "Change language", "Go to webpage", "Done" => "Cache has been deleted");
					$access = $_SESSION['Grupa'];
					$user_menu = array($_SESSION['Imie'], $access, 'Last login', $user['Ostatnie_logowanie']);
					$pomoc = array("Tutorial", "Under construction");
					$lang_chng = array("Change language", "Select your language", array("Polski" => array("PL", 0, 0), "English" => array("EN", 60, 0), "Deutschi" => array("DE", 30, 0), "Italiano" => array("ITA", 90, 0)));
					$access_denied = array("Access denied", "You can not perform this operation because it does not have a sufficient level of access", "Close");
				} elseif($_SESSION['jezyk'] == 'DE'){
					$title = "Panel administracyjny";
					$menu_top = array("Strona główna" => "general", "Zarządzanie plikami" => "ftp", 'Konfiguracja profilu' => 'profil');
					$menu_left = array("Statystyki|fa-tachometer" => 'general',
										"Zarządzanie zawartością|fa-quote-right" => array("Dodawanie kompozycji" => "add_news", "Przegląd kompozycji" => "news", "Zarządzanie kategoriami" => "category"),
										"Zarządzanie menu|fa-road" => "menu",
										"Komponenty|fa-tasks" => array("Lista ikon" => "icon", "Lista przycisków" => "button"),
										"Strony błędów|fa-exclamation-triangle" => array("Error 403" => "errors/403/403.php\" target=\"_blank", "Error 404" => "errors/404/404.php\" target=\"_blank",
																						"Error 405" => "errors/405/405.php\" target=\"_blank", "Error 500" => "errors/500/500.php\" target=\"_blank",
																						"Error 503" => "errors/503/503.php\" target=\"_blank", 
																						"Strona wyłączona" => "errors/offline/offline.php\" target=\"_blank",
																						"Strona w przebudowie" => "errors/under construction/under construction.php\" target=\"_blank"),
										"Zarządzanie plikami|fa-cloud" => "ftp",
										"Konfiguracja|fa-sliders" => array("System" => "system", "Strona" => 'page', "Slider" => "slider"),
										"Zarządzanie użytkownikami|fa-users" => array("Dodawanie użytkownika" => "add_user", "Przegląd użytkowników" => "users",
																						"Zarządzanie dostępem" => "access"),
										"Logi|fa-book" => "logs",
										"Aktualizacje|fa-cloud-download" => "update");
					$top_icons = array("Wyczyść cache", "Poradnik", "Odśwież stronę", 'Przełącz menu', "Wyloguj", "Zmień język", "Przejdź do serwisu", "Done" => "Cache został usunięty");
					$access = $_SESSION['Grupa'];
					$user_menu = array($_SESSION['Imie'], $access, 'Ostatnie logowanie', $user['Ostatnie_logowanie']);
					$pomoc = array("Pomoc", "W budowie");
					$lang_chng = array("Zmiana języka", "Wybierz swój język", array("Polski" => array("PL", 0, 0), "English" => array("EN", 60, 0), "Deutschi" => array("DE", 30, 0), "Italiano" => array("ITA", 90, 0)));
					$access_denied = array("Dostęp wzbroniony", "Nie możesz wykonać tej czynności ponieważ nie masz wystarczającego poziomu dostępu", "Zamknij");
				} elseif($_SESSION['jezyk'] == 'ITA'){
					$title = "Panel administracyjny";
					$menu_top = array("Strona główna" => "general", "Zarządzanie plikami" => "ftp", 'Konfiguracja profilu' => 'profil');
					$menu_left = array("Statystyki|fa-tachometer" => 'general',
										"Zarządzanie zawartością|fa-quote-right" => array("Dodawanie kompozycji" => "add_news", "Przegląd kompozycji" => "news", "Zarządzanie kategoriami" => "category"),
										"Zarządzanie menu|fa-road" => "menu",
										"Komponenty|fa-tasks" => array("Lista ikon" => "icon", "Lista przycisków" => "button"),
										"Strony błędów|fa-exclamation-triangle" => array("Error 403" => "errors/403/403.php\" target=\"_blank", "Error 404" => "errors/404/404.php\" target=\"_blank",
																						"Error 405" => "errors/405/405.php\" target=\"_blank", "Error 500" => "errors/500/500.php\" target=\"_blank",
																						"Error 503" => "errors/503/503.php\" target=\"_blank", 
																						"Strona wyłączona" => "errors/offline/offline.php\" target=\"_blank",
																						"Strona w przebudowie" => "errors/under construction/under construction.php\" target=\"_blank"),
										"Zarządzanie plikami|fa-cloud" => "ftp",
										"Konfiguracja|fa-sliders" => array("System" => "system", "Strona" => 'page', "Slider" => "slider"),
										"Zarządzanie użytkownikami|fa-users" => array("Dodawanie użytkownika" => "add_user", "Przegląd użytkowników" => "users",
																						"Zarządzanie dostępem" => "access"),
										"Logi|fa-book" => "logs",
										"Aktualizacje|fa-cloud-download" => "update");
					$top_icons = array("Wyczyść cache", "Poradnik", "Odśwież stronę", 'Przełącz menu', "Wyloguj", "Zmień język", "Przejdź do serwisu", "Done" => "Cache został usunięty");
					$access = $_SESSION['Grupa'];
					$user_menu = array($_SESSION['Imie'], $access, 'Ostatnie logowanie', $user['Ostatnie_logowanie']);
					$pomoc = array("Pomoc", "W budowie");
					$lang_chng = array("Zmiana języka", "Wybierz swój język", array("Polski" => array("PL", 0, 0), "English" => array("EN", 60, 0), "Deutschi" => array("DE", 30, 0), "Italiano" => array("ITA", 90, 0)));
					$access_denied = array("Dostęp wzbroniony", "Nie możesz wykonać tej czynności ponieważ nie masz wystarczającego poziomu dostępu", "Zamknij");
				}
				
				$index_domyslne = array("title" => $title,
										"menu_top" => $menu_top,
										"menu_left" => $menu_left,
										"top_icons" => $top_icons,
										"dostep" => $access,
										"user_menu" => $user_menu,
										"pomoc" => $pomoc,
										"lang_chng" => $lang_chng,
										"access_denied" => $access_denied);

				self::$smarty->assign("index_domyslne", $index_domyslne);
				
				if(isset($_POST['cache_clear'])){
					$sciezka = "../cache/";
					
					if($sciezka != ""){
						$scan = scandir($sciezka);
						foreach ($scan as $key) {
							if($key != '.' && $key != '..'){
								if(filetype($sciezka.'/'.$key) == 'dir'){
									self::usuwanie($sciezka.'/'.$key);
								} else {
									unlink($sciezka.'//'.$key);
								}
							}
						}
						reset($scan);
						if($sciezka != "../cache/"){
							rmdir($sciezka);
						}
					}
					
					header("Cache: 1");
				}
				
				if(isset($_GET['Location'])){
					switch ($_GET['Location']) {
						case 'general':
							include 'general.php';
							break;
						case 'add_news':
							include 'dodawanie_news.php';
							break;
						case 'news':
							if(isset($_GET['edit_id'])){
								include 'news_edit.php';
							} else {
								include 'news.php';
							}
							break;
						case 'category':
							include 'kategorie.php';
							break;
						case 'menu':
							include 'menu.php';
							break;
						case 'icon':
							include 'ikony.php';
							break;
						case 'button':
							include 'button.php';
							break;
						case 'ftp':
							include 'ftp.php';
							break;
						case 'system':
							include 'system_sett.php';
							break;
						case 'page':
							include 'strona_sett.php';
							break;
						case 'slider':
							include 'slider_sett.php';
							break;
						case 'add_user':
							include 'add_user.php';
							break;
						case 'users':
							include 'uzytkownicy.php';
							break;
						case 'access':
							include 'dostep.php';
							break;
						case 'logs':
							include 'logi.php';
							break;
						case 'profil':
							include 'profil.php';
							break;
						case 'update':
							include 'update.php';
							break;
						default:
							include 'errors/404/404.php';
							break;
					}
				} else {
					include 'general.php';
				}
			}
			self::assign();
		}
		
		private static function assign(){
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$title = "Panel administracyjny";
			} elseif($_SESSION['jezyk'] == 'EN'){
				$title = "Admin panem";
			} elseif($_SESSION['jezyk'] == 'DE'){
				
			} elseif($_SESSION['jezyk'] == 'ITA'){
				
			}
			
			self::$smarty->assign('title', $title);
			
			self::$smarty->display("index.tpl", 'panel');
			
			if(isset($_GET['Location']) && $_GET['Location'] == 'logout'){
				self::logout();
				header("Location: ./");
			}
		}
		
		private static function logout(){
			Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 33, '".$_SESSION['Email']."')");
			unset($_SESSION['Zalogowany']);
			unset($_SESSION['Login']);
		}
	}
?>