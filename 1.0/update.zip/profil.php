<?php
	$profil = new Profil();
	
	
	/**
	 * 
	 */
	class Profil {
		
		function __construct() {
			if(isset($_POST['profil_submit'])){
				$this->zapisz($_POST['imie'], $_POST['nazwisko'], $_POST['haslo'], $_POST['kraj'], $_POST['miasto']);
			}
			
			Index::$smarty->assign("location", "profil.tpl");
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$header = array("Zarządzanie profilem", "user");
				$teksty = array("Imie", "Nazwisko", "Email", "Nowe hasło", "Kraj", "Miasto", "zapisz");
				$info = array("Informacja", "Zostaw pole `Nowe hasło` puste aby nie zmieniać hasła");
			} elseif($_SESSION['jezyk'] == 'EN'){
				$header = array("Profil management", "user");
				$teksty = array("First name", "Last name", "Email", "New password", "Country", "City", "Save");
				$info = array("Information", "Leave empty field `New password` to not change password");
			} elseif($_SESSION['jezyk'] == 'EN'){
				$header = array("Zarządzanie profilem", "user");
				$teksty = array("Imie", "Nazwisko", "Email", "Nowe hasło", "Kraj", "Miasto", "zapisz");
				$info = array("Informacja", "Zostaw pole `Nowe hasło` puste aby nie zmieniać hasła");
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$header = array("Zarządzanie profilem", "user");
				$teksty = array("Imie", "Nazwisko", "Email", "Nowe hasło", "Kraj", "Miasto", "zapisz");
				$info = array("Informacja", "Zostaw pole `Nowe hasło` puste aby nie zmieniać hasła");
			}
			
			$domyslne_query = Index::$pdo->query("SELECT `Imie`, `Nazwisko`, `Email`, `Kraj`, `Miasto` FROM `uzytkownicy` WHERE `Email` = '".$_SESSION['Email']."'");
			$domyslne_query = $domyslne_query->fetch(PDO::FETCH_ASSOC);
			
			$kraje = array('ANDORRA', 'UNITED ARAB EMIRATES', 'AFGHANISTAN', 'ANTIGUA AND BARBUDA', 'ANGUILLA', 'ALBANIA', 'ARMENIA', 'NETHERLANDS ANTILLES','ANGOLA',
						'ANTARCTICA', 'ARGENTINA', 'AMERICAN SAMOA', 'AUSTRIA', 'AUSTRALIA', 'ARUBA', 'AZERBAIJAN', 'BOSNIA AND HERZEGOVINA', 'BARBADOS', 'BANGLADESH',
						'BELGIUM', 'BURKINA FASO', 'BULGARIA', 'BAHRAIN', 'BURUNDI', 'BENIN', 'SAINT BARTHELEMY', 'BERMUDA', 'BRUNEI DARUSSALAM', 'BOLIVIA', 'BRAZIL',
						'BAHAMAS', 'BHUTAN', 'BOTSWANA', 'BELARUS', 'BELIZE', 'CANADA', 'COCOS', 'CONGO', 'CENTRAL AFRICAN REPUBLIC', 'CONGO', 'SWITZERLAND', 'COTE D IVOIRE',
						'COOK ISLANDS', 'CHILE', 'CAMEROON', 'CHINA', 'COLOMBIA', 'COSTA RICA', 'CUBA', 'CAPE VERDE', 'CHRISTMAS ISLAND', 'CYPRUS', 'CZECH REPUBLIC',
						'GERMANY', 'DJIBOUTI', 'DENMARK', 'DOMINICA', 'DOMINICAN REPUBLIC', 'ALGERIA', 'ECUADOR', 'ESTONIA', 'EGYPT', 'ERITREA', 'SPAIN', 'ETHIOPIA',
						'FINLAND', 'FIJI', 'FALKLAND', 'MICRONESIA', 'FAROE ISLANDS', 'FRANCE', 'GABON', 'UNITED KINGDOM', 'GRENADA', 'GEORGIA', 'GHANA', 'GIBRALTAR',
						'GREENLAND', 'GAMBIA', 'GUINEA', 'EQUATORIAL GUINEA', 'GREECE', 'GUATEMALA', 'GUAM', 'GUINEA-BISSAU', 'GUYANA', 'HONG KONG', 'HONDURAS', 'CROATIA',
						'HAITI', 'HUNGARY', 'INDONESIA', 'IRELAND', 'ISRAEL', 'ISLE OF MAN', 'INDIA', 'IRAQ', 'IRAN', 'ICELAND', 'ITALY', 'JAMAICA', 'JORDAN', 'JAPAN',
						'KENYA', 'KYRGYZSTAN', 'CAMBODIA', 'KIRIBATI', 'COMOROS', 'SAINT KITTS AND NEVIS', 'KOREA DEMOCRATIC PEOPLES REPUBLIC OF', 'KOREA REPUBLIC OF',
						'KUWAIT', 'CAYMAN ISLANDS', 'KAZAKSTAN', 'LAO PEOPLES DEMOCRATIC REPUBLIC', 'LEBANON', 'SAINT LUCIA', 'LIECHTENSTEIN', 'SRI LANKA', 'LIBERIA',
						'LESOTHO', 'LITHUANIA', 'LUXEMBOURG', 'LATVIA', 'LIBYAN ARAB JAMAHIRIYA', 'MOROCCO', 'MONACO', 'MOLDOVA', 'MONTENEGRO', 'SAINT MARTIN', 'MADAGASCAR',
						'MARSHALL ISLAND', 'MACEDONIA', 'MALI', 'MYANMAR', 'MONGOLIA', 'MACAU', 'NORTHERN MARIANA ISLANDS', 'MAURITANIA', 'MONTSERRAT', 'MALTA', 'MAURITIUS',
						'MALDIVES', 'MALAWI', 'MEXICO', 'MALAYSIA', 'MOZAMBIQUE', 'NAMIBIA', 'NEW CALEDONIA', 'NIGER', 'NIGERIA', 'NICARAGUA', 'NETHERLANDS', 'NORWAY',
						'NEPAL', 'NAURU', 'NIUE', 'NEW ZEALAND', 'OMAN', 'PANAMA', 'PERU', 'FRENCH POLYNESIA', 'PAPUA NEW GUINEA', 'PHILIPPINES', 'PAKISTAN', 'POLSKA', 
						'SAINT PIERRE AND MIQUELON', 'PITCAIRN', 'PUERTO RICO', 'PORTUGAL', 'PALAU', 'PARAGUAY', 'QATAR', 'ROMANIA', 'SERBIA', 'RUSSIAN FEDERATION',
						'RWANDA', 'SAUDI ARABIA', 'SOLOMON ISLANDS', 'SEYCHELLES', 'SUDAN', 'SWEDEN', 'SINGAPORE', 'SAINT HELENA', 'SLOVENIA', 'SLOVAKIA', 'SIERRA LEONE',
						'SAN MARINO', 'SENEGAL', 'SOMALIA', 'SURINAME', 'SAO TOME AND PRINCIPE', 'EL SALVADOR', 'SYRIAN ARAB REPUBLIC', 'SWAZILAND', 'TURKS AND CAICOS ISLANDS',
						'CHAD', 'TOGO', 'THAILAND', 'TAJIKISTAN', 'TOKELAU', 'TIMOR-LESTE', 'TURKMENISTAN', 'TUNISIA', 'TONGA', 'TURKEY', 'TRINIDAD AND TOBAGO', 'TUVALU',
						'TAIWAN', 'TANZANIA', 'UKRAINE', 'UGANDA', 'UNITED STATES', 'URUGUAY', 'UZBEKISTAN', 'HOLY SEE', 'SAINT VINCENT AND THE GRENADINES', 'VENEZUELA',
						'VIRGIN ISLANDS, BRITISH', 'VIRGIN ISLANDS, U.S.', 'VIETNAM', 'VANUATU', 'WALLIS AND FUTUNA', 'SAMOA', 'KOSOVO', 'YEMEN', 'MAYOTTE', 'SOUTH AFRICA',
						'ZAMBIA', 'ZIMBABWE');
			
			$profil_text = array("header" => $header,
								"teksty" => $teksty,
								"kraje" => $kraje,
								"domyslne" => $domyslne_query,
								"info" => $info);
			
			Index::$smarty->assign("profil_text", $profil_text);
		}
		
		public function zapisz($imie, $nazwisko, $haslo, $kraj, $miasto){
			if($haslo != ""){
				$haslo_dlugosc = strlen($haslo) / 2; #Wyznaczenie połowy wyrazu
				$haslo_1z2 = ceil($haslo_dlugosc); #Wyznaczenie 1 połowy wyrazu(zaokrąglenie)
				$haslo_2z2 = strlen($haslo) - $haslo_1z2; #Wyznaczenie 2 połowy wyrazu
				
				$haslo_a = substr($haslo, 0, $haslo_1z2); #Przypisanie 1 połowy wyrazu
				$haslo_b = substr($haslo, $haslo_1z2, $haslo_2z2); #Przypisanie 2 połowy wyrazu
				
				$haslo_a = sha1($haslo_a); #Hashowanie 1 części hasła
				$haslo_b = sha1($haslo_b); #Hashowanie 2 części hasła
				
				$imie = strip_tags($imie);
				$nazwisko = strip_tags($nazwisko);
				$kraj = strip_tags($kraj);
				$miasto = strip_tags($miasto);
				
				Index::$pdo->query("UPDATE `uzytkownicy` SET `Haslo_a` = '".$haslo_a."',`Haslo_b` = '".$haslo_b."',`Imie` = '".$imie."', `Nazwisko` = '".$nazwisko."',`Kraj` = '".$kraj."', `Miasto` = '".$miasto."' WHERE `Email` = '".$_SESSION['Email']."'");
				
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 40, '".$_SESSION['Email']."')");
			} else {
				$imie = strip_tags($imie);
				$nazwisko = strip_tags($nazwisko);
				$kraj = strip_tags($kraj);
				$miasto = strip_tags($miasto);
				
				Index::$pdo->query("UPDATE `uzytkownicy` SET `Imie` = '".$imie."', `Nazwisko` = '".$nazwisko."', `Kraj` = '".$kraj."', `Miasto` = '".$miasto."' WHERE `Email` = '".$_SESSION['Email']."'");
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 40, '".$_SESSION['Email']."')");
			}
			
			header("Location: profil");
		}
	}
?>