<?php
	$ikon = new Ikonki();
	
	/**
	 * 
	 */
	class Ikonki {
		
		function __construct() {
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$header = array("Lista ikonek", "star-half-o");
			} elseif($_SESSION['jezyk'] == 'EN'){
				$header = array("Icons list", "star-half-o");
			} elseif($_SESSION['jezyk'] == 'DE'){
				$header = array("Lista ikonek", "star-half-o");
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$header = array("Lista ikonek", "star-half-o");
			}
			
			$ikony_bootstrap = array("glyphicon glyphicon-asterisk", "glyphicon glyphicon-music", "glyphicon glyphicon-th", "glyphicon glyphicon-cog", "glyphicon glyphicon-upload",
									"glyphicon glyphicon-headphones", "glyphicon glyphicon-book", "glyphicon glyphicon-text-width", "glyphicon glyphicon-facetime-video", "glyphicon glyphicon-move",
									"glyphicon glyphicon-fast-forward", "glyphicon glyphicon-ok-sign", "glyphicon glyphicon-arrow-right", "glyphicon glyphicon-leaf", "glyphicon glyphicon-comment",
									"glyphicon glyphicon-resize-vertical", "glyphicon glyphicon-hand-right", "glyphicon glyphicon-globe", "glyphicon glyphicon-heart-empty", "glyphicon glyphicon-sort-by-alphabet-alt",
									"glyphicon glyphicon-collapse-up", "glyphicon glyphicon-saved", "glyphicon glyphicon-floppy-open", "glyphicon glyphicon-tower", "glyphicon glyphicon-sound-6-1",
									"glyphicon glyphicon-sound-7-1", "glyphicon glyphicon-stats", "glyphicon glyphicon-credit-card", "glyphicon glyphicon-import", "glyphicon glyphicon-log-in",
									"glyphicon glyphicon-sort-by-order", "glyphicon glyphicon-link", "glyphicon glyphicon-wrench", "glyphicon glyphicon-hand-left", "glyphicon glyphicon-resize-horizontal",
									"glyphicon glyphicon-magnet", "glyphicon glyphicon-fire", "glyphicon glyphicon-arrow-up", "glyphicon glyphicon-question-sign", "glyphicon glyphicon-step-forward",
									"glyphicon glyphicon-step-backward", "glyphicon glyphicon-picture", "glyphicon glyphicon-align-left", "glyphicon glyphicon-bookmark", "glyphicon glyphicon-volume-off",
									"glyphicon glyphicon-inbox", "glyphicon glyphicon-trash", "glyphicon glyphicon-th-list", "glyphicon glyphicon-search", "glyphicon glyphicon-plus",
									"glyphicon glyphicon-euro", "glyphicon glyphicon-heart", "glyphicon glyphicon-ok", "glyphicon glyphicon-home", "glyphicon glyphicon-play-circle",
									"glyphicon glyphicon-volume-down", "glyphicon glyphicon-print", "glyphicon glyphicon-align-center", "glyphicon glyphicon-map-marker", "glyphicon glyphicon-fast-backward",
									"glyphicon glyphicon-eject", "glyphicon glyphicon-info-sign", "glyphicon glyphicon-arrow-down", "glyphicon glyphicon-eye-open", "glyphicon glyphicon-chevron-up",
									"glyphicon glyphicon-hdd", "glyphicon glyphicon-hand-up", "glyphicon glyphicon-tasks", "glyphicon glyphicon-phone", "glyphicon glyphicon-sort-by-order-alt",
									"glyphicon glyphicon-flash", "glyphicon glyphicon-export", "glyphicon glyphicon-transfer", "glyphicon glyphicon-sd-video", "glyphicon glyphicon-copyright-mark",
									"glyphicon glyphicon-registration-mark", "glyphicon glyphicon-hd-video", "glyphicon glyphicon-cutlery", "glyphicon glyphicon-send", "glyphicon glyphicon-log-out",
									"glyphicon glyphicon-sort-by-attributes", "glyphicon glyphicon-pushpin", "glyphicon glyphicon-filter", "glyphicon glyphicon-hand-down", "glyphicon glyphicon-bullhorn",
									"glyphicon glyphicon-chevron-down", "glyphicon glyphicon-eye-close", "glyphicon glyphicon-share-alt", "glyphicon glyphicon-screenshot", "glyphicon glyphicon-chevron-left".
									"glyphicon glyphicon-backward", "glyphicon glyphicon-adjust", "glyphicon glyphicon-align-right", "glyphicon glyphicon-camera", "glyphicon glyphicon-volume-up",
									"glyphicon glyphicon-repeat", "glyphicon glyphicon-file", "glyphicon glyphicon-remove", "glyphicon glyphicon-star", "glyphicon glyphicon-minus", "glyphicon glyphicon-cloud",
									"glyphicon glyphicon-star-empty", "glyphicon glyphicon-zoom-in", "glyphicon glyphicon-time", "glyphicon glyphicon-refresh", "glyphicon glyphicon-qrcode", "glyphicon glyphicon-font",
									"glyphicon glyphicon-align-justify", "glyphicon glyphicon-tint", "glyphicon glyphicon-play", "glyphicon glyphicon-chevron-right", "glyphicon glyphicon-remove-circle", 
									"glyphicon glyphicon-resize-full", "glyphicon glyphicon-warning-sign", "glyphicon glyphicon-retweet", "glyphicon glyphicon-bell", "glyphicon glyphicon-circle-arrow-right",
									"glyphicon glyphicon-briefcase", "glyphicon glyphicon-usd", "glyphicon glyphicon-sort-by-attributes-alt", "glyphicon glyphicon-new-window", "glyphicon glyphicon-floppy-disk",
									"glyphicon glyphicon-header", "glyphicon glyphicon-subtitles", "glyphicon glyphicon-cloud-download", "glyphicon glyphicon-cloud-upload", "glyphicon glyphicon-sound-stereo",
									"glyphicon glyphicon-compressed", "glyphicon glyphicon-floppy-saved", "glyphicon glyphicon-record", "glyphicon glyphicon-unchecked", "glyphicon glyphicon-gbp",
									"glyphicon glyphicon-fullscreen", "glyphicon glyphicon-circle-arrow-left", "glyphicon glyphicon-certificate", "glyphicon glyphicon-shopping-cart",
									"glyphicon glyphicon-plane", "glyphicon glyphicon-resize-small", "glyphicon glyphicon-ok-circle", "glyphicon glyphicon-plus-sign", "glyphicon glyphicon-pause",
									"glyphicon glyphicon-edit", "glyphicon glyphicon-list", "glyphicon glyphicon-bold", "glyphicon glyphicon-barcode", "glyphicon glyphicon-list-alt", "glyphicon glyphicon-road",
									"glyphicon glyphicon-zoom-out", "glyphicon glyphicon-user", "glyphicon glyphicon-envelope", "glyphicon glyphicon-pencil", "glyphicon glyphicon-film",
									"glyphicon glyphicon-off", "glyphicon glyphicon-download-alt", "glyphicon glyphicon-lock", "glyphicon glyphicon-tag", "glyphicon glyphicon-italic", "glyphicon glyphicon-indent-left",
									"glyphicon glyphicon-share", "glyphicon glyphicon-stop", "glyphicon glyphicon-minus-sign", "glyphicon glyphicon-ban-circle", "glyphicon glyphicon-exclamation-sign",
									"glyphicon glyphicon-calendar", "glyphicon glyphicon-folder-close", "glyphicon glyphicon-thumbs-up", "glyphicon glyphicon-circle-arrow-up", "glyphicon glyphicon-dashboard",
									"glyphicon glyphicon-sort", "glyphicon glyphicon-expand", "glyphicon glyphicon-save", "glyphicon glyphicon-floppy-remove", "glyphicon glyphicon-earphone", "glyphicon glyphicon-sound-dolby",
									"glyphicon glyphicon-tree-conifer", "glyphicon glyphicon-tree-deciduous", "glyphicon glyphicon-sound-5-1", "glyphicon glyphicon-phone-alt", "glyphicon glyphicon-floppy-save",
									"glyphicon glyphicon-open", "glyphicon glyphicon-collapse-down", "glyphicon glyphicon-sort-by-alphabet", "glyphicon glyphicon-paperclip", "glyphicon glyphicon-circle-arrow-down",
									"glyphicon glyphicon-thumbs-down", "glyphicon glyphicon-folder-open", "glyphicon glyphicon-random", "glyphicon glyphicon-gift", "glyphicon glyphicon-arrow-left", "glyphicon glyphicon-remove-sign",
									"glyphicon glyphicon-forward", "glyphicon glyphicon-check", "glyphicon glyphicon-indent-right", "glyphicon glyphicon-text-height", "glyphicon glyphicon-tags", "glyphicon glyphicon-flag",
									"glyphicon glyphicon-download", "glyphicon glyphicon-signal", "glyphicon glyphicon-th-large", "glyphicon glyphicon-glass");
			
			$ikony_font_awesome = array("fa-adjust", "fa-anchor", "fa-archive", "fa-arrows", "fa-arrows-h", "fa-arrows-v", "fa-asterisk", "fa-automobile", "fa-ban", "fa-bank",
										"fa-bar-chart-o", "fa-barcode", "fa-bars", "fa-beer", "fa-bell", "fa-bell-o", "fa-bolt", "fa-bomb", "fa-book", "fa-bookmark", "fa-bookmark-o",
										"fa-briefcase", "fa-bug", "fa-building", "fa-building-o", "fa-bullhorn", "fa-bullseye", "fa-cab", "fa-calendar", "fa-calendar-o", "fa-camera",
										"fa-camera-retro", "fa-car", "fa-caret-square-o-down", "fa-caret-square-o-left", "fa-caret-square-o-right", "fa-caret-square-o-up", "fa-certificate",
										"fa-check", "fa-check-circle", "fa-check-circle-o", "fa-check-square", "fa-check-square-o", "fa-child", "fa-circle", "fa-circle-o", "fa-circle-o-notch",
										"fa-circle-thin", "fa-clock-o", "fa-cloud", "fa-cloud-download", "fa-cloud-upload", "fa-code", "fa-code-fork", "fa-coffee", "fa-cog", "fa-cogs",
										"fa-comment", "fa-comment-o", "fa-comments", "fa-comments-o", "fa-compass", "fa-credit-card", "fa-crop", "fa-crosshairs", "fa-cube", "fa-cubes",
										"fa-cutlery", "fa-dashboard", "fa-database", "fa-desktop", "fa-dot-circle-o", "fa-download", "fa-edit", "fa-ellipsis-h", "fa-ellipsis-v", "fa-envelope",
										"fa-envelope-o", "fa-envelope-square", "fa-eraser", "fa-exchange", "fa-exclamation", "fa-exclamation-circle", "fa-exclamation-triangle", "fa-external-link",
										"fa-external-link-square", "fa-eye", "fa-eye-slash", "fa-fax", "fa-female", "fa-fighter-jet", "fa-file-archive-o", "fa-file-audio-o", "fa-file-code-o",
										"fa-file-excel-o", "fa-file-image-o", "fa-file-movie-o", "fa-file-pdf-o", "fa-file-photo-o", "fa-file-picture-o", "fa-file-powerpoint-o", "fa-file-sound-o",
										"fa-file-video-o", "fa-file-word-o", "fa-file-zip-o", "fa-film", "fa-filter", "fa-fire", "fa-fire-extinguisher", "fa-flag", "fa-flag-checkered",
										"fa-flag-o", "fa-flash", "fa-flask", "fa-folder", "fa-folder-o", "fa-folder-open", "fa-folder-open-o", "fa-frown-o", "fa-gamepad", "fa-gavel",
										"fa-gear", "fa-gears", "fa-gift", "fa-glass", "fa-globe", "fa-graduation-cap", "fa-group", "fa-hdd-o", "fa-headphones", "fa-heart", "fa-heart-o",
										"fa-history", "fa-home", "fa-image", "fa-inbox", "fa-info", "fa-info-circle", "fa-institution", "fa-key", "fa-keyboard-o", "fa-language", "fa-laptop",
										"fa-leaf", "fa-legal", "fa-lemon-o", "fa-level-down", "fa-level-up", "fa-life-bouy", "fa-life-ring", "fa-life-saver", "fa-lightbulb-o",
										"fa-location-arrow", "fa-lock", "fa-magic", "fa-magnet", "fa-mail-forward", "fa-mail-reply", "fa-mail-reply-all", "fa-male", "fa-map-marker",
										"fa-meh-o", "fa-microphone", "fa-microphone-slash", "fa-minus", "fa-minus-circle", "fa-minus-square", "fa-minus-square-o", "fa-mobile", "fa-mobile-phone",
										"fa-money", "fa-moon-o", "fa-mortar-board", "fa-music", "fa-navicon", "fa-paper-plane", "fa-paper-plane-o", "fa-paw", "fa-pencil", "fa-pencil-square",
										"fa-pencil-square-o", "fa-phone", "fa-phone-square", "fa-photo", "fa-picture-o", "fa-plane", "fa-plus", "fa-plus-circle", "fa-plus-square",
										"fa-plus-square-o", "fa-power-off", "fa-print", "fa-puzzle-piece", "fa-qrcode", "fa-question", "fa-question-circle", "fa-question-circle",
										"fa-quote-left", "fa-quote-right", "fa-random", "fa-recycle", "fa-refresh", "fa-reorder", "fa-reply", "fa-reply-all", "fa-retweet", "fa-road",
										"fa-rocket", "fa-rss", "fa-rss-square", "fa-search", "fa-search-minus", "fa-search-plus", "fa-send", "fa-send-o", "fa-share", "fa-share-alt",
										"fa-share-alt-square", "fa-share-square", "fa-share-square-o", "fa-shield", "fa-shopping-cart", "fa-sign-in", "fa-sign-out", "fa-signal",
										"fa-sitemap", "fa-sliders", "fa-smile-o", "fa-sort", "fa-sort-alpha-asc", "fa-sort-alpha-desc", "fa-sort-amount-asc", "fa-sort-amount-desc",
										"fa-sort-asc", "fa-sort-desc", "fa-sort-down", "fa-sort-up", "fa-sort-numeric-asc", "fa-sort-numeric-desc", "fa-space-shuttle", "fa-spinner",
										"fa-spoon", "fa-square", "fa-square-o", "fa-star", "fa-star-half", "fa-star-half-empty", "fa-star-half-full", "fa-star-half-o", "fa-star-o",
										"fa-suitcase", "fa-sun-o", "fa-support", "fa-tablet", "fa-tachometer", "fa-tag", "fa-tags", "fa-tasks", "fa-taxi", "fa-terminal", "fa-thumb-tack",
										"fa-thumbs-down", "fa-thumbs-o-down", "fa-thumbs-o-up", "fa-thumbs-up", "fa-ticket", "fa-times", "fa-times-circle", "fa-times-circle-o",
										"fa-tint", "fa-toggle-down", "fa-toggle-left", "fa-toggle-right", "fa-toggle-up", "fa-trash-o", "fa-tree", "fa-trophy", "fa-truck", "fa-umbrella",
										"fa-university", "fa-unlock", "fa-unlock-alt", "fa-unsorted", "fa-upload", "fa-user", "fa-users", "fa-video-camera", "fa-volume-down", "fa-volume-down",
										"fa-volume-off", "fa-volume-up", "fa-warning", "fa-wheelchair", "fa-wrench");
			
			$ikony_domyslne = array("header" => $header,
									"ikony_font_awesome" => $ikony_font_awesome,
									"ikony_bootstrap" => $ikony_bootstrap);
									
			Index::$smarty->assign("ikony_domyslne", $ikony_domyslne);
			Index::$smarty->assign('location', 'ikony.tpl');
		}
	}
	
?>