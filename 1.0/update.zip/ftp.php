<?php
	$ftp = new Ftp();
	
	/**
	 * 
	 */
	class Ftp {
		
		function __construct() {
			if(isset($_POST['new_plik'])){
				$this->tworzenie_pliku($_POST['new_plik'], $_POST['mode']);
			}
			
			if(isset($_POST['new_folder'])){
				$this->tworzenie_folderu($_POST['new_folder'], $_POST['dostep']);
			}
			
			if(isset($_FILES['plik'])){
				$this->upload($_POST['sciezka'], $_FILES['plik']);
			}
			
			if(isset($_POST['chmod_change'])){
				$array = $_POST['chmod_change'];
				$array = explode("|", $array);
				
				foreach ($array as $item) {
					if($item != "on" && $item != ''){
						$this->zmiana_uprawnien($item, $_POST['mode']);
					}
				}
			}
			
			if(isset($_POST['nowa_nazwa'])){
				$this->zmiana_nazwy("../".$_POST['sciezka'], $_POST['stara_nazwa'], $_POST['nowa_nazwa']);
			}
			
			if(isset($_POST['usuwanie'])){
				$array = $_POST['usuwanie'];
				$array = explode("|", $array);
				
				foreach ($array as $item) {
					if($item != "on" && $item != ''){
						$this->usuwanie($item);
					}
				}
			}
			
			if(isset($_POST['odczyt'])){
				$this->odczyt($_POST['odczyt']);
			}
			
			$header = array("Zarządzanie plikami", "cloud");
			
			Index::$smarty->assign("header", $header);
			Index::$smarty->assign("location", "ftp.tpl");
			
			$this->rozszerzenia();
			$this->lista_plikow();

			if(isset($_POST['zapis'])){
				$this->zapis($_POST['zapis'], $_POST['sciezka_zapis']);
			}
			
			$this->teksty();
		}
		
		public function odczyt($sciezka){
			$fp = fopen($sciezka, "r");
			$dane = "";
			
			if(filesize($sciezka) > 0){
				$dane = fread($fp, filesize($sciezka));
			}
			
			$wartosc = "<div id='odczyt'>".$dane."</div>";
			echo($wartosc);
			fclose($fp);
		}
		
		public function teksty(){
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$ftp_text = array("Ogolne" => array("Utwórz plik", "Utwórz folder", "Odświerz", "Prześlij plik", "Zmień uprawnienia", "Usuń", "Lokacja", "Nazwa", "Rozmiar", "Uprawnienia",
												"Ostatania edycja", "Data utworzenia", "Zmień nazwę", "Zmień uprawnienia", "Edytuj", "Usuń", "URL"),
								"Popups" => array("Nowy plik" => array("Tworzenie pliku", "Wprowadź nazwę z rozszerzeniem", "Podaj prawa dostępu (numeryczne)", "Dodaj", "Anuluj"),
													"Nowy folder" => array("Tworzenie folderu", "Wprowadź nazwę", "Podaj prawa dostępu (numeryczne)", "Dodaj", "Anuluj"),
													"Przeylanie pliku" => array("Przesyłanie pliku", "Wskaż plik który chcesz przesłać", "Prześlij", "Anuluj"),
													"Zmaina uprawnien" => array("Zmiana uprawnienień", "Podaj prawa dostępu (numeryczne)", "Zmień", "Anuluj"),
													"Usuwanie" => array("Usuwanie elementów", "Czy jesteś pewien że chcesz usunąć element(y)?", "Usuń", "Anuluj"),
													"Zmiana nazwy" => array("Zmiana nazwy", "Wprowadź nową nazwę", "Zmień", "Anuluj"),
													"Edycja pliku" => array("Edycja pliku", "Zapisz", "Anuluj"),
													"URL" => array("Lonk do pliku", "Skopiuj link", "Zamknij")
											),
								"Puste" => "Nie możesz pozostawić pola pustego",
								"Nie_zaznaczone" => "Musisz zaznaczyć conajmniej 1 element",
								"Pusty_plik" => "Musisz wybrać plik",
								"permissions" => "Odmówiono dostępu do folderu/pliku",
								"Istnienje" => "Folder już istnieje",
								"Istnienje_plik" => "Plik już istnieje"
							);
			} elseif($_SESSION['jezyk'] == 'EN'){
				$ftp_text = array("Ogolne" => array("Create file", "Create folder", "Refresh", "Send file", "Change permissions", "Remove", "Location", "Name", "Size", "Permissions",
												"Last edit", "Create date", "Change name", "Change permissions", "Edit", "Remove", "URL"),
								"Popups" => array("Nowy plik" => array("Creating file", "Enter name with extension", "Enter permissions (numeric)", "Add", "Cancel"),
													"Nowy folder" => array("Creating folder", "Enter name", "Enter permissions (numeric)", "Add", "Cancel"),
													"Przeylanie pliku" => array("Sending file", "Choose file to send", "Send", "Cancel"),
													"Zmaina uprawnien" => array("Changing permissions", "Enter permissions (numeric)", "Save", "Cancel"),
													"Usuwanie" => array("Deleting", "Are you sure you want to delete an item(s)?", "Delete", "Cancel"),
													"Zmiana nazwy" => array("Change name", "Enter name", "Save", "Cancel"),
													"Edycja pliku" => array("Editing file", "Save", "Cancel"),
													"URL" => array("Lonk to file", "Copy this link", "Close")
											),
								"Puste" => "You can not leave file empty",
								"Nie_zaznaczone" => "You must select at least one element",
								"Pusty_plik" => "You must select file",
								"permissions" => "Folder/file permissions denied",
								"Istnienje" => "Folder exist",
								"Istnienje_plik" => "File exist"
							);
			} elseif($_SESSION['jezyk'] == 'DE'){
				$ftp_text = array("Ogolne" => array("Utwórz plik", "Utwórz folder", "Odświerz", "Prześlij plik", "Zmień uprawnienia", "Usuń", "Lokacja", "Nazwa", "Rozmiar", "Uprawnienia",
												"Ostatania edycja", "Data utworzenia", "Zmień nazwę", "Zmień uprawnienia", "Edytuj", "Usuń", "URL"),
								"Popups" => array("Nowy plik" => array("Tworzenie pliku", "Wprowadź nazwę z rozszerzeniem", "Podaj prawa dostępu (numeryczne)", "Dodaj", "Anuluj"),
													"Nowy folder" => array("Tworzenie folderu", "Wprowadź nazwę", "Podaj prawa dostępu (numeryczne)", "Dodaj", "Anuluj"),
													"Przeylanie pliku" => array("Przesyłanie pliku", "Wskaż plik który chcesz przesłać", "Prześlij", "Anuluj"),
													"Zmaina uprawnien" => array("Zmiana uprawnienień", "Podaj prawa dostępu (numeryczne)", "Zmień", "Anuluj"),
													"Usuwanie" => array("Usuwanie elementów", "Czy jesteś pewien że chcesz usunąć element(y)?", "Usuń", "Anuluj"),
													"Zmiana nazwy" => array("Zmiana nazwy", "Wprowadź nową nazwę", "Zmień", "Anuluj"),
													"Edycja pliku" => array("Edycja pliku", "Zapisz", "Anuluj"),
													"URL" => array("Lonk do pliku", "Skopiuj link", "Zamknij")
											),
								"Puste" => "Nie możesz pozostawić pola pustego",
								"Nie_zaznaczone" => "Musisz zaznaczyć conajmniej 1 element",
								"Pusty_plik" => "Musisz wybrać plik",
								"permissions" => "Odmówiono dostępu do folderu/pliku",
								"Istnienje" => "Folder istnieje",
								"Istnienje_plik" => "Plik już istnieje"
							);
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$ftp_text = array("Ogolne" => array("Utwórz plik", "Utwórz folder", "Odświerz", "Prześlij plik", "Zmień uprawnienia", "Usuń", "Lokacja", "Nazwa", "Rozmiar", "Uprawnienia",
												"Ostatania edycja", "Data utworzenia", "Zmień nazwę", "Zmień uprawnienia", "Edytuj", "Usuń", "URL"),
								"Popups" => array("Nowy plik" => array("Tworzenie pliku", "Wprowadź nazwę z rozszerzeniem", "Podaj prawa dostępu (numeryczne)", "Dodaj", "Anuluj"),
													"Nowy folder" => array("Tworzenie folderu", "Wprowadź nazwę", "Podaj prawa dostępu (numeryczne)", "Dodaj", "Anuluj"),
													"Przeylanie pliku" => array("Przesyłanie pliku", "Wskaż plik który chcesz przesłać", "Prześlij", "Anuluj"),
													"Zmaina uprawnien" => array("Zmiana uprawnienień", "Podaj prawa dostępu (numeryczne)", "Zmień", "Anuluj"),
													"Usuwanie" => array("Usuwanie elementów", "Czy jesteś pewien że chcesz usunąć element(y)?", "Usuń", "Anuluj"),
													"Zmiana nazwy" => array("Zmiana nazwy", "Wprowadź nową nazwę", "Zmień", "Anuluj"),
													"Edycja pliku" => array("Edycja pliku", "Zapisz", "Anuluj"),
													"URL" => array("Lonk do pliku", "Skopiuj link", "Zamknij")
											),
								"Puste" => "Nie możesz pozostawić pola pustego",
								"Nie_zaznaczone" => "Musisz zaznaczyć conajmniej 1 element",
								"Pusty_plik" => "Musisz wybrać plik",
								"permissions" => "Odmówiono dostępu do folderu/pliku",
								"Istnienje" => "Folder istnieje",
								"Istnienje_plik" => "Plik już istnieje"
							);
			}
			
			Index::$smarty->assign("teksty", $ftp_text);
		}
		
		public function zapis($tresc, $sciezka){
			$access = $_SESSION['Dostep'];
			$access = $access[3];
			
			if($access == 5){
				$nazwa = explode("/", $sciezka);
				$nazwa = end($nazwa);
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 32, '".$nazwa."|".$_SESSION['Email']."')");
				
				$fp = fopen($sciezka, "w");
				fputs($fp, $tresc);
				fclose($fp);
				$error = error_get_last();
				
				if($error['message'] == 'mkdir(): Permission denied'){
					header("Dostep: 1");
				} else {
					Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 14, '".$nazwa."|".$_SESSION['Email']."')");
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function upload($sciezka, $plik){
			$access = $_SESSION['Dostep'];
			$access = $access[3];
			
			if($access == 5){
				$uploaded = $sciezka.$plik['name'];
				if (is_uploaded_file($plik['tmp_name'])) {
					$nazwa = explode("/", $uploaded);
					$nazwa = end($nazwa);
					@move_uploaded_file($plik['tmp_name'],$uploaded);
					
					$error = error_get_last();
					
					if($error['message'] == 'mkdir(): Permission denied'){
						header("Dostep: 1");
					} else {
						Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 13, '".$nazwa."|".$_SESSION['Email']."')");
					}
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function zmiana_uprawnien($sciezka, $mode){
			$access = $_SESSION['Dostep'];
			$access = $access[3];
			
			if($access == 5){
				$nazwa = explode("/", $sciezka);
				$nazwa = end($nazwa);
				
				@chmod($sciezka, $mode);
				$error = error_get_last();
				
				if($error['message'] == 'mkdir(): Permission denied'){
					header("Dostep: 1");
				} else {
					Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 14, '".$nazwa."|".$_SESSION['Email']."')");
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function tworzenie_folderu($sciezka, $dostep){
			$access = $_SESSION['Dostep'];
			$access = $access[3];
			
			if($access == 5){
				$nazwa = explode("/", $sciezka);
				$nazwa = end($nazwa);
				
				@mkdir($sciezka, $dostep);
				$error = error_get_last();
				
				if($error != ""){
					if($error['message'] == 'mkdir(): File exists'){
						header("Istnienie: 1");
					}elseif($error['message'] == 'mkdir(): Permission denied'){
						header("Dostep: 1");
					}
				} else {
					Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 12, '".$nazwa."|".$_SESSION['Email']."')");
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function tworzenie_pliku($sciezka, $mode){
			$access = $_SESSION['Dostep'];
			$access = $access[3];
			
			if($access == 5){
				if($mode == ''){
					$mode = 777;
				}
				$nazwa = explode("/", $sciezka);
				$nazwa = end($nazwa);
				
				if(!file_exists($sciezka)){
					touch($sciezka);
					chmod($sciezka, $mode);
				} else {
					header("Istnienie: 1");
				}
				
				$error = error_get_last();
				
				if($error['message'] == 'mkdir(): Permission denied'){
					header("Dostep: 1");
				} else {
					Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 11, '".$nazwa."|".$_SESSION['Email']."')");
					chmod($sciezka, $mode);
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		private static function usuwanie($sciezka){
			$access = $_SESSION['Dostep'];
			$access = $access[3];
			
			if($access == 5){
				if($sciezka != ""){
					if(is_dir($sciezka)){
						$scan = scandir($sciezka);
						foreach ($scan as $key) {
							if($key != '.' && $key != '..'){
								if(filetype($sciezka.'/'.$key) == 'dir'){
									self::usuwanie($sciezka.'/'.$key);
								} else {
									@unlink($sciezka.'//'.$key);
									$error = error_get_last();
									
									if($error['message'] == 'mkdir(): Permission denied'){
										header("Dostep: 1");
									} else {
										$nazwa = explode("/", $sciezka);
										$nazwa = end($nazwa);
										Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 15, '".$nazwa."|".$_SESSION['Email']."')");
									}
								}
							}
						}
						reset($scan);
						@rmdir($sciezka);
						$error = error_get_last();
						
						if($error['message'] == 'mkdir(): Permission denied'){
							header("Dostep: 1");
						} else {
							$nazwa = explode("/", $sciezka);
							$nazwa = end($nazwa);
							Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 15, '".$nazwa."|".$_SESSION['Email']."')");
						}
					} else {
						@unlink($sciezka);
						$error = error_get_last();
						
						if($error['message'] == 'mkdir(): Permission denied'){
							header("Dostep: 1");
						} else {
							$nazwa = explode("/", $sciezka);
							$nazwa = end($nazwa);
							Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 15, '".$nazwa."|".$_SESSION['Email']."')");
						}
					}
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function zmiana_nazwy($sciezka, $stara_nazwa, $nowa_nazwa){
			$access = $_SESSION['Dostep'];
			$access = $access[3];
			
			if($access == 5){
				@rename($sciezka.$stara_nazwa, $sciezka.$nowa_nazwa);
				$error = error_get_last();
				
				if($error['message'] == 'mkdir(): Permission denied'){
					header("Dostep: 1");
				} else {
					Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 38, '".$nowa_nazwa."|".$_SESSION['Email']."')");
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		private $pliki = array();
		private $foldery = array();
		
		public function rozszerzenia(){
			$query = Index::$pdo->query("SELECT * FROM `rozszerzenia`");
			
			$query = $query->fetchAll(PDO::FETCH_ASSOC);
			
			$ext = array();
			
			foreach ($query as $item){
				$itm = explode(",", $item['Wartosc']);
				$ext[$item['Typ']] = $itm;
			}
			
			Index::$smarty->assign("rozszerzenia", $ext);
		}
		
		public function lista_plikow(){
			if(!isset($_POST['folder']) || $_POST['folder'] == '../pliki'){
				$sciezka = '../pliki/';
				$back = '';
			} else {
				$sciezka = $_POST['folder'];
				
				if($sciezka[strlen($sciezka)-1] != '/'){
					$sciezka .= '/';
				}
				
				if($sciezka != "../pliki/"){
					$back = explode("/", trim($sciezka, "/"));
					unset($back[count($back) - 1]);
					$back = implode('/', $back);
				} else {
					$back = '';
				}
			}
			
			@$dir = opendir($sciezka);
			$error = error_get_last();
			
			if($error['message'] == 'mkdir(): Permission denied'){
				header("Dostep: 1");
			} else {
				$folder = 0;
				$plik = 0;
				
				while($plik = readdir($dir)){
					if($plik != '.' && $plik != ".."){
						if(is_dir($sciezka.$plik)){
							$this->foldery[$folder] = array("Nazwa" => $plik, "Ostatnia_edycja" => date ("Y-m-d H:i", filemtime($sciezka.$plik)),
												"Data_utworzenia" => date ("Y-m-d H:i", filectime($sciezka.$plik)), "Uprawnienia" => fileperms($sciezka.$plik)
							);
							++$folder;
						} else {
							$info = pathinfo($plik);
							if(filesize($sciezka.$plik) / 1024 < 1024){
								$rozmiar = round(filesize($sciezka.$plik) / 1024, 2);
								$roz = 'KB';
							} elseif(filesize($sciezka.$plik) / 1024 < (1024*1024)){
								$rozmiar = round(filesize($sciezka.$plik) / (1024*1024), 2);
								$roz = 'MB';
							} else{
								$rozmiar = round(filesize($sciezka.$plik) / (1024*1024*1024), 2);
								$roz = 'GB';
							}
							
							$this->pliki[$plik] = array("Nazwa" => $plik, 'Rozmiar' => $rozmiar, 'Rozszerzenie' => (array_key_exists("extension", $info)) ? $info['extension'] : "",
												'Jednostka' => $roz, "Ostatnia_edycja" => date ("Y-m-d H:i", filemtime($sciezka.$plik)),
												"Data_utworzenia" => date ("Y-m-d H:i", filectime($sciezka.$plik)), "Uprawnienia" => fileperms($sciezka.$plik)
							);
							++$plik;
						}
					}
				}
			}	

			Index::$smarty->assign("powrot", $back);
			Index::$smarty->assign("sciezka", $sciezka);
			Index::$smarty->assign("foldery", $this->foldery);
			Index::$smarty->assign("pliki", $this->pliki);
		}
	}
?>