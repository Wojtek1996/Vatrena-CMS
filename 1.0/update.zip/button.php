<?php
	$button = new Button();
	
	/**
	 * 
	 */
	class Button {
		
		function __construct() {
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$header = array("Lista przycisków", "gamepad");
				$btns_header = array("Przyciski domyślne", "Domyslne", "Okrągłe przyciski", "O", "Przyciski z obramowaniem", "Obramowanie", "Płaskie przyciski", "Płaski",
									"Przyciski zaokrąglone", "Zaokrąglone", "Przyciski bez zaokrągleń", "Bez zaokrągleń");
				$btns_sizes = array("Domyślny rozmiar przycisków", "Bardzo małe przyciski", "Małe przyciski", "Duże przyciski");
			} elseif($_SESSION['jezyk'] == 'EN'){
				$header = array("Buttons list", "gamepad");
				$btns_header = array("Default buttons", "Default", "Radius buttons", "R", "Buttons with border", "Border", "Flat buttons", "Flat",
									"Rounded buttons", "Rounded", "Buttons without rounded", "No rounded");
				$btns_sizes = array("Default buttons size", "Extra small buttons", "Small buttons", "Large buttons");
			} elseif($_SESSION['jezyk'] == 'DE'){
				$header = array("Lista przycisków", "gamepad");
				$btns_header = array("Przyciski domyślne", "Domyslne", "Okrągłe przyciski", "O", "Przyciski z obramowaniem", "Obramowanie", "Płaskie przyciski", "Płaski",
									"Przyciski zaokrąglone", "Zaokrąglone", "Przyciski bez zaokrągleń", "Bez zaokrągleń");
				$btns_sizes = array("Domyślny rozmiar przycisków", "Bardzo małe przyciski", "Małe przyciski", "Duże przyciski");
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$header = array("Lista przycisków", "gamepad");
				$btns_header = array("Przyciski domyślne", "Domyslne", "Okrągłe przyciski", "O", "Przyciski z obramowaniem", "Obramowanie", "Płaskie przyciski", "Płaski",
									"Przyciski zaokrąglone", "Zaokrąglone", "Przyciski bez zaokrągleń", "Bez zaokrągleń");
				$btns_sizes = array("Domyślny rozmiar przycisków", "Bardzo małe przyciski", "Małe przyciski", "Duże przyciski");
			}
			
			$buttons_default = array("header" => $header,
									"btns_header" => $btns_header,
									"btns_sizes" => $btns_sizes);
			
			Index::$smarty->assign("buttons_default", $buttons_default);
			
			Index::$smarty->assign("location", "button.tpl");
		}
	}
?>