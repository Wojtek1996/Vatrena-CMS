<?php
	$uprawnienia = new Uprawnienia();
	
	/**
	 * Wartości
	 * 0 - Wszystko zabronione
	 * 1 - Tworzenie
	 * 2 - Modyfikacja (edycja)
	 * 3 - Usuwanie
	 * 4 - Tworzenie + Modyfikacja
	 * 5 - Wszystko dozwolone
	 * 
	 * Segmenty
	 * 0 - Artykuły
	 * 1 - Kategorie
	 * 2 - Menu
	 * 3 - FTP
	 * 4 - Konfiguracja globalna
	 * 5 - Użytkownicy
	 * 6 - Grupy
	 * 7 - Logi
	 */
	class Uprawnienia {
		function __construct() {
			if(isset($_POST['del_group'])){
				$this->usuwanie($_POST['del_group']);
			}
			
			if(isset($_POST['nazwa'])){
				$this->dodawanie($_POST['nazwa'], $_POST['artykuly'], $_POST['kategorie'], $_POST['menu'], $_POST['pliki'], $_POST['konfiguracja'], $_POST['uzytkownicy'], $_POST['grupy'], $_POST['logi']);
			}
			
			if(isset($_POST['edycja'])){
				$this->edycja($_POST['edycja']);
			}
			
			if(isset($_POST['edit_name'])){
				$this->zapis_edycji($_POST['edit_name'], $_POST['edit_artykul'], $_POST['edit_ftp'], $_POST['edit_grupy'], $_POST['edit_kategorie'], $_POST['edit_konfiguracja'], $_POST['edit_menu'], $_POST['edit_user'], $_POST['old'], $_POST['edit_logi']);
			}
			
			Index::$smarty->assign("location", "dostep.tpl");
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$header = array("Zarządzanie dostępem", "key");
				$tabela = array("Zarządzanie grupami", "Nazwa", "Dostęp", "Edytuj", "Usuń");
				$access = array("Dostęp wzbroniony", "Nie możesz wykonać tej czynności ponieważ nie masz wystarczającego poziomu dostępu", "Zamknij");
				$dodawanie = array("Dodawanie grupy", "Nazwa grupy", " Zarządzanie artykułami", "Zarządzanie kategoriami", "Zarządzanie menu", "Zarządzanie plikami", "Zarządzanie konfiguracją",
									"Zarządzanie użytkownikami", "Zarządzanie grupami", "Zarządzanie logami", "Dodaj");
				$info = array("Informacja", "Dostęp w tabeli grup podawany jest w postaci numerycznej, aby zobaczyć poradnik dotyczący grup użytkowników naciśnij znak zapytania na górze strony", "Uwaga", "Zmiany w kontach widoczne będą dopiero po ponownym zalogowaniu się");
				$edycja = array("Edycja", "Nazwa grupy", " Zarządzanie artykułami", "Zarządzanie kategoriami", "Zarządzanie menu", "Zarządzanie plikami", "Zarządzanie konfiguracją",
									"Zarządzanie użytkownikami", "Zarządzanie grupami", "Zarządzanie logami", "Zapisz");
				$name_error = array("Błąd", "Musisz podać nazwę która nie jest już zajęta!", "Zamknij");
				$usuwanie_grupy = array("Usuwanie grupy", "Czy jesteś pewien że chcesz usunąć grupę?", "Usuń", "Anuluj");
			} elseif($_SESSION['jezyk'] == 'EN'){
				$header = array("Access group management", "key");
				$tabela = array("Group management", "Name", "Access", "Edit", "Remove");
				$dodawanie = array("Adding group", "Group name", " Article management", "Category management", "Menu management", "File management", "Configuration management",
									"Users management", "Groups management", "Logs management", "Add");
				$info = array("Information", "Access to group table is given in numerical form to see tutorial for user groups press question mark at the top of the page", "Attention", "Changes in accounts will be visible only after re-login");
				$edycja = array("Edit", "Group name", " Article management", "Category management", "Menu management", "File management", "Configuration management",
									"Users management", "Groups management", "Logs management", "Save");
				$name_error = array("Error", "You must enter a name that is not already occupied!", "Close");
				$usuwanie_grupy = array("Group deleting", "Are you sure you want to delete the group?", "Remove", "Cancel");
			} elseif($_SESSION['jezyk'] == 'DE'){
				$header = array("Zarządzanie dostępem", "key");
				$tabela = array("Zarządzanie grupami", "Nazwa", "Dostep", "Edytuj", "Usuń");
				$dodawanie = array("Dodawanie grupy", "Nazwa grupy", " Zarządzanie artykułami", "Zarządzanie kategoriami", "Zarządzanie menu", "Zarządzanie plikami", "Zarządzanie konfiguracją",
									"Zarządzanie użytkownikami", "Zarządzanie grupami", "Zarządzanie logami", "Dodaj");
				$info = array("Informacja", "Dostęp w tabeli grup podawany jest w postaci numerycznej, aby zobaczyć poradnik dotyczący grup użytkowników naciśnij znak zapytania na górze strony", "Uwaga", "Zmiany w kontach widoczne będą dopiero po ponownym zalogowaniu się");
				$edycja = array("Edycja", "Nazwa grupy", " Zarządzanie artykułami", "Zarządzanie kategoriami", "Zarządzanie menu", "Zarządzanie plikami", "Zarządzanie konfiguracją",
									"Zarządzanie użytkownikami", "Zarządzanie grupami", "Zarządzanie logami", "Zapisz");
				$name_error = array("Błąd", "Musisz podać nazwę która nie jest już zajęta!", "OK");
				$usuwanie_grupy = array("Usuwanie grupy", "Czy jesteś pewien że chcesz usunąć grupę?", "Usuń", "Anuluj");
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$header = array("Zarządzanie dostępem", "key");
				$tabela = array("Zarządzanie grupami", "Nazwa", "Dostep", "Edytuj", "Usuń");
				$dodawanie = array("Dodawanie grupy", "Nazwa grupy", " Zarządzanie artykułami", "Zarządzanie kategoriami", "Zarządzanie menu", "Zarządzanie plikami", "Zarządzanie konfiguracją",
									"Zarządzanie użytkownikami", "Zarządzanie grupami", "Zarządzanie logami", "Dodaj");
				$info = array("Informacja", "Dostęp w tabeli grup podawany jest w postaci numerycznej, aby zobaczyć poradnik dotyczący grup użytkowników naciśnij znak zapytania na górze strony", "Uwaga", "Zmiany w kontach widoczne będą dopiero po ponownym zalogowaniu się");
				$edycja = array("Edycja", "Nazwa grupy", " Zarządzanie artykułami", "Zarządzanie kategoriami", "Zarządzanie menu", "Zarządzanie plikami", "Zarządzanie konfiguracją",
									"Zarządzanie użytkownikami", "Zarządzanie grupami", "Zarządzanie logami", "Zapisz");
				$name_error = array("Błąd", "Musisz podać nazwę która nie jest już zajęta!", "OK");
				$usuwanie_grupy = array("Usuwanie grupy", "Czy jesteś pewien że chcesz usunąć grupę?", "Usuń", "Anuluj");
			}
			
			$query = Index::$pdo->query("SELECT `Nazwa`, `Dostep`, `ID` FROM `grupy_dostepu`");
			$query = $query->fetchAll(PDO::FETCH_ASSOC);
			
			$dostep = array();
			foreach($query as $item){
				$dostep[$item['Nazwa']] = array($item['Dostep'], $item['ID']);
			}
			
			$domyslne = array("grupy" => $dostep,
								"Dostep" => array("Wszystko zabronione" => 0, "Dodawanie" => 1, "Modyfikacja" => 2, "Usuwanie" => 3 , "Dodawanie i modyfikacja" => 4, "Wszystko dozwolone" => 5),
								"Informacja" => $info,
								"Tabela" => $tabela,
								"Dodawanie" => $dodawanie,
								"Edycja" => $edycja,
								"Name_error" => $name_error,
								"Usuwanie" => $usuwanie_grupy);
			
			Index::$smarty->assign("domyslne", $domyslne);
			Index::$smarty->assign("header", $header);
		}
		
		public function zapis_edycji($nazwa, $art, $ftp, $group, $kat, $konfig, $menu, $user, $old_nazwa, $logi){
			$dostep = $art.$kat.$menu.$ftp.$konfig.$user.$group.$logi;
			Index::$pdo->query("UPDATE `grupy_dostepu` SET `Nazwa` = '".$nazwa."', `Dostep` = '".$dostep."' WHERE `Nazwa` = '".$old_nazwa."'");
			Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 26, '".$nazwa."|".$_SESSION['Email']."')");
		}
		
		public function edycja($nazwa){
			$access = $_SESSION['Dostep'];
			$access = $access[6];
			
			if($access == 2 || $access == 4 || $access == 5){
				$query = Index::$pdo->query("SELECT `Nazwa`, `Dostep` FROM `grupy_dostepu` WHERE `Nazwa` = '".$nazwa."'");
				$query = $query->fetch(PDO::FETCH_ASSOC);
				
				echo("<div id='edit_access'>".$query['Nazwa']."|".$query['Dostep']."</div>");
			} else {
				header("ACCESS_DENIED: 1");
			} 
		}

		public function dodawanie($nazwa, $artykul, $kategoria, $menu, $ftp, $konfiguracja, $uzytkownik, $grupa, $logi){
			$access = $_SESSION['Dostep'];
			$access = $access[6];
			
			if($access == 1 || $access == 4 || $access == 5){
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 25, '".$nazwa."|".$_SESSION['Email']."')");
				
				$capsule = $artykul.$kategoria.$menu.$ftp.$konfiguracja.$uzytkownik.$grupa.$logi;
				$insert = Index::$pdo->exec("INSERT INTO `grupy_dostepu` (`ID`, `Nazwa`, `Dostep`) VALUES (null, '".$nazwa."', '".$capsule."')");
				
				$error = Index::$pdo->errorInfo();
				if($error[0] == 23000){
					header("UNIQUE_ERROR: 1");
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function usuwanie($nazwa){
			$access = $_SESSION['Dostep'];
			$access = $access[6];
			
			if($access == 3 || $access == 5){
				$id = Index::$pdo->query("SELECT `Nazwa` FROM `grupy_dostepu` WHERE `Nazwa` = '".$nazwa."'");
				$id = $id->fetch(PDO::FETCH_ASSOC); 
				Index::$pdo->exec("DELETE FROM `grupy_dostepu` WHERE `Nazwa` = '".$nazwa."'");
				Index::$pdo->query("UPDATE `uzytkownicy` SET `Dostep` = 1 WHERE `Dostep` = ".$id['Nazwa']);
				
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 27, '".$nazwa."|".$_SESSION['Email']."')");
			} else {
				header("ACCESS_DENIED: 1");
			} 
		}
	}
?>