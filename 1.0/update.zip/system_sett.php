<?php
	$system = new System();
	/**
	 * 
	 */
	class System {
		
		function __construct() {
			if(isset($_POST['kodowanie'])){
				$this->zapis($_POST['kodowanie'], $_POST['strefa_czasowa'], $_POST['image_ext'], $_POST['text_ext'], $_POST['sound_ext'],
							$_POST['film_ext'], $_POST['archiwa_ext'], $_POST['code_ext'], $_POST['excel_ext'], $_POST['adobe_ext'], $_POST['powerpoint_ext'],
							$_POST['default_lang'], $_POST['gzip_status'], $_POST['gzip_poziom'], $_POST['admin_email']);
			}
			
			Index::$smarty->assign("location", "system_sett.tpl");
			
			$query = Index::$pdo->query("SELECT `Nazwa`, `Wartosc` FROM `ustawienia` WHERE `Nazwa` = 'Kodowanie_znakow' OR `Nazwa` = 'Strefa_czasowa' OR `Nazwa` = 'Jezyk_wyswietlania_panel' OR `Nazwa` = 'gzip' OR `Nazwa` = 'gzip_poziom' OR `Nazwa` = 'admin_email'");
			$query_resoult = array();
			foreach($query as $item){
				$query_resoult[$item['Nazwa']] = $item['Wartosc'];
			}
			$query = Index::$pdo->query("SELECT `Typ`, `Wartosc` FROM `rozszerzenia`");
			foreach ($query as $item) {
				$query_resoult[$item['Typ']] = $item['Wartosc'];
			}
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				Index::$smarty->assign("header", array("Zarządzanie systemem", "cogs"));
				$teksty = array("Ustawienia systemu", "Kodowanie znaków", "Strefa czasowa", "Domyślny język wyświetlania panelu", "Rozszerzenia dźwieków",
							"Rozszerzenia filmów", "Rozszerzenia tekstu", "Rozszerzenia obrazków", "Rozszerzenia kodów źródłowych",
							"Rozszerzenia programu Excel", "Rozszerzenia programu Powerpoint", "Rozszerzenia programów Adobe", "Rozszerzenia archiwów", "Zapisz", "Kompresja gzip",
							"Poziom kompresji", "Email administratora");
				$wybor = array("Tak", "Nie");
				$done = "Zmiany zostały zapisane";
			} elseif($_SESSION['jezyk'] == 'EN'){
				Index::$smarty->assign("header", array("System configuration", "cogs"));
				$teksty = array("System configuration", "Charset", "Time zone", "Default panel language", "Sound extensions",
							"Video extensions", "Text extensions", "Image extensions", "Code extensions",
							"Excel extensions", "Powerpoint extensions", "Adobe extensions", "Archive extensions", "Save", "Gzip compression",
							"Compression level", "Admin email");
				$wybor = array("Yes", "No");
				$done = "Settings have been saved";
			} elseif($_SESSION['jezyk'] == 'DE'){
				Index::$smarty->assign("header", array("Zarządzanie systemem", "cogs"));
				$teksty = array("Ustawienia systemu", "Kodowanie znaków", "Strefa czasowa", "Domyślny język wyświetlania panelu", "Rozszerzenia dźwieków",
							"Rozszerzenia filmów", "Rozszerzenia tekstu", "Rozszerzenia obrazków", "Rozszerzenia kodów źródłowych",
							"Rozszerzenia programu Excel", "Rozszerzenia programu Powerpoint", "Rozszerzenia programów Adobe", "Rozszerzenia archiwów", "Zapisz", "Kompresja gzip",
							"Poziom kompresji", "Email administratora");
				$wybor = array("Tak", "Nie");
				$done = "Zmiany zostały zapisane";
			} elseif($_SESSION['jezyk'] == 'ITA'){
				Index::$smarty->assign("header", array("Zarządzanie systemem", "cogs"));
				$teksty = array("Ustawienia systemu", "Kodowanie znaków", "Strefa czasowa", "Domyślny język wyświetlania panelu", "Rozszerzenia dźwieków",
							"Rozszerzenia filmów", "Rozszerzenia tekstu", "Rozszerzenia obrazków", "Rozszerzenia kodów źródłowych",
							"Rozszerzenia programu Excel", "Rozszerzenia programu Powerpoint", "Rozszerzenia programów Adobe", "Rozszerzenia archiwów", "Zapisz", "Kompresja gzip",
							"Poziom kompresji", "Email administratora");
				$wybor = array("Tak", "Nie");
				$done = "Zmiany zostały zapisane";
			}
			
			$domyslne = array("Kodowanie" => array('Chinese Traditional (Big5) ' => 'big5', 'Korean (EUC) ' => 'euc-kr', 'Western Alphabet ' => 'iso-8859-1', 'Central European Alphabet (ISO)' => 'iso-8859-2',
													'Latin 3 Alphabet (ISO) ' => 'iso-8859-3', 'Baltic Alphabet (ISO) ' => 'iso-8859-4', 'Cyrillic Alphabet (ISO) ' => 'iso-8859-5',
													'Arabic Alphabet (ISO) ' => 'iso-8859-6', 'Greek Alphabet (ISO) ' => 'iso-8859-7', 'Hebrew Alphabet (ISO)' => 'iso-8859-8',
													'Cyrillic Alphabet (KOI8-R) ' => 'koi8-r', 'Japanese (Shift-JIS) ' => 'shift-jis', 'Japanese (EUC) ' => 'x-euc', 'Universal Alphabet (UTF-8) ' => 'utf-8',
													'Central European Alphabet (Windows) ' => 'windows-1250', 'Cyrillic Alphabet (Windows) ' => 'windows-1251', 'Western Alphabet (Windows) ' => 'windows-1252',
													'Greek Alphabet (Windows) ' => 'windows-1253', 'Turkish Alphabet ' => 'windows-1254', 'Hebrew Alphabet (Windows) ' => 'windows-1255',
													'Arabic Alphabet (Windows) ' => 'windows-1256', 'Baltic Alphabet (Windows) ' => 'windows-1257', 'Vietnamese Alphabet (Windows) ' => 'windows-1258',
													'Thai (Windows) ' => 'windows-874'),
								"Strefy_czasowe" => array("Europe/Warsaw" => "Wybierz strefę czasową...","Pacific/Midway" => "(GMT-11:00) Midway",
															"Pacific/Niue" => "(GMT-11:00) Niue","Pacific/Pago_Pago" => "(GMT-11:00) Pago Pago","Pacific/Johnston" => "(GMT-10:00) Czas hawajski","Pacific/Rarotonga" => "(GMT-10:00) Rarotonga","Pacific/Tahiti" => "(GMT-10:00) Tahiti","Pacific/Marquesas" => "(GMT-09:30) Markizy","America/Anchorage" => "(GMT-09:00) Czas alaskański","Pacific/Gambier" => "(GMT-09:00) Gambier","America/Los_Angeles" => "(GMT-08:00) Czas pacyficzny","America/Tijuana" => "(GMT-08:00) Czas pacyficzny - Tijuana","America/Vancouver" => "(GMT-08:00) Czas pacyficzny - Vancouver","America/Whitehorse" => "(GMT-08:00) Czas pacyficzny - Whitehorse","Pacific/Pitcairn" => "(GMT-08:00) Wyspy Pitcairn","America/Shiprock" => "(GMT-07:00) Czas górski","America/Phoenix" => "(GMT-07:00) Czas górski - Arizona","America/Mazatlan" => "(GMT-07:00) Czas górski - Chihuahua, Mazatlan","America/Dawson_Creek" => "(GMT-07:00) Czas górski - Dawson Creek","America/Edmonton" => "(GMT-07:00) Czas górski - Edmonton","America/Hermosillo" => "(GMT-07:00) Czas górski - Hermosillo","America/Yellowknife" => "(GMT-07:00) Czas górski - Yellowknife","America/Belize" => "(GMT-06:00) Belize","America/Chicago" => "(GMT-06:00) Czas centralny","America/Mexico_City" => "(GMT-06:00) Czas centralny - Meksyk","America/Regina" => "(GMT-06:00) Czas centralny - Regina","America/Tegucigalpa" => "(GMT-06:00) Czas centralny – Tegucigalpa","America/Winnipeg" => "(GMT-06:00) Czas centralny- Winnipeg","Pacific/Galapagos" => "(GMT-06:00) Galapagos","America/Guatemala" => "(GMT-06:00) Gwatemala","America/Costa_Rica" => "(GMT-06:00) Kostaryka","America/Managua" => "(GMT-06:00) Managua","America/El_Salvador" => "(GMT-06:00) Salwador","Pacific/Easter" => "(GMT-06:00) Wyspa Wielkanocna","America/Bogota" => "(GMT-05:00) Bogota","America/New_York" => "(GMT-05:00) Czas wschodni","America/Iqaluit" => "(GMT-05:00) Czas wschodni - Iqaluit","America/Montreal" => "(GMT-05:00) Czas wschodni - Montreal","America/Toronto" => "(GMT-05:00) Czas wschodni - Toronto","America/Grand_Turk" => "(GMT-05:00) Grand Turk","America/Guayaquil" => "(GMT-05:00) Guayaquil","America/Havana" => "(GMT-05:00) Hawana","America/Jamaica" => "(GMT-05:00) Jamajka","America/Cayman" => "(GMT-05:00) Kajmany","America/Lima" => "(GMT-05:00) Lima","America/Nassau" => "(GMT-05:00) Nassau","America/Panama" => "(GMT-05:00) Panama","America/Port-au-Prince" => "(GMT-05:00) Port-au-Prince","America/Rio_Branco" => "(GMT-05:00) Rio Branco","America/Caracas" => "(GMT-04:30) Caracas","America/Antigua" => "(GMT-04:00) Antigua","America/Asuncion" => "(GMT-04:00) Asunción","America/Barbados" => "(GMT-04:00) Barbados","Atlantic/Bermuda" => "(GMT-04:00) Bermudy","America/Boa_Vista" => "(GMT-04:00) Boa Vista","America/Campo_Grande" => "(GMT-04:00) Campo Grande","America/Cuiaba" => "(GMT-04:00) Cuiabá","America/Curacao" => "(GMT-04:00) Curaçao","America/Halifax" => "(GMT-04:00) Czas atlantycki - Halifax","America/Guyana" => "(GMT-04:00) Gujana","America/La_Paz" => "(GMT-04:00) La Paz","America/Manaus" => "(GMT-04:00) Manaus","America/Martinique" => "(GMT-04:00) Martynika","America/Tortola" => "(GMT-04:00) Port-of-Spain","America/Puerto_Rico" => "(GMT-04:00) Portoryko","America/Porto_Velho" => "(GMT-04:00) Pôrto Velho","America/Santiago" => "(GMT-04:00) Santiago","America/Santo_Domingo" => "(GMT-04:00) Santo Domingo","Antarctica/Palmer" => "(GMT-04:00) Stacja Palmer","America/Thule" => "(GMT-04:00) Thule","America/St_Johns" => "(GMT-03:30) Czas nowofundlandzki - St. Johns","America/Araguaina" => "(GMT-03:00) Araguaina","America/Belem" => "(GMT-03:00) Belém","America/Argentina/Buenos_Aires" => "(GMT-03:00) Buenos Aires","America/Fortaleza" => "(GMT-03:00) Fortaleza","America/Godthab" => "(GMT-03:00) Godthab","America/Cayenne" => "(GMT-03:00) Kajenna","America/Maceio" => "(GMT-03:00) Maceió","America/Miquelon" => "(GMT-03:00) Miquelon","America/Montevideo" => "(GMT-03:00) Montevideo","America/Paramaribo" => "(GMT-03:00) Paramaribo","America/Recife" => "(GMT-03:00) Recife","America/Bahia" => "(GMT-03:00) Salwador","Antarctica/Rothera" => "(GMT-03:00) Stacja Rothera","Atlantic/Stanley" => "(GMT-03:00) Stanley","America/Sao_Paulo" => "(GMT-03:00) Săo Paulo","Atlantic/South_Georgia" => "(GMT-02:00) Georgia Południowa","America/Noronha" => "(GMT-02:00) Noronha","Atlantic/Azores" => "(GMT-01:00) Azory","America/Scoresbysund" => "(GMT-01:00) Scoresbysund","Atlantic/Cape_Verde" => "(GMT-01:00) Zielony Przylądek","Africa/Abidjan" => "(GMT+00:00) Abidżan","Africa/Accra" => "(GMT+00:00) Akra","Africa/Timbuktu" => "(GMT+00:00) Bamako","Africa/Banjul" => "(GMT+00:00) Bandżul","Africa/Bissau" => "(GMT+00:00) Bissau","Africa/Casablanca" => "(GMT+00:00) Casablanca","Africa/Dakar" => "(GMT+00:00) Dakar","America/Danmarkshavn" => "(GMT+00:00) Danmarkshavn","Europe/Dublin" => "(GMT+00:00) Dublin","Africa/Freetown" => "(GMT+00:00) Freetown","Etc/GMT" => "(GMT+00:00) GMT (bez zmiany czasu)","Africa/Conakry" => "(GMT+00:00) Konakri","Europe/Lisbon" => "(GMT+00:00) Lizbona","Africa/Lome" => "(GMT+00:00) Lomé","Europe/London" => "(GMT+00:00) Londyn","Africa/Monrovia" => "(GMT+00:00) Monrovia","Africa/Nouakchott" => "(GMT+00:00) Nawakszut","Atlantic/Reykjavik" => "(GMT+00:00) Rejkiawik","Africa/Sao_Tome" => "(GMT+00:00) Săo Tomé","Africa/El_Aaiun" => "(GMT+00:00) Ujun","Africa/Ouagadougou" => "(GMT+00:00) Wagadugu","Atlantic/Canary" => "(GMT+00:00) Wyspy Kanaryjskie","Atlantic/Faeroe" => "(GMT+00:00) Wyspy Owcze","Atlantic/St_Helena" => "(GMT+00:00) Św. Helena","Africa/Algiers" => "(GMT+01:00) Algier","Europe/Amsterdam" => "(GMT+01:00) Amsterdam","Europe/Andorra" => "(GMT+01:00) Andora","Africa/Bangui" => "(GMT+01:00) Bangi","Europe/Berlin" => "(GMT+01:00) Berlin","Africa/Brazzaville" => "(GMT+01:00) Brazzaville","Europe/Brussels" => "(GMT+01:00) Bruksela","Europe/Budapest" => "(GMT+01:00) Budapeszt","Africa/Ceuta" => "(GMT+01:00) Ceuta","Europe/Zagreb" => "(GMT+01:00) Czas środkowoeuropejski – Belgrad","Europe/Prague" => "(GMT+01:00) Czas środkowoeuropejski – Praga","Africa/Douala" => "(GMT+01:00) Duala","Europe/Gibraltar" => "(GMT+01:00) Gibraltar","Africa/Kinshasa" => "(GMT+01:00) Kinszasa","Europe/Copenhagen" => "(GMT+01:00) Kopenhaga","Africa/Lagos" => "(GMT+01:00) Lagos","Africa/Libreville" => "(GMT+01:00) Libreville","Africa/Luanda" => "(GMT+01:00) Luanda","Europe/Luxembourg" => "(GMT+01:00) Luksemburg","Europe/Madrid" => "(GMT+01:00) Madryt","Africa/Malabo" => "(GMT+01:00) Malabo","Europe/Malta" => "(GMT+01:00) Malta","Europe/Monaco" => "(GMT+01:00) Monako","Africa/Ndjamena" => "(GMT+01:00) Ndżamena","Africa/Niamey" => "(GMT+01:00) Niamej","Europe/Oslo" => "(GMT+01:00) Oslo","Europe/Paris" => "(GMT+01:00) Paryż","Africa/Porto-Novo" => "(GMT+01:00) Porto Novo","Europe/Vatican" => "(GMT+01:00) Rzym","Europe/Stockholm" => "(GMT+01:00) Sztokholm","Europe/Tirane" => "(GMT+01:00) Tirana","Africa/Tunis" => "(GMT+01:00) Tunis","Europe/Warsaw" => "(GMT+01:00) Warszawa","Europe/Vienna" => "(GMT+01:00) Wiedeń","Africa/Windhoek" => "(GMT+01:00) Windhoek","Europe/Zurich" => "(GMT+01:00) Zurych","Asia/Amman" => "(GMT+02:00) Amman","Europe/Athens" => "(GMT+02:00) Ateny","Asia/Beirut" => "(GMT+02:00) Bejrut","Africa/Blantyre" => "(GMT+02:00) Blantyre","Europe/Bucharest" => "(GMT+02:00) Bukareszt","Africa/Bujumbura" => "(GMT+02:00) Bużumbura","Asia/Damascus" => "(GMT+02:00) Damaszek","Africa/Gaborone" => "(GMT+02:00) Gaborone","Asia/Gaza" => "(GMT+02:00) Gaza","Africa/Harare" => "(GMT+02:00) Harare","Europe/Mariehamn" => "(GMT+02:00) Helsinki","Europe/Istanbul" => "(GMT+02:00) Istambuł","Asia/Jerusalem" => "(GMT+02:00) Jerozolima","Africa/Johannesburg" => "(GMT+02:00) Johannesburg","Africa/Cairo" => "(GMT+02:00) Kair","Africa/Kigali" => "(GMT+02:00) Kigali","Europe/Kiev" => "(GMT+02:00) Kijów","Europe/Chisinau" => "(GMT+02:00) Kiszyniów","Africa/Lubumbashi" => "(GMT+02:00) Lubumbashi","Africa/Lusaka" => "(GMT+02:00) Lusaka","Africa/Maputo" => "(GMT+02:00) Maputo","Africa/Maseru" => "(GMT+02:00) Maseru","Africa/Mbabane" => "(GMT+02:00) Mbabane","Europe/Nicosia" => "(GMT+02:00) Nikozja","Europe/Riga" => "(GMT+02:00) Ryga","Europe/Sofia" => "(GMT+02:00) Sofia","Europe/Tallinn" => "(GMT+02:00) Tallin","Africa/Tripoli" => "(GMT+02:00) Trypolis","Europe/Vilnius" => "(GMT+02:00) Wilno","Africa/Addis_Ababa" => "(GMT+03:00) Addis Abeba","Asia/Aden" => "(GMT+03:00) Aden","Indian/Antananarivo" => "(GMT+03:00) Antananarywa","Africa/Asmera" => "(GMT+03:00) Asmara","Asia/Baghdad" => "(GMT+03:00) Bagdad","Asia/Bahrain" => "(GMT+03:00) Bahrajn","Africa/Khartoum" => "(GMT+03:00) Chartum","Indian/Comoro" => "(GMT+03:00) Comoro","Africa/Dar_es_Salaam" => "(GMT+03:00) Dar es-Salaam","Africa/Djibouti" => "(GMT+03:00) Dżibuti","Africa/Kampala" => "(GMT+03:00) Kampala","Asia/Qatar" => "(GMT+03:00) Katar","Asia/Kuwait" => "(GMT+03:00) Kuwejt","Indian/Mayotte" => "(GMT+03:00) Mayotte","Europe/Minsk" => "(GMT+03:00) Mińsk","Africa/Mogadishu" => "(GMT+03:00) Mogadisz","Europe/Kaliningrad" => "(GMT+03:00) Moskwa-01 - Kaliningrad","Africa/Nairobi" => "(GMT+03:00) Nairobi","Asia/Riyadh" => "(GMT+03:00) Rijad","Antarctica/Syowa" => "(GMT+03:00) Stacja Syowa","Asia/Tehran" => "(GMT+03:30) Teheran","Asia/Baku" => "(GMT+04:00) Baku","Asia/Dubai" => "(GMT+04:00) Dubaj","Asia/Yerevan" => "(GMT+04:00) Erewan","Indian/Mahe" => "(GMT+04:00) Mahé","Asia/Muscat" => "(GMT+04:00) Maskat","Indian/Mauritius" => "(GMT+04:00) Mauritius","Europe/Moscow" => "(GMT+04:00) Moskwa+00","Europe/Samara" => "(GMT+04:00) Moskwa+00 – Samara","Indian/Reunion" => "(GMT+04:00) Reunion","Asia/Tbilisi" => "(GMT+04:00) Tbilisi","Asia/Kabul" => "(GMT+04:30) Kabul","Asia/Aqtau" => "(GMT+05:00) Aktau","Asia/Aqtobe" => "(GMT+05:00) Aktobe","Asia/Ashgabat" => "(GMT+05:00) Aszchabat","Asia/Dushanbe" => "(GMT+05:00) Duszanbe","Asia/Karachi" => "(GMT+05:00) Karaczi","Indian/Maldives" => "(GMT+05:00) Malediwy","Antarctica/Mawson" => "(GMT+05:00) Stacja Mawson","Asia/Tashkent" => "(GMT+05:00) Taszkient","Indian/Kerguelen" => "(GMT+05:00) Wyspy Kerguelena","Asia/Calcutta" => "(GMT+05:30) Czas standardowy - Indie","Asia/Colombo" => "(GMT+05:30) Kolombo","Asia/Katmandu" => "(GMT+05:45) Katmandu","Asia/Almaty" => "(GMT+06:00) Ałma Ata","Asia/Bishkek" => "(GMT+06:00) Biszkek","Indian/Chagos" => "(GMT+06:00) Czagos","Asia/Dhaka" => "(GMT+06:00) Dakka","Asia/Yekaterinburg" => "(GMT+06:00) Moskwa+04 - Jekaterynburg","Antarctica/Vostok" => "(GMT+06:00) Stacja Vostok","Asia/Thimphu" => "(GMT+06:00) Thimphu","Asia/Rangoon" => "(GMT+06:30) Rangun","Indian/Cocos" => "(GMT+06:30) Wyspy Kokosowe","Asia/Bangkok" => "(GMT+07:00) Bangkok","Asia/Hovd" => "(GMT+07:00) Chowd","Asia/Jakarta" => "(GMT+07:00) Dżakarta","Asia/Saigon" => "(GMT+07:00) Hanoi","Asia/Omsk" => "(GMT+07:00) Moskwa+03 - Omsk, Nowosybirsk","Asia/Phnom_Penh" => "(GMT+07:00) Phnom Penh","Antarctica/Davis" => "(GMT+07:00) Stacja Davis","Asia/Vientiane" => "(GMT+07:00) Wientian","Indian/Christmas" => "(GMT+07:00) Wyspa Bożego Narodzenia","Asia/Brunei" => "(GMT+08:00) Brunei","Asia/Choibalsan" => "(GMT+08:00) Choibalsan","Asia/Shanghai" => "(GMT+08:00) Czas chiński - Pekin","Australia/Perth" => "(GMT+08:00) Czas zachodni - Perth","Asia/Hong_Kong" => "(GMT+08:00) Hongkong","Asia/Kuala_Lumpur" => "(GMT+08:00) Kuala Lumpur","Asia/Makassar" => "(GMT+08:00) Makassar","Asia/Macau" => "(GMT+08:00) Makau","Asia/Manila" => "(GMT+08:00) Manila","Asia/Krasnoyarsk" => "(GMT+08:00) Moskwa+04 - Krasnojarsk","Asia/Singapore" => "(GMT+08:00) Singapur","Antarctica/Casey" => "(GMT+08:00) Stacja Casey","Asia/Taipei" => "(GMT+08:00) Tajpej","Asia/Ulaanbaatar" => "(GMT+08:00) Ułan Bator","Asia/Dili" => "(GMT+09:00) Dili","Asia/Jayapura" => "(GMT+09:00) Jayapura","Asia/Irkutsk" => "(GMT+09:00) Moskwa+05 - Irkuck","Pacific/Palau" => "(GMT+09:00) Palau","Asia/Pyongyang" => "(GMT+09:00) Pyongyang","Asia/Seoul" => "(GMT+09:00) Seul","Asia/Tokyo" => "(GMT+09:00) Tokio","Australia/Darwin" => "(GMT+09:30) Czas centralny - Darwin","Australia/Adelaide" => "(GMT+09:30) Czas środkowy - Adelaide","Antarctica/DumontDUrville" => "(GMT+10:00) Baza Dumont D'Urville","Australia/Brisbane" => "(GMT+10:00) Czas wschodni - Brisbane","Australia/Hobart" => "(GMT+10:00) Czas wschodni - Hobart","Australia/Sydney" => "(GMT+10:00) Czas wschodni - Melbourne, Sydney","Pacific/Guam" => "(GMT+10:00) Guam","Asia/Yakutsk" => "(GMT+10:00) Moskwa+06 - Jakuck","Pacific/Port_Moresby" => "(GMT+10:00) Port Moresby","Pacific/Saipan" => "(GMT+10:00) Saipan","Pacific/Yap" => "(GMT+10:00) Truk","Pacific/Efate" => "(GMT+11:00) Efate","Pacific/Guadalcanal" => "(GMT+11:00) Guadalcanal","Pacific/Kosrae" => "(GMT+11:00) Kosrae","Asia/Vladivostok" => "(GMT+11:00) Moskwa+07 - Jużnosachalińsk","Pacific/Noumea" => "(GMT+11:00) Numea","Pacific/Ponape" => "(GMT+11:00) Ponape","Pacific/Norfolk" => "(GMT+11:30) Norfolk","Pacific/Auckland" => "(GMT+12:00) Auckland","Pacific/Fiji" => "(GMT+12:00) Fidżi","Pacific/Funafuti" => "(GMT+12:00) Funafuti","Pacific/Kwajalein" => "(GMT+12:00) Kwajalein","Pacific/Majuro" => "(GMT+12:00) Majuro","Asia/Magadan" => "(GMT+12:00) Moskwa+08 - Magadan","Asia/Kamchatka" => "(GMT+12:00) Moskwa+08 – Petropawłowsk Kamczacki","Pacific/Nauru" => "(GMT+12:00) Nauru","Pacific/Tarawa" => "(GMT+12:00) Tarawa","Pacific/Wake" => "(GMT+12:00) Wake","Pacific/Wallis" => "(GMT+12:00) Wallis","Pacific/Apia" => "(GMT+13:00) Apia","Pacific/Enderbury" => "(GMT+13:00) Enderbury","Pacific/Fakaofo" => "(GMT+13:00) Fakaofo","Pacific/Tongatapu" => "(GMT+13:00) Tongatapu","Pacific/Kiritimati" => "(GMT+14:00) Kiritimati"),
								"jezyk_wyswietlania" => array("Polski" => "PL", "English" => "EN", "Italiano" => "ITA"),
								"Wartosci" => $query_resoult,
								"teksty" => $teksty,
								"wybor" => $wybor,
								"done" => $done
						);
			Index::$smarty->assign("domyslne", $domyslne);
		}
		
		public function zapis($kodowanie, $strefa, $obrazki, $text, $dzwiek, $filmy, $archiwa, $kod, $excel, $adobe, $powerpoint, $panel_lang, $gzip_status, $gzip_posiom, $admin_email){
			$access = $_SESSION['Dostep'];
			$access = $access[4];
			
			if($access == 5){
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 16, '".$_SESSION['Email']."')");
				Index::$pdo->query("UPDATE `ustawienia` SET `Wartosc` = '".$kodowanie."' WHERE `Nazwa` = 'Kodowanie_znakow';
									UPDATE `ustawienia` SET `Wartosc` = '".$strefa."' WHERE `Nazwa` = 'Strefa_czasowa';
									UPDATE `ustawienia` SET `Wartosc` = '".$panel_lang."' WHERE `Nazwa` = 'Jezyk_wyswietlania_panel';
									UPDATE `ustawienia` SET `Wartosc` = '".$gzip_status."' WHERE `Nazwa` = 'gzip';
									UPDATE `ustawienia` SET `Wartosc` = '".$gzip_posiom."' WHERE `Nazwa` = 'gzip_poziom';
									UPDATE `ustawienia` SET `Wartosc` = '".$admin_email."' WHERE `Nazwa` = 'admin_email';
									UPDATE `rozszerzenia` SET `Wartosc` = '".$obrazki."' WHERE `Typ` = 'Obrazki';
									UPDATE `rozszerzenia` SET `Wartosc` = '".$text."' WHERE `Typ` = 'Text';
									UPDATE `rozszerzenia` SET `Wartosc` = '".$dzwiek."' WHERE `Typ` = 'Dzwiek';
									UPDATE `rozszerzenia` SET `Wartosc` = '".$archiwa."' WHERE `Typ` = 'Archiwa';
									UPDATE `rozszerzenia` SET `Wartosc` = '".$kod."' WHERE `Typ` = 'Kod';
									UPDATE `rozszerzenia` SET `Wartosc` = '".$excel."' WHERE `Typ` = 'Excel';
									UPDATE `rozszerzenia` SET `Wartosc` = '".$filmy."' WHERE `Typ` = 'Filmy';
									UPDATE `rozszerzenia` SET `Wartosc` = '".$adobe."' WHERE `Typ` = 'Adobe';
									UPDATE `rozszerzenia` SET `Wartosc` = '".$powerpoint."' WHERE `Typ` = 'Powerpoint'");
				header("Location: system");
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
	}
?>