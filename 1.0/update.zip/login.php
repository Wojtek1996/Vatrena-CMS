<?php
	if(isset($_POST['email'])){
		Logowanie::login();
	}
	
	/**
	 * 
	 */
	class Logowanie {
		public static function login(){
			if($_POST['email'] == '' || $_POST['haslo'] == ''){
				header("Pusto: 1");
			} else {
				$login = strip_tags($_POST['email']);
				$haslo = $_POST['haslo'];
				
				$haslo_dlugosc = strlen($haslo) / 2; #Wyznaczenie połowy wyrazu
				$haslo_1z2 = ceil($haslo_dlugosc); #Wyznaczenie 1 połowy wyrazu(zaokrąglenie)
				$haslo_2z2 = strlen($haslo) - $haslo_1z2; #Wyznaczenie 2 połowy wyrazu
				
				$haslo_a = substr($haslo, 0, $haslo_1z2); #Przypisanie 1 połowy wyrazu
				$haslo_b = substr($haslo, $haslo_1z2, $haslo_2z2); #Przypisanie 2 połowy wyrazu
				
				$haslo_a = sha1($haslo_a); #Hashowanie 1 części hasła
				$haslo_b = sha1($haslo_b); #Hashowanie 2 części hasła
				
				$query = Index::$pdo->prepare("SELECT `ID` FROM `uzytkownicy` WHERE `Email` = ? && `Haslo_a` = '".$haslo_a."' && `Haslo_b` = '".$haslo_b."'");
				$query->bindValue(1, $login);
				$query->execute();
				
				if($query->fetch(PDO::FETCH_OBJ)){
					$status = Index::$pdo->query("SELECT `Status`, `Dostep`, `Imie` FROM `uzytkownicy` WHERE `Email` = '".$_POST['email']."'");
					$status = $status->fetch();
					if($status['Status'] == 0){
						$data = new DateTime(null, new DateTimeZone(Index::$strefa));
						$data = $data -> format("Y-m-d H:i:s");
						$_SESSION['Zalogowany'] = 1;
						$_SESSION['Email'] = $_POST['email'];
						$dostep = Index::$pdo->query("SELECT `Nazwa`, `Dostep` FROM `grupy_dostepu` WHERE `ID` = ".$status['Dostep']);
						$dostep = $dostep->fetchAll(PDO::FETCH_ASSOC);
						
						$_SESSION['Imie'] = $status['Imie'];
						$_SESSION['Dostep'] = $dostep[0]['Dostep'];
						$_SESSION['Grupa'] = $dostep[0]['Nazwa'];
						
						Index::$pdo->query("UPDATE `uzytkownicy` SET `ostatnie_logowanie` = '".$data."' WHERE `Email` = '".$_SESSION['Email']."'");
						Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".$data."', 0, '".$_SESSION['Email']."')");
					} else {
						header("Blad: 1");
					}
				} else {
					$data = new DateTime(null, new DateTimeZone(Index::$strefa));
					$data = $data -> format("Y-m-d H:i:s");
					Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`) VALUES (null, '".$data."', 1)");
					header("Blad: 1");
				}
			}
		}
	}
?>