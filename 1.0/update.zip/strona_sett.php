<?php
	$strona = new Strona();
	/**
	 * 
	 */
	class Strona {
		
		function __construct() {
			if(isset($_POST['nazwa_strony'])){
				$this->zapis($_POST['nazwa_strony'], $_POST['default_page_lang'], $_POST['strona_wlaczona'], $_POST['opis_strony'], $_POST['keywords'], $_POST['robots'], $_POST['imie'], $_POST['autor_widoczny'], $_POST['caching'], $_POST['cache_life_time'], $_POST['section_1_bg'], $_POST['section_2_bg'], $_POST['section_3_bg'], $_POST['section_4_bg'], $_POST['favicon16x16'], $_POST['favicon32x32'], $_POST['favicon57x57'], $_POST['favicon60x60'], $_POST['favicon72x72'], $_POST['favicon76x76'], $_POST['favicon96x96'], $_POST['favicon114x114'], $_POST['favicon120x120'], $_POST['favicon144x144'], $_POST['favicon152x152'], $_POST['favicon160x160'], $_POST['favicon196x196'], $_POST['strona_przebudowa'], $_POST['section_5_bg'], $_POST['section_6_bg'], $_POST['section_7_bg'], $_POST['section_8_bg'], $_POST['section_9_bg'], $_POST['section_10_bg'], $_POST['logo_url'], $_POST['youtube_link'], $_POST['facebook_link'], $_POST['googleplus_link'], $_POST['wyswietlane_na_strone'], $_POST['admin_email']);
			}
			
			Index::$smarty->assign("location", "strona_sett.tpl");
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$header = array("Zarządzanie stroną internetową", "globe");
				$teksty = array("Zarządzanie stroną internetową", " Nazwa strony", "Język strony", "Strona włączona", "Ikonka strony 16x16 (URL)", "Ustawienia metadanych",
								"Opis strony", "Słowa kluczowe", "Roboty", "Autor", "Pokaż metadane autora", "Zapisz", "Caching", "Czas życia cache", "Tło sekcji 1 (Hex)",
								"Tło sekcji 2 (Hex)", "Tło sekcji 3 (Hex)", "Tło sekcji 4 (Hex)", "Ikonka strony 32x32 (URL)", "Ikonka strony 57x57 (URL)",
								"Ikonka strony 60x60 (URL)", "Ikonka strony 72x72 (URL)", "Ikonka strony 76x76 (URL)", "Ikonka strony 96x96 (URL)",
								"Ikonka strony 114x114 (URL)", "Ikonka strony 120x120 (URL)", "Ikonka strony 144x144 (URL)", "Ikonka strony 152x152 (URL)",
								"Ikonka strony 160x160 (URL)", "Ikonka strony 196x196 (URL)", "Strona w przebudowie", "Tło sekcji 5 (Hex)",
								"Tło sekcji 6 (Hex)", "Tło sekcji 7 (Hex)", "Tło sekcji 8 (Hex)", "Tło sekcji 9 (Hex)", "Tło sekcji 10 (Hex)", "Logo (URL)",
								"Link YouTube", "Link Facebook", "Link Google+", "Ilość pozycji na stronie", "Email administraotra");
				$wybor = array("Tak", "Nie");
				$done = "Zmiany zostały zapisane";
			} elseif($_SESSION['jezyk'] == 'EN'){
				$header = array("Page configuration", "globe");
				$teksty = array("Page configuration", " Website name", "Site langugae", "Page on", "Page icon 16x16 (URL)", "Metadata settings",
								"Page description", "Keywords", "Robots", "Author", "Show author metadata", "Save", "Caching", "Cache life time", "Section 1 background (Hex)",
								"Section 2 background (Hex)", "Section 3 background (Hex)", "Section 4 background (Hex)", "Page icon 32x32 (URL)", "Page icon 57x57 (URL)",
								"Page icon 60x60 (URL)", "Page icon 72x72 (URL)", "Page icon 76x76 (URL)", "Page icon 96x96 (URL)",
								"Page icon 114x114 (URL)", "Page icon 120x120 (URL)", "Page icon 144x144 (URL)", "Page icon 152x152 (URL)",
								"Page icon 160x160 (URL)", "Page icon 196x196 (URL)", "Page under construction", "Admin Email");
				$wybor = array("Yes", "No");
				$done = "Settings have been saved";
			} elseif($_SESSION['jezyk'] == 'DE'){
				$header = array("Zarządzanie stroną internetową", "globe");
				$teksty = array("Zarządzanie stroną internetową", " Nazwa strony", "Język strony", "Strona włączona", "Ikonka strony 16x16 (URL)", "Ustawienia metadanych",
								"Opis strony", "Słowa kluczowe", "Roboty", "Autor", "Pokaż metadane autora", "Zapisz", "Caching", "Czas życia cache", "Tło sekcji 1 (Hex)",
								"Tło sekcji 2 (Hex)", "Tło sekcji 3 (Hex)", "Tło sekcji 4 (Hex)", "Ikonka strony 32x32 (URL)", "Ikonka strony 57x57 (URL)",
								"Ikonka strony 60x60 (URL)", "Ikonka strony 72x72 (URL)", "Ikonka strony 76x76 (URL)", "Ikonka strony 96x96 (URL)",
								"Ikonka strony 114x114 (URL)", "Ikonka strony 120x120 (URL)", "Ikonka strony 144x144 (URL)", "Ikonka strony 152x152 (URL)",
								"Ikonka strony 160x160 (URL)", "Ikonka strony 196x196 (URL)", "Strona w przebudowie", "Email administratora");
				$wybor = array("Tak", "Nie");
				$done = "Zmiany zostały zapisane";
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$header = array("Zarządzanie stroną internetową", "globe");
				$teksty = array("Zarządzanie stroną internetową", " Nazwa strony", "Język strony", "Strona włączona", "Ikonka strony 16x16 (URL)", "Ustawienia metadanych",
								"Opis strony", "Słowa kluczowe", "Roboty", "Autor", "Pokaż metadane autora", "Zapisz", "Caching", "Czas życia cache", "Tło sekcji 1 (Hex)",
								"Tło sekcji 2 (Hex)", "Tło sekcji 3 (Hex)", "Tło sekcji 4 (Hex)", "Ikonka strony 32x32 (URL)", "Ikonka strony 57x57 (URL)",
								"Ikonka strony 60x60 (URL)", "Ikonka strony 72x72 (URL)", "Ikonka strony 76x76 (URL)", "Ikonka strony 96x96 (URL)",
								"Ikonka strony 114x114 (URL)", "Ikonka strony 120x120 (URL)", "Ikonka strony 144x144 (URL)", "Ikonka strony 152x152 (URL)",
								"Ikonka strony 160x160 (URL)", "Ikonka strony 196x196 (URL)", "Strona w przebudowie", "Email adnimistratora");
				$wybor = array("Tak", "Nie");
				$done = "Zmiany zostały zapisane";
			}
			
			$query = Index::$pdo->query("SELECT `Nazwa`, `Wartosc` FROM `ustawienia` WHERE `Nazwa` = 'Nazwa_strony' OR `Nazwa` = 'Jezyk_wyswietlania_strona' OR `Nazwa` = 'Strona_wlaczona' OR `Nazwa` = 'Opis' OR `Nazwa` = 'Keywords' OR `Nazwa` = 'Roboty' OR `Nazwa` = 'Autor' OR `Nazwa` = 'Pokaz_autora' OR `Nazwa` = 'Caching' OR `Nazwa` = 'Cache_time' OR `Nazwa` = 'sekcja_1_bg' OR `Nazwa` = 'sekcja_2_bg' OR `Nazwa` = 'sekcja_3_bg' OR `Nazwa` = 'sekcja_4_bg' OR `Nazwa` = 'favicon16x16' OR `Nazwa` = 'favicon32x32' OR `Nazwa` = 'favicon57x57' OR `Nazwa` = 'favicon60x60' OR `Nazwa` = 'favicon72x72' OR `Nazwa` = 'favicon76x76' OR `Nazwa` = 'favicon96x96' OR `Nazwa` = 'favicon114x114' OR `Nazwa` = 'favicon120x120' OR `Nazwa` = 'favicon144x144' OR `Nazwa` = 'favicon152x152' OR `Nazwa` = 'favicon160x160' OR `Nazwa` = 'favicon196x196' OR `Nazwa` = 'Strona_przebudowa' OR `Nazwa` = 'sekcja_5_bg' OR `Nazwa` = 'sekcja_6_bg' OR `Nazwa` = 'sekcja_7_bg' OR `Nazwa` = 'sekcja_8_bg' OR `Nazwa` = 'sekcja_9_bg' OR `Nazwa` = 'sekcja_10_bg' OR `Nazwa` = 'logo_url' OR `Nazwa` = 'youtube_link' OR `Nazwa` = 'facebook_link' OR `Nazwa` = 'googleplus_link' OR `Nazwa` = 'wyswietlane_na_strone' OR `Nazwa` = 'email_administratora'");
			
			$default = array();
			foreach($query as $item){
				$default[$item['Nazwa']] = $item['Wartosc'];
			}
			
			$domyslne = array("header" => $header,
								"jezyk_wyswietlania" => array("Polski" => "PL", "English" => "EN", "Italiano" => "ITA"),
								"roboty" => array('Index, Follow', 'Index, No follow', 'Noindex, Follow', 'Noindex, Nofollow'),
								'domyslne' => $default,
								"teksty" => $teksty,
								"wybor" => $wybor,
								"done" => $done
							);
			
			Index::$smarty->assign("domyslne", $domyslne);
		}
		
		public function zapis($nazwa, $jezyk, $status_strony, $opis, $keywords, $robots, $autor, $autor_show, $caching, $cache_life_time, $sekcja_1_bg, $sekcja_2_bg, $sekcja_3_bg, $sekcja_4_bg, $favicon16x16, $favicon32x32, $favicon57x57, $favicon60x60, $favicon72x72, $favicon76x76, $favicon96x96, $favicon114x114, $favicon120x120, $favicon144x144, $favicon152x152, $favicon160x160, $favicon196x196, $strona_przebudowa, $sekcja_5, $sekcja_6, $sekcja_7, $sekcja_8, $sekcja_9, $sekcja_10, $logo_url, $youtube, $facebook, $googleplus, $wyswietlane_na_strone, $email){
			$access = $_SESSION['Dostep'];
			$access = $access[4];
			
			if($access == 5){
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 17, '".$_SESSION['Email']."')");
				Index::$pdo->query("UPDATE `ustawienia` SET `Wartosc` = '".$nazwa."' WHERE `Nazwa` = 'Nazwa_strony';
									UPDATE `ustawienia` SET `Wartosc` = '".$jezyk."' WHERE `Nazwa` = 'Jezyk_wyswietlania_strona';
									UPDATE `ustawienia` SET `Wartosc` = '".$status_strony."' WHERE `Nazwa` = 'Strona_wlaczona';
									UPDATE `ustawienia` SET `Wartosc` = '".$opis."' WHERE `Nazwa` = 'Opis';
									UPDATE `ustawienia` SET `Wartosc` = '".$keywords."' WHERE `Nazwa` = 'Keywords';
									UPDATE `ustawienia` SET `Wartosc` = '".$robots."' WHERE `Nazwa` = 'Roboty';
									UPDATE `ustawienia` SET `Wartosc` = '".$autor."' WHERE `Nazwa` = 'Autor';
									UPDATE `ustawienia` SET `Wartosc` = '".$autor_show."' WHERE `Nazwa` = 'Pokaz_autora';
									UPDATE `ustawienia` SET `Wartosc` = '".$caching."' WHERE `Nazwa` = 'Caching';
									UPDATE `ustawienia` SET `Wartosc` = '".$cache_life_time."' WHERE `Nazwa` = 'Cache_time';
									UPDATE `ustawienia` SET `Wartosc` = '".$strona_przebudowa."' WHERE `Nazwa` = 'Strona_przebudowa';
									UPDATE `ustawienia` SET `Wartosc` = '".$sekcja_1_bg."' WHERE `Nazwa` = 'sekcja_1_bg';
									UPDATE `ustawienia` SET `Wartosc` = '".$sekcja_2_bg."' WHERE `Nazwa` = 'sekcja_2_bg';
									UPDATE `ustawienia` SET `Wartosc` = '".$sekcja_3_bg."' WHERE `Nazwa` = 'sekcja_3_bg';
									UPDATE `ustawienia` SET `Wartosc` = '".$sekcja_4_bg."' WHERE `Nazwa` = 'sekcja_4_bg';
									UPDATE `ustawienia` SET `Wartosc` = '".$sekcja_3_bg."' WHERE `Nazwa` = 'sekcja_3_bg';
									UPDATE `ustawienia` SET `Wartosc` = '".$favicon16x16."' WHERE `Nazwa` = 'favicon16x16';
									UPDATE `ustawienia` SET `Wartosc` = '".$favicon32x32."' WHERE `Nazwa` = 'favicon32x32';
									UPDATE `ustawienia` SET `Wartosc` = '".$favicon57x57."' WHERE `Nazwa` = 'favicon57x57';
									UPDATE `ustawienia` SET `Wartosc` = '".$favicon60x60."' WHERE `Nazwa` = 'favicon60x60';
									UPDATE `ustawienia` SET `Wartosc` = '".$favicon72x72."' WHERE `Nazwa` = 'favicon72x72';
									UPDATE `ustawienia` SET `Wartosc` = '".$favicon76x76."' WHERE `Nazwa` = 'favicon76x76';
									UPDATE `ustawienia` SET `Wartosc` = '".$favicon96x96."' WHERE `Nazwa` = 'favicon96x96';
									UPDATE `ustawienia` SET `Wartosc` = '".$favicon114x114."' WHERE `Nazwa` = 'favicon114x114';
									UPDATE `ustawienia` SET `Wartosc` = '".$favicon120x120."' WHERE `Nazwa` = 'favicon120x120';
									UPDATE `ustawienia` SET `Wartosc` = '".$favicon144x144."' WHERE `Nazwa` = 'favicon144x144';
									UPDATE `ustawienia` SET `Wartosc` = '".$favicon152x152."' WHERE `Nazwa` = 'favicon152x152';
									UPDATE `ustawienia` SET `Wartosc` = '".$favicon160x160."' WHERE `Nazwa` = 'favicon160x160';
									UPDATE `ustawienia` SET `Wartosc` = '".$favicon196x196."' WHERE `Nazwa` = 'favicon196x196';
									UPDATE `ustawienia` SET `Wartosc` = '".$sekcja_5."' WHERE `Nazwa` = 'sekcja_5_bg';
									UPDATE `ustawienia` SET `Wartosc` = '".$sekcja_6."' WHERE `Nazwa` = 'sekcja_6_bg';
									UPDATE `ustawienia` SET `Wartosc` = '".$sekcja_7."' WHERE `Nazwa` = 'sekcja_7_bg';
									UPDATE `ustawienia` SET `Wartosc` = '".$sekcja_8."' WHERE `Nazwa` = 'sekcja_8_bg';
									UPDATE `ustawienia` SET `Wartosc` = '".$sekcja_9."' WHERE `Nazwa` = 'sekcja_9_bg';
									UPDATE `ustawienia` SET `Wartosc` = '".$sekcja_10."' WHERE `Nazwa` = 'sekcja_10_bg';
									UPDATE `ustawienia` SET `Wartosc` = '".$logo_url."' WHERE `Nazwa` = 'logo_url';
									UPDATE `ustawienia` SET `Wartosc` = '".$youtube."' WHERE `Nazwa` = 'youtube_link';
									UPDATE `ustawienia` SET `Wartosc` = '".$facebook."' WHERE `Nazwa` = 'facebook_link';
									UPDATE `ustawienia` SET `Wartosc` = '".$googleplus."' WHERE `Nazwa` = 'googleplus_link';
									UPDATE `ustawienia` SET `Wartosc` = ".$wyswietlane_na_strone." WHERE `Nazwa` = 'wyswietlane_na_strone';
									UPDATE `ustawienia` SET `Wartosc` = '".$email."' WHERE `Nazwa` = 'email_administratora'");
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
	}
?>