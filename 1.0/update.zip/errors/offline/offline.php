<!DOCTYPE HTML>
<html>
	<head>
		<title>Strona wyłączona</title>
		<meta charset="UTF-8" />
		<base href="<?php 
		$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		$actual_link = explode("admin", $actual_link);
		$actual_link = $actual_link[0];
		echo($actual_link); ?>admin/">
		<style type="text/css">
			*{
				border: 0;
			}
			
			body{
				background: url("errors/offline/city.jpg") no-repeat center center fixed;
				-webkit-background-size: cover;
				-moz-background-size: cover;
				-o-background-size: cover;
				background-size: cover;
			}
			
			#center_wrapper{
				position: absolute;
				width: 600px;
				left: 50%;
				margin-left: -300px;
				height: 300px;
				top: 50%;
				margin-top: -150px;
				background: #fff;
				border-radius: 30px;
				background: #000;
				color: #333333;
				opacity: 0.8;
			}
			
			#center_box{
				position: absolute;
				width: 500px;
				left: 50%;
				margin-left: -250px;
				height: 200px;
				top: 50%;
				margin-top: -100px;
				text-align: center;
				color: #fafafa;
				font-family: fantasy;
			}
			
			h2{
				font-size: 50px;
				margin: 0;
				display: inline-block;
				vertical-align: middle;
				margin-bottom: 50px;
			}
			
			img{
				vertical-align: middle;
				display: inline-block;
				max-height: 60px;
			}
			
			a:link, a:visited, a:active{
				color: #FF4A05;
				text-decoration: none;
			}
		</style>
	</head>
	<body>
		<section id="center_wrapper">
		</section>
		<section id="center_box">
			<h2>Strona wyłączona</h3>
			<p>Strona aktualnie jest <strong>wyłączona</strong>, zapraszamy ponownie później</p>
			<p><a href="javascript:history.back()">Wróć do poprzedniej strony</a></p>
		</section>
	</body>
</html>