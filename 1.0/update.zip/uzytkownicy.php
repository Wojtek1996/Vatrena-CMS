<?php
	$uzytkownicy = new Uzytkownicy();
	/**
	 * 
	 */
	class Uzytkownicy {
		
		function __construct() {
			if(isset($_POST['user_del'])){
				$this->usuwanie($_POST['user_del']);
			}
			
			if(isset($_POST['edit_email'])){
				$this->edycja($_POST['edit_imie'], $_POST['edit_nazwisko'], $_POST['edit_email'], $_POST['edit_kraj'], $_POST['edit_miasto'], $_POST['edit_dostep'], $_POST['edit_pass'], $_POST['id']);
			}
			
			if(isset($_POST['status_data'])){
				$this->status($_POST['status_data']);
			}
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$header = array("Zarządzanie użytkownikami", "users");
				$tabela = array("#", "Imię", "Nazwisko", "Email", "Kraj", 'Miasto', "Grupa", "Status", "Edytuj", "Usuń");
				$alerty = array("Info" => array("Informacja", "Vatrena CMS używa do szyfrowania haseł algorytmu który nie pozwala na odszyfrowanie hasła. Zapomniane hasło może zostać jedynie zmienione."),
								"Uwaga" => array("Uwaga", "Jeśli usuniesz konto na którym jesteś aktualnie zalogowany zmiany nastąpią dopiero po wylogowaniu się"),
								"Email" => "Adres e-mail musi być w formacie e@mail.pl");
				$modals = array("Edycja" => array("Edycja konta użytkownika", "Jeśli nie chcesz zmieniac hasła, pozostaw pole \"Nowe hasło\" puste.", " Imię", 'Nazwisko',
													"Email", "Nowe hasło", "Kraj", "Miasto", "Grupa dostępu", "Zapisz"),
								"Usuwanie" => array("Usuwanie użytkownika", " Czy jesteś pewien że chcesz usunąć użytkownika?", "Usuń", "Anuluj"),
								"Only_admin" => array("Uwaga", "Nie możesz usunąć jedynego konta roota!", "Zamknij"),
								"Email" => array("Uwaga", "Na ten adres Email jest już zarejestrowany inny użytkownik", "Zamknij"));
			} elseif($_SESSION['jezyk'] == 'EN'){
				$header = array("User management", "users");
				$tabela = array("#", "First name", "Last name", "Email", "Countru", 'City', "Group", "Status", "Edit", "Remove");
				$alerty = array("Info" => array("Information", "Vatrena CMS uses an algorithm to encrypt passwords that does not allow to decrypt passwords. Forgot your password can only be changed"),
								"Uwaga" => array("Attention", "If you delete an account on which you are currently logged changes occur only after logging out"),
								"Email" => "Email address must be like e@mail.pl");
				$modals = array("Edycja" => array("User profile edit", "If you do not want to change the password, leave the \"New password\" field empty.", " First name", 'Last name',
													"Email", "New password", "Country", "City", "Access group", "Save"),
								"Usuwanie" => array("Deleting user", " Are you sure you want to remove user?", "Remove", "Cancel"),
								"Only_admin" => array("Attention", "You can not remove last root account!", "Close"),
								"Email" => array("Attention", "On this Email address is already registered another user", "Close"));
			} elseif($_SESSION['jezyk'] == 'DE'){
				$header = array("Zarządzanie użytkownikami", "users");
				$tabela = array("#", "Imię", "Nazwisko", "Email", "Kraj", 'Miasto', "Grupa", "Status", "Edytuj", "Usuń");
				$alerty = array("Info" => array("Informacja", "Vatrena CMS używa do szyfrowania haseł algorytmu który nie pozwala na odszyfrowanie hasła. Zapomniane hasło może zostać jedynie zmienione."),
								"Uwaga" => array("Uwaga", "Jeśli usuniesz konto na którym jesteś aktualnie zalogowany zmiany nastąpią dopiero po wologowaniu się"),
								"Email" => "Adres e-mail musi być w formacie e@mail.pl");
				$modals = array("Edycja" => array("Edycja konta użytkownika", "Jeśli nie chcesz zmieniac hasła, pozostaw pole \"Nowe hasło\" puste.", " Imię", 'Nazwisko',
													"Email", "Nowe hasło", "Kraj", "Miasto", "Grupa dostępu", "Zapisz"),
								"Usuwanie" => array("Usuwanie użytkownika", " Czy jesteś pewien że chcesz usunąć użytkownika?", "Usuń", "Anuluj"),
								"Only_admin" => array("Uwaga", "Nie możesz usunąć jedynego konta roota!", "Zamknij"),
								"Email" => array("Uwaga", "Na ten adres Email jest już zarejestrowany inny użytkownik", "Zamknij"));
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$header = array("Zarządzanie użytkownikami", "users");
				$tabela = array("#", "Imię", "Nazwisko", "Email", "Kraj", 'Miasto', "Grupa", "Status", "Edytuj", "Usuń");
				$alerty = array("Info" => array("Informacja", "Vatrena CMS używa do szyfrowania haseł algorytmu który nie pozwala na odszyfrowanie hasła. Zapomniane hasło może zostać jedynie zmienione."),
								"Uwaga" => array("Uwaga", "Jeśli usuniesz konto na którym jesteś aktualnie zalogowany zmiany nastąpią dopiero po wologowaniu się"),
								"Email" => "Adres e-mail musi być w formacie e@mail.pl");
				$modals = array("Edycja" => array("Edycja konta użytkownika", "Jeśli nie chcesz zmieniac hasła, pozostaw pole \"Nowe hasło\" puste.", " Imię", 'Nazwisko',
													"Email", "Nowe hasło", "Kraj", "Miasto", "Grupa dostępu", "Zapisz"),
								"Usuwanie" => array("Usuwanie użytkownika", " Czy jesteś pewien że chcesz usunąć użytkownika?", "Usuń", "Anuluj"),
								"Only_admin" => array("Uwaga", "Nie możesz usunąć jedynego konta roota!", "Zamknij"),
								"Email" => array("Uwaga", "Na ten adres Email jest już zarejestrowany inny użytkownik", "Zamknij"));
			}
			
			$domyslne = array();
			
			$query = Index::$pdo->query("SELECT * FROM `uzytkownicy`");
			$query = $query->fetchAll(PDO::FETCH_ASSOC);
			
			$users = array();
			foreach($query as $item){
				$users[$item['Email']] = $item;
			}
			
			$query = Index::$pdo->query("SELECT `ID`, `Nazwa` FROM `grupy_dostepu`");
			$query = $query->fetchAll(PDO::FETCH_ASSOC);
			
			foreach($query as $item){
				$groups[$item['ID']] = $item['Nazwa'];
			}
			
			$kraje = array('ANDORRA', 'UNITED ARAB EMIRATES', 'AFGHANISTAN', 'ANTIGUA AND BARBUDA', 'ANGUILLA', 'ALBANIA', 'ARMENIA', 'NETHERLANDS ANTILLES','ANGOLA',
						'ANTARCTICA', 'ARGENTINA', 'AMERICAN SAMOA', 'AUSTRIA', 'AUSTRALIA', 'ARUBA', 'AZERBAIJAN', 'BOSNIA AND HERZEGOVINA', 'BARBADOS', 'BANGLADESH',
						'BELGIUM', 'BURKINA FASO', 'BULGARIA', 'BAHRAIN', 'BURUNDI', 'BENIN', 'SAINT BARTHELEMY', 'BERMUDA', 'BRUNEI DARUSSALAM', 'BOLIVIA', 'BRAZIL',
						'BAHAMAS', 'BHUTAN', 'BOTSWANA', 'BELARUS', 'BELIZE', 'CANADA', 'COCOS', 'CONGO', 'CENTRAL AFRICAN REPUBLIC', 'CONGO', 'SWITZERLAND', 'COTE D IVOIRE',
						'COOK ISLANDS', 'CHILE', 'CAMEROON', 'CHINA', 'COLOMBIA', 'COSTA RICA', 'CUBA', 'CAPE VERDE', 'CHRISTMAS ISLAND', 'CYPRUS', 'CZECH REPUBLIC',
						'GERMANY', 'DJIBOUTI', 'DENMARK', 'DOMINICA', 'DOMINICAN REPUBLIC', 'ALGERIA', 'ECUADOR', 'ESTONIA', 'EGYPT', 'ERITREA', 'SPAIN', 'ETHIOPIA',
						'FINLAND', 'FIJI', 'FALKLAND', 'MICRONESIA', 'FAROE ISLANDS', 'FRANCE', 'GABON', 'UNITED KINGDOM', 'GRENADA', 'GEORGIA', 'GHANA', 'GIBRALTAR',
						'GREENLAND', 'GAMBIA', 'GUINEA', 'EQUATORIAL GUINEA', 'GREECE', 'GUATEMALA', 'GUAM', 'GUINEA-BISSAU', 'GUYANA', 'HONG KONG', 'HONDURAS', 'CROATIA',
						'HAITI', 'HUNGARY', 'INDONESIA', 'IRELAND', 'ISRAEL', 'ISLE OF MAN', 'INDIA', 'IRAQ', 'IRAN', 'ICELAND', 'ITALY', 'JAMAICA', 'JORDAN', 'JAPAN',
						'KENYA', 'KYRGYZSTAN', 'CAMBODIA', 'KIRIBATI', 'COMOROS', 'SAINT KITTS AND NEVIS', 'KOREA DEMOCRATIC PEOPLES REPUBLIC OF', 'KOREA REPUBLIC OF',
						'KUWAIT', 'CAYMAN ISLANDS', 'KAZAKSTAN', 'LAO PEOPLES DEMOCRATIC REPUBLIC', 'LEBANON', 'SAINT LUCIA', 'LIECHTENSTEIN', 'SRI LANKA', 'LIBERIA',
						'LESOTHO', 'LITHUANIA', 'LUXEMBOURG', 'LATVIA', 'LIBYAN ARAB JAMAHIRIYA', 'MOROCCO', 'MONACO', 'MOLDOVA', 'MONTENEGRO', 'SAINT MARTIN', 'MADAGASCAR',
						'MARSHALL ISLAND', 'MACEDONIA', 'MALI', 'MYANMAR', 'MONGOLIA', 'MACAU', 'NORTHERN MARIANA ISLANDS', 'MAURITANIA', 'MONTSERRAT', 'MALTA', 'MAURITIUS',
						'MALDIVES', 'MALAWI', 'MEXICO', 'MALAYSIA', 'MOZAMBIQUE', 'NAMIBIA', 'NEW CALEDONIA', 'NIGER', 'NIGERIA', 'NICARAGUA', 'NETHERLANDS', 'NORWAY',
						'NEPAL', 'NAURU', 'NIUE', 'NEW ZEALAND', 'OMAN', 'PANAMA', 'PERU', 'FRENCH POLYNESIA', 'PAPUA NEW GUINEA', 'PHILIPPINES', 'PAKISTAN', 'POLSKA', 
						'SAINT PIERRE AND MIQUELON', 'PITCAIRN', 'PUERTO RICO', 'PORTUGAL', 'PALAU', 'PARAGUAY', 'QATAR', 'ROMANIA', 'SERBIA', 'RUSSIAN FEDERATION',
						'RWANDA', 'SAUDI ARABIA', 'SOLOMON ISLANDS', 'SEYCHELLES', 'SUDAN', 'SWEDEN', 'SINGAPORE', 'SAINT HELENA', 'SLOVENIA', 'SLOVAKIA', 'SIERRA LEONE',
						'SAN MARINO', 'SENEGAL', 'SOMALIA', 'SURINAME', 'SAO TOME AND PRINCIPE', 'EL SALVADOR', 'SYRIAN ARAB REPUBLIC', 'SWAZILAND', 'TURKS AND CAICOS ISLANDS',
						'CHAD', 'TOGO', 'THAILAND', 'TAJIKISTAN', 'TOKELAU', 'TIMOR-LESTE', 'TURKMENISTAN', 'TUNISIA', 'TONGA', 'TURKEY', 'TRINIDAD AND TOBAGO', 'TUVALU',
						'TAIWAN', 'TANZANIA', 'UKRAINE', 'UGANDA', 'UNITED STATES', 'URUGUAY', 'UZBEKISTAN', 'HOLY SEE', 'SAINT VINCENT AND THE GRENADINES', 'VENEZUELA',
						'VIRGIN ISLANDS, BRITISH', 'VIRGIN ISLANDS, U.S.', 'VIETNAM', 'VANUATU', 'WALLIS AND FUTUNA', 'SAMOA', 'KOSOVO', 'YEMEN', 'MAYOTTE', 'SOUTH AFRICA',
						'ZAMBIA', 'ZIMBABWE');
			
			$domyslne = array("Grupy" => $groups,
								"Uzytkownicy" => $users,
								"Kraje" => $kraje,
								"Tabela" => $tabela,
								"Alerty" => $alerty,
								"Modal" => $modals);
			
			Index::$smarty->assign("domyslne", $domyslne);
			Index::$smarty->assign("header", $header);
			
			Index::$smarty->assign("location", 'uzytkownicy.tpl');
		}
		
		function status($data){
			$access = $_SESSION['Dostep'];
			$access = $access[5];
			
			if($access == 2 || $access == 4 || $access == 5){
				$data = explode("|", $data);
				if($data[1] == 0){
					Index::$pdo->query("UPDATE `uzytkownicy` SET `Status` = 1 WHERE `ID` = ".$data[0]);
				} else {
					Index::$pdo->query("UPDATE `uzytkownicy` SET `Status` = 0 WHERE `ID` = ".$data[0]);
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		function edycja($imie, $nazwisko, $email, $kraj, $miasto, $dostep, $pass, $id){
			$access = $_SESSION['Dostep'];
			$access = $access[5];
			
			if($access == 2 || $access == 4 || $access == 5){
				$em = Index::$pdo->query("SELECT `ID` FROM `uzytkownicy` WHERE `Email` = '".$email."'");
				$em = $em->fetch(PDO::FETCH_ASSOC);
				
				if($em['ID'] == $id || $em['ID'] == ""){
					$ile = Index::$pdo->query("SELECT COUNT(*) FROM `uzytkownicy` WHERE `Dostep` = 0");
					$ile = $ile->fetch(PDO::FETCH_ASSOC);
					$ile = $ile['COUNT(*)'];
					
					if(!$this->root_valid() && $dostep != 0){
						$dostep = 0;
						header("Jedyne: 1");
					}
					
					if($pass != ''){
						$haslo_dlugosc = strlen($pass) / 2; #Wyznaczenie połowy wyrazu
						$haslo_1z2 = ceil($haslo_dlugosc); #Wyznaczenie 1 połowy wyrazu(zaokrąglenie)
						$haslo_2z2 = strlen($pass) - $haslo_1z2; #Wyznaczenie 2 połowy wyrazu
						
						$haslo_a = substr($pass, 0, $haslo_1z2); #Przypisanie 1 połowy wyrazu
						$haslo_b = substr($pass, $haslo_1z2, $haslo_2z2); #Przypisanie 2 połowy wyrazu
						
						$haslo_a = sha1($haslo_a); #Hashowanie 1 części hasła
						$haslo_b = sha1($haslo_b); #Hashowanie 2 części hasła
						
						$imie = strip_tags($imie);
						$nazwisko = strip_tags($nazwisko);
						$kraj = strip_tags($kraj);
						$miasto = strip_tags($miasto);
						
						Index::$pdo->query("UPDATE `uzytkownicy` SET `Haslo_a` = '".$haslo_a."',`Haslo_b` = '".$haslo_b."', `Email` = '".$email."',`Imie` = '".$imie."', `Nazwisko` = '".$nazwisko."',`Kraj` = '".$kraj."', `Miasto` = '".$miasto."', `Dostep` = ".$dostep." WHERE `ID` = ".$id);
						
						Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 23, '".$email."|".$_SESSION['Email']."')");
					} else {
						$imie = strip_tags($imie);
						$nazwisko = strip_tags($nazwisko);
						$kraj = strip_tags($kraj);
						$miasto = strip_tags($miasto);
						
						Index::$pdo->query("UPDATE `uzytkownicy` SET `Email` = '".$email."',`Imie` = '".$imie."', `Nazwisko` = '".$nazwisko."',`Kraj` = '".$kraj."', `Miasto` = '".$miasto."', `Dostep` = ".$dostep." WHERE `ID` = ".$id);
						
						Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 22, '".$email."|".$_SESSION['Email']."')");
					}
				} else {
					header("Email: 1");
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		function usuwanie($id){
			$access = $_SESSION['Dostep'];
			$access = $access[5];
			
			if($access == 3 || $access == 5){
				if($this->root_valid($id)){
					$nazwa = Index::$pdo->query("SELECT `Email` FROM `uzytkownicy` WHERE `ID` = ".$id);
					$nazwa = $nazwa->fetch(PDO::FETCH_ASSOC);
					
					Index::$pdo->query("DELETE FROM `uzytkownicy` WHERE `ID` = ".$id);
					Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 24, '".$nazwa['Email']."|".$_SESSION['Email']."')");
				} else {
					header("Jedyne: 1");
					echo "jedyne";
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public function root_valid($id = false){
			$ile = Index::$pdo->query(" SELECT COUNT(*) FROM `uzytkownicy` WHERE `Dostep` = 0");
			$ile = $ile->fetch(PDO::FETCH_ASSOC);
			$ile = $ile['COUNT(*)'];
			
			if($id != false){
				$dst = Index::$pdo->query("SELECT `Dostep` FROM `uzytkownicy` WHERE `ID` = ".$id);
				$dst = $dst->fetch(PDO::FETCH_ASSOC);
				$dst = $dst['Dostep'];
				
				if($dst == 0 && $ile == 1){
					return false;
				} else {
					return true;
				}
			} else {
				if($ile == 1){
					return false;
				} elseif($ile > 1) {
					return true;
				}
			}
		}
	}
?>