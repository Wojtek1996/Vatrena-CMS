<?php
	bukiety::wyswietlanie();
	
	/**
	 * 
	 */
	class bukiety {
		private static $strona_obecna;
		private static $liczba_na_strone = 10;
		public static function wyswietlanie(){
			if(isset($_POST['kosz'])){
				self::kosz($_POST['kosz']);
			}
			
			if(isset($_POST['usuniecie'])){
				self::usuwanie($_POST['usuniecie']);
			}
			
			if(isset($_POST['Przywroc'])){
				$access = $_SESSION['Dostep'];
				$access = $access[0];
			
				if($access == 2 || $access == 4 || $access == 5){
					$access = $_SESSION['Dostep'];
					$access = $access[0];
					
					if($access == 5 || $access == 2 || $access == 4){
						$nazwa = Index::$pdo->query("SELECT `Nazwa` FROM `artykuly` WHERE `ID` = ".$_POST['Przywroc']);
						$nazwa = $nazwa->fetch(PDO::FETCH_ASSOC);
						Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 35, '".$nazwa['Nazwa']."|".$_SESSION['Email']."')");
					} else {
						header("ACCESS_DENIED: 1");
					}
					
					Index::$pdo->query("UPDATE `artykuly` set `Kosz` = 0 WHERE `ID` = ".$_POST['Przywroc']);
				} else {
					header("ACCESS_DENIED: 1");
				}
			}
			
			
			$wszystkie = Index::$pdo->query("SELECT COUNT(*) FROM `artykuly` WHERE `Kosz` = 0");
			$wszystkie = $wszystkie -> fetch();
			$wszystkie = $wszystkie['COUNT(*)'];
			
			$opublikowane = Index::$pdo->query("SELECT COUNT(*) FROM `artykuly` WHERE `Status` = 1 && `Kosz` = 0");
			$opublikowane = $opublikowane->fetch();
			$opublikowane = $opublikowane['COUNT(*)'];
			
			$nieopublikowane = Index::$pdo->query("SELECT COUNT(*) FROM `artykuly` WHERE `Status` = 0 && `Kosz` = 0");
			$nieopublikowane = $nieopublikowane->fetch();
			$nieopublikowane = $nieopublikowane['COUNT(*)'];
			
			$kosz_liczba = Index::$pdo->query("SELECT COUNT(*) FROM `artykuly` WHERE `Kosz` = 1");
			$kosz_liczba = $kosz_liczba->fetch();
			$kosz_liczba = $kosz_liczba['COUNT(*)'];
			
			if(!isset($_POST['Warunek']) || $_POST['Warunek'] == 'all'){
				$warunek_liczba = Index::$pdo->query("SELECT COUNT(*) FROM `artykuly` WHERE `Kosz` = 0");
				$warunek_liczba = $warunek_liczba -> fetch();
				$warunek_liczba = $warunek_liczba['COUNT(*)'];
				self::paginacja($warunek_liczba);
				$query = Index::$pdo->query("SELECT * FROM `artykuly`  WHERE `Kosz` = 0 ORDER BY `ID` DESC LIMIT ".self::$strona_obecna*self::$liczba_na_strone.", ".self::$liczba_na_strone);
			} elseif($_POST['Warunek'] == 'published'){
				$warunek_liczba = Index::$pdo->query("SELECT COUNT(*) FROM `artykuly` WHERE `Kosz` = 0 AND `Status` = 1");
				$warunek_liczba = $warunek_liczba -> fetch();
				$warunek_liczba = $warunek_liczba['COUNT(*)'];
				self::paginacja($warunek_liczba);
				$query = Index::$pdo->query("SELECT * FROM `artykuly` WHERE `Status` = 1 && `Kosz` = 0 ORDER BY `ID` DESC LIMIT ".self::$strona_obecna*self::$liczba_na_strone.", ".self::$liczba_na_strone);
			} elseif($_POST['Warunek'] == 'unpublished'){
				$warunek_liczba = Index::$pdo->query("SELECT COUNT(*) FROM `artykuly` WHERE `Kosz` = 0 AND `Status` = 0");
				$warunek_liczba = $warunek_liczba -> fetch();
				$warunek_liczba = $warunek_liczba['COUNT(*)'];
				self::paginacja($warunek_liczba);
				$query = Index::$pdo->query("SELECT * FROM `artykuly` WHERE `Status` = 0 && `Kosz` = 0 ORDER BY `ID` DESC LIMIT ".self::$strona_obecna*self::$liczba_na_strone.", ".self::$liczba_na_strone);
			} elseif($_POST['Warunek'] == 'trash'){
				$warunek_liczba = Index::$pdo->query("SELECT COUNT(*) FROM `artykuly` WHERE `Kosz` = 1");
				$warunek_liczba = $warunek_liczba -> fetch();
				$warunek_liczba = $warunek_liczba['COUNT(*)'];
				self::paginacja($warunek_liczba);
				$query = Index::$pdo->query("SELECT * FROM `artykuly` WHERE `Kosz` = 1 ORDER BY `ID` DESC LIMIT ".self::$strona_obecna*self::$liczba_na_strone.", ".self::$liczba_na_strone);
			}
			
			$newsy = $query->fetchall(PDO::FETCH_ASSOC);
			
			$query = Index::$pdo->query("SELECT * FROM `kategorie` ORDER BY `ID`");
			$query = $query->fetchall(PDO::FETCH_ASSOC);
			
			$kategorie = array();
			
			foreach($query as $item){
				$kategorie[$item['ID']] = $item['Nazwa'];
			}
			
			if(isset($_POST['aktywuj'])){
				$access = $_SESSION['Dostep'];
				$access = $access[0];
				
				if($access == 5 || $access == 2 || $access == 4){
					$string = explode("|", $_POST['aktywuj']);
					
					Index::$pdo->query("UPDATE `artykuly` SET `Status` = ".$string[1]." WHERE `ID` = ".$string[0]);
					
					$nazwa = Index::$pdo->query("SELECT `Nazwa` FROM `artykuly` WHERE `ID` = ".$string[0]);
					$nazwa = $nazwa->fetch(PDO::FETCH_ASSOC);
					Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 3, '".$nazwa['Nazwa']."|".$_SESSION['Email']."')");
				} else {
					header("ACCESS_DENIED: 1");
				}
			}
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$header = array("Przegląd treści", "search");
				$top_buttons = array("Wszystkie", $wszystkie, "Opublikowane", $opublikowane, "Nieopublikowane", $nieopublikowane, "W koszu", $kosz_liczba, "Szukaj");
				$table_text = array("ID", "Tytuł", "Kategorie", "Język", "Autor", "Data", "Publikacja");
				if(isset($_POST['Warunek']) && $_POST['Warunek'] == 'trash'){
					$btns = array("Przywróć", "reply", "Usuń", "trash-o");
				} else {
					$btns = array("Edytuj", "pencil", "Przenieś do kosza", "trash-o");
				}
				$del_info = array("Uwaga", "Czy napewno chcesz usunąć element?", "Usuń", "Anuluj");
			} elseif($_SESSION['jezyk'] == 'EN'){
				$header = array("Composition list", "search");
				$top_buttons = array("All", $wszystkie, "Published", $opublikowane, "Not published", $nieopublikowane, "In trash", $kosz_liczba, "Search");
				$table_text = array("ID", "Title", "Category", "Language", "Author", "Date", "Published");
				if(isset($_POST['Warunek']) && $_POST['Warunek'] == 'trash'){
					$btns = array("Restore", "reply", "Delete", "trash-o");
				} else {
					$btns = array("Edit", "pencil", "Move to trash", "trash-o");
				}
				$del_info = array("Uwaga", "Czy napewno chcesz usunąć element?", "Usuń", "Anuluj");
				} elseif($_SESSION['jezyk'] == 'DE'){
				$header = array("Przegląd kompozycji", "search");
				$top_buttons = array("Wszystkie", $wszystkie, "Opublikowane", $opublikowane, "Nieopublikowane", $nieopublikowane, "W koszu", $kosz_liczba, "Szukaj");
				$table_text = array("ID", "Tytuł", "Kategorie", "ID", "Autor", "Data");
				if(isset($_POST['Warunek']) && $_POST['Warunek'] == 'trash'){
					$btns = array("Przywróć", "reply", "Usuń", "trash-o");
				} else {
					$btns = array("Edytuj", "pencil", "Przenieś do kosza", "trash-o");
				}
				$del_info = array("Uwaga", "Czy napewno chcesz usunąć element?", "Usuń", "Anuluj");
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$header = array("Przegląd kompozycji", "search");
				$top_buttons = array("Wszystkie", $wszystkie, "Opublikowane", $opublikowane, "Nieopublikowane", $nieopublikowane, "W koszu", $kosz_liczba, "Szukaj");
				$table_text = array("ID", "Tytuł", "Kategorie", "Język", "Autor", "Data");
				if(isset($_POST['Warunek']) && $_POST['Warunek'] == 'trash'){
					$btns = array("Przywróć", "reply", "Usuń", "trash-o");
				} else {
					$btns = array("Edytuj", "pencil", "Przenieś do kosza", "trash-o");
				}
				$del_info = array("Uwaga", "Czy napewno chcesz usunąć element?", "Usuń", "Anuluj");
			}
			
			$news_default = array("usuwanie" => $del_info,
									"przyciski" => $btns,
									"table_text" => $table_text,
									"top_buttons" => $top_buttons,
									"header" => $header,
									"kategorie" => $kategorie,
									"newsy" => $newsy);
			
			Index::$smarty->assign("news_default", $news_default);
			
			Index::$smarty->assign('location', 'news.tpl');
		}
		
		public static function kosz($kosz){
			$access = $_SESSION['Dostep'];
			$access = $access[0];
			
			if($access == 5 || $access == 2 || $access == 4){
				Index::$pdo->query("UPDATE `artykuly` set `Kosz` = 1 WHERE `ID` = ".$kosz);
				
				$nazwa = Index::$pdo->query("SELECT `Nazwa` FROM `artykuly` WHERE `ID` = ".$kosz);
				$nazwa = $nazwa->fetch(PDO::FETCH_ASSOC);
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 34, '".$nazwa['Nazwa']."|".$_SESSION['Email']."')");
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
		
		public static function usuwanie($del){
			$access = $_SESSION['Dostep'];
			$access = $access[0];
			
			if($access == 5 || $access == 3){
				$nazwa = Index::$pdo->query("SELECT `Nazwa` FROM `artykuly` WHERE `ID` = ".$del);
				$nazwa = $nazwa->fetch(PDO::FETCH_ASSOC);
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 4, '".$nazwa['Nazwa']."|".$_SESSION['Email']."')");
				
				Index::$pdo->query("DELETE FROM `artykuly` WHERE `ID` = ".$del);
				
				$query = Index::$pdo->query("SELECT `ID` FROM `menu` WHERE `Artykul` = ".$del);
				
				foreach($query as $item){
					Index::$pdo->query("UPDATE `menu` set `Artykul` = '', `Typ` = 0 WHERE `ID` = ".$item['ID']);
				}
			} else {
				header("ACCESS_DENIED: 1");
			}
		}

		public static function paginacja($liczba){
			if(!isset($_POST['strona'])){
				self::$strona_obecna = 0;
			} else {
				self::$strona_obecna = $_POST['strona'];
			}
			
			$liczba_stron = ceil($liczba/self::$liczba_na_strone);
			
			Index::$smarty->assign("ostatnia", $liczba_stron - 1);
			Index::$smarty->assign("obecna", self::$strona_obecna);
			Index::$smarty->assign("paginacja", $liczba_stron);
		}
	}
?>