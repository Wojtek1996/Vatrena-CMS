<?php
	general::przekaz();
	
	class general{
		
		public static function przekaz(){
			$stats = Index::$pdo->query("SELECT * FROM `statystyki`");
			$stats = $stats -> fetchall();

			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$stat = array("Odwiedzin dzisiaj|".$stats[0]['Wartosc'] => "fa-signal", "Odwiedzin w tym tygodniu|".$stats[1]['Wartosc'] => "fa-list-alt", "Odwiedzin w tym miesiącu|".$stats[2]['Wartosc'] => "fa-calendar",
								"Łączna suma odwiedzin|".$stats[3]['Wartosc'] => "fa-bar-chart-o");
				$charts = array($stats[4]['Wartosc'], $stats[5]['Wartosc'], $stats[6]['Wartosc'], $stats[7]['Wartosc'], $stats[8]['Wartosc'], $stats[9]['Wartosc']);
				$legenda = array("Firefox" => "ff", "Chrome" => "chr", "Safari" => "sfi", "Opera" => "op", "IE" => "ie", "Inne" => "inne");
				$miesiac_stats = array($stats[10]['Wartosc'], $stats[11]['Wartosc'], $stats[12]['Wartosc'], $stats[13]['Wartosc'],
										$stats[14]['Wartosc'], $stats[15]['Wartosc'], $stats[16]['Wartosc'], $stats[17]['Wartosc'], $stats[18]['Wartosc'], $stats[19]['Wartosc'],
										$stats[20]['Wartosc'], $stats[21]['Wartosc']);
				$header = array("Strona główna", "tachometer");
				$teksty = array("Odwiedziny według miesięcy (ostatni rok)", "Odwiedziny według przeglądarek");
			} elseif($_SESSION['jezyk'] == 'EN'){
				$stat = array("Visits today|".$stats[0]['Wartosc'] => "fa-signal", "Visits in this week|".$stats[1]['Wartosc'] => "fa-list-alt", "Visits in this month|".$stats[2]['Wartosc'] => "fa-calendar",
								"All visits|".$stats[3]['Wartosc'] => "fa-bar-chart-o");
				$charts = array($stats[4]['Wartosc'], $stats[5]['Wartosc'], $stats[6]['Wartosc'], $stats[7]['Wartosc'], $stats[8]['Wartosc'], $stats[9]['Wartosc']);
				$legenda = array("Firefox" => "ff", "Chrome" => "chr", "Safari" => "sfi", "Opera" => "op", "IE" => "ie", "Inne" => "inne");
				$miesiac_stats = array($stats[10]['Wartosc'], $stats[11]['Wartosc'], $stats[12]['Wartosc'], $stats[13]['Wartosc'],
										$stats[14]['Wartosc'], $stats[15]['Wartosc'], $stats[16]['Wartosc'], $stats[17]['Wartosc'], $stats[18]['Wartosc'], $stats[19]['Wartosc'],
										$stats[20]['Wartosc'], $stats[21]['Wartosc']);
				$header = array("Homepage", "tachometer");
				$teksty = array("Visits by month (last year)", "Visits by browsers");
			} elseif($_SESSION['jezyk'] == 'DE'){
				$stat = array("Odwiedzin dzisiaj|".$stats[0]['Wartosc'] => "fa-signal", "Odwiedzin w tym tygodniu|".$stats[1]['Wartosc'] => "fa-list-alt", "Odwiedzin w tym miesiącu|".$stats[2]['Wartosc'] => "fa-calendar",
								"Łączna suma odwiedzin|".$stats[3]['Wartosc'] => "fa-bar-chart-o");
				$charts = array($stats[4]['Wartosc'], $stats[5]['Wartosc'], $stats[6]['Wartosc'], $stats[7]['Wartosc'], $stats[8]['Wartosc'], $stats[9]['Wartosc']);
				$legenda = array("Firefox" => "ff", "Chrome" => "chr", "Safari" => "sfi", "Opera" => "op", "IE" => "ie", "Inne" => "inne");
				$miesiac_stats = array($stats[10]['Wartosc'], $stats[11]['Wartosc'], $stats[12]['Wartosc'], $stats[13]['Wartosc'],
										$stats[14]['Wartosc'], $stats[15]['Wartosc'], $stats[16]['Wartosc'], $stats[17]['Wartosc'], $stats[18]['Wartosc'], $stats[19]['Wartosc'],
										$stats[20]['Wartosc'], $stats[21]['Wartosc']);
				$header = array("Strona główna", "tachometer");
				$teksty = array("Odwiedziny według miesięcy (ostatni rok)", "Odwiedziny według przeglądarek");
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$stat = array("Odwiedzin dzisiaj|".$stats[0]['Wartosc'] => "fa-signal", "Odwiedzin w tym tygodniu|".$stats[1]['Wartosc'] => "fa-list-alt", "Odwiedzin w tym miesiącu|".$stats[2]['Wartosc'] => "fa-calendar",
								"Łączna suma odwiedzin|".$stats[3]['Wartosc'] => "fa-bar-chart-o");
				$charts = array($stats[4]['Wartosc'], $stats[5]['Wartosc'], $stats[6]['Wartosc'], $stats[7]['Wartosc'], $stats[8]['Wartosc'], $stats[9]['Wartosc']);
				$legenda = array("Firefox" => "ff", "Chrome" => "chr", "Safari" => "sfi", "Opera" => "op", "IE" => "ie", "Inne" => "inne");
				$miesiac_stats = array($stats[10]['Wartosc'], $stats[11]['Wartosc'], $stats[12]['Wartosc'], $stats[13]['Wartosc'],
										$stats[14]['Wartosc'], $stats[15]['Wartosc'], $stats[16]['Wartosc'], $stats[17]['Wartosc'], $stats[18]['Wartosc'], $stats[19]['Wartosc'],
										$stats[20]['Wartosc'], $stats[21]['Wartosc']);
				$header = array("Strona główna", "tachometer");
				$teksty = array("Odwiedziny według miesięcy (ostatni rok)", "Odwiedziny według przeglądarek");
			}
			
			$general_domyslne = array("Teksty" => $teksty,
										"Header" => $header,
										"Miesiac_stats" => $miesiac_stats,
										"Legenda" => $legenda,
										"Stats" => $stat,
										"Chart" => $charts);
			
			Index::$smarty->assign("general_domyslne", $general_domyslne);
			
			Index::$smarty->assign('location', 'general.tpl');
		}
	}
?>