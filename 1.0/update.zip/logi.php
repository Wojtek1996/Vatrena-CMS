<?php
	$logi = new Logi();
	
	/**
	 * Kody
	 * 0 - Login (pomyślny)
	 * 1 - Login (Błąd)
	 * 2 - Dodanie kompozycji
	 * 3 - Zmiana statusu kompozycji
	 * 4 - Usunięcie kompozycji
	 * 5 - Edycja kompozycji
	 * 6 - Dodanie kategorii
	 * 7 - Zmiana statusu kategorii
	 * 8 - Usunięcie kategorii
	 * 9 - Dodawanie menu
	 * 10 - Usuwanie menu
	 * 11 - Utworzenie pliku
	 * 12 - Utworzenie folderu
	 * 13 - Przesłanie pliku
	 * 14 - Zmiana uprawnień
	 * 15 - Usunięcie pliku
	 * 16 - Zapis konfiguracji systemu
	 * 17 - Zapis konfiguracji strony
	 * 18 - Zapis konfiguracji slidera
	 * 19 - Dodanie slajdu
	 * 20 - Usunięcie slajdu
	 * 21 - Dodanie użytkownika
	 * 22 - Edycja (bez zmiany hasła) konta użytkownika
	 * 23 - Edycja (ze zmianą hasła) konta użytkownika
	 * 24 - Usunięcie użytkownika
	 * 25 - Dodanie grupy dostępu
	 * 26 - Edycja grupy dostępu
	 * 27 - Usunięcie grupy dostępu
	 * 28 - Wykasowanie logów
	 * 29 - Zmiana statusu pozycji menu
	 * 30 - zmiana strony startowej
	 * 31 - Zmiana typu pozycji menu
	 * 32 - Zmiana zawartości pliku
	 * 33 - Wylogowanie
	 * 34 - Przeniesienie newa do kosza
	 * 35 - Przywrócenie newsa z kosza
	 * 36 - Zmiana nazwy kategorii
	 * 37 - Edycja kategorii menu
	 * 38 - Zmiana nazwy pliku/folderu
	 * 39 - Zmaina swoich danych
	 * 40 - Zmiana swoich danych i hasła
	 */
	class Logi {
		private static $strona_obecna;
		private static $liczba_na_strone = 20;
		function __construct() {
			if(isset($_POST['clear'])){
				$this->usuwanie();
			}
			
			Index::$smarty->assign("location", "logi.tpl");
			
			$header = array("Logi", "book");
			
			$wszystkie = Index::$pdo->query("SELECT COUNT(*) FROM `logi`");
			$wszystkie = $wszystkie -> fetch();
			$wszystkie = $wszystkie['COUNT(*)'];
			
			self::paginacja($wszystkie);
			
			$query = Index::$pdo->query("SELECT * FROM `logi` ORDER BY `ID` DESC LIMIT ".self::$strona_obecna*self::$liczba_na_strone.", ".self::$liczba_na_strone);
			$query = $query->fetchAll();
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$kody = array(0 => "Pomyślnie zalogowano użytkownika o emailu", 1 => "Błąd podczas logowania", "Else" => "Nieznany kod błędu",
							2 => array("Kompozycja", "została dodana przez użytkownika"), 3 => array("Status kompozycji", "został zmieniony przez użytkownika"),
							4 => array("Kompozycja", "została usunięta przez użytkownika"), 5 => array("Kompozycja", "została zmieniona przez użytkownika"),
							6 => array("Kategoria", "została dodana przez użytkownika"), 7 => array("Status kategorii", "został zmienony przez użytkownika"),
							8 => array("Kategoria", "została usunięta przez użytkownika"), 9 => array("Pozycja menu", "została utworzona przez użytkownika"),
							10 => array("Pozycja menu", "została usunięta przez użytkownika"), 11 => array("Plik", "został utworzony przez użytkownika"),
							12 => array("Folder", "został utworzony przez użytkownika"), 13 => array("Plik", "został przesłany na serwer przez użytkownika"),
							14 => array("Uprawnienia pliku", "Zostały zmienione przez użytkownika"), 15 => array("Plik", "został usunięty przez użytkownika"),
							16 => "Konfiguracja systemu została zmieniona przez użytkownika", 17 => "Konfiguracja strony została zmieniona przez użytkownika",
							18 => "Konfiguracja slidera została zmienona przez użytkownika", 19 => array("Slajd", "został dodany przez użytkownika"),
							20 => array("Slajd", "został usunięty przez użytkownika"), 21 => array("Użytkownik", "został dodany przez użytkownika"),
							22 => array("Dane użytkownika", "zostały zmienione przez użytkownika"), 23 => array("Hasło oraz dane uzytkownika", "zostały zmienione przez użytkownika"),
							24 => array("Konto użytkownika", "zostało usunięte przez użytkownika"), 25 => array("Grupa dostępu", "została stworzona przez użytkownika"),
							26 => array("Dane grupy dostępu", "zostały zmienione przez uzytkownika"), 27 => array("Grupa dostępu", "została usunięta przez użytkownika"),
							28 => "Logi zostały wyczyszczone przez użytkownika", 29 => array("Status pozycji menu", "został zmienony przez użytkownika"),
							30 => array("Pozycja menu", "została ustawiona jako strona domowa przez użytkownika"),
							31 => array("Typ pozycji menu", "został zmieniony przez użytkownika"),
							32 => array("Zawartość pliku", "została zmieniona przez użytkownika"), 33 => "Wylogowano użytkownika",
							34 => array("Kompozycja", "została przeniesiona do kosza przez użytkownika"),
							35 => array("Kompozycja", "została przywrócona z kosza przez użytkownika"),
							36 => array("Nazwa kompozycji", "została zmieniona przez użytkownika"),
							37 => array("Pozycja menu", "została zmieniona przez użytkownika"),
							38 => array("Nazwa folderu/pliku", "została zmieniona przez uzytkownika"),
							39 => array("Użytkownik", "zmienił swoje dane"),
							40 => array("Użytkownik", "zmienił swoje dane oraz hasło"));
				$modal = array("Uwaga", "Czy jesteś pewien że chcesz usunąć logi?", "Usuń", "Anuluj");
				$tabela = array("Treść", "Data", "Wyczyść logi");
			} elseif($_SESSION['jezyk'] == 'EN'){
				$kody = array(0 => "Succesfullu loged user with email", 1 => "Error when logging", "Else" => "Undefined error code",
							2 => array("Composition", "została dodana przez użytkownika"), 3 => array("Composition status", "has been changed by user with email"),
							4 => array("Composition", "została usunięta przez użytkownika"), 5 => array("Composition", "has been changed by user with email"),
							6 => array("Category", "has been added by the user with email"), 7 => array("Category status", "has beed changed by user with email"),
							8 => array("Category", "has been deleted by the user with email"), 9 => array("Menu position", "has been created by the user with email"),
							10 => array("Menu position", "has been deleted by user with email"), 11 => array("File", "has been created by user with email"),
							12 => array("Folder", "has been created by user with email"), 13 => array("Plik", "has been sended to server by user with email"),
							14 => array("Uprawnienia pliku", "has been changed by user with email"), 15 => array("Plik", "has been removed by user with email"),
							16 => "System configuration has been changed by user with email", 17 => "Page configuration has been changed by user with email",
							18 => "Slider configuration has been changed by user with email", 19 => array("Slide", "has been added by user with the email"),
							20 => array("Slide", "has been removed by user with email"), 21 => array("User", "has been added by user with email"),
							22 => array("User", " data has been changed by user with email"), 23 => array("Password and data of user", "has been changed by user with email"),
							24 => array("User account", "has been deleted by user with email"), 25 => array("Access group", "has been created by user with email"),
							26 => array("Data of access group", "has been changed by user with email"), 27 => array("Access group", "has been removed by user with email"),
							28 => "Logs has been cleared by user with email", 29 => array("Status of menu position", "has been changed by user with email"),
							30 => array("Menu position", "has been selected as homepage by user with email"),
							31 => array("Type of menu position", "has been changed by user with email"),
							32 => array("Content of file", "has been edited by user with email"), 33 => "Logged out user with email",
							34 => array("Composition", "has been moved to trash by user with email"),
							35 => array("Composition", "has been restored from trash by user with email"),
							36 => array("Name of compostion", "has been changed by user with email"),
							37 => array("Menu position", "has been changed by user with email"),
							38 => array("Name of file/folder", "has been changed by user with email"),
							39 => array("User", "has changed its data"),
							40 => array("User", "has changed its data and password"));
				$modal = array("Attention", "Are you sure you want to remove logs?", "Remove", "Cancel");
				$tabela = array("Content", "Date", "Clear logs");
			} elseif($_SESSION['jezyk'] == 'DE'){
				$kody = array(0 => "Pomyślnie zalogowano użytkownika o emailu", 1 => "Błąd podczas logowania", "Else" => "Nieznany kod błędu",
							2 => array("Kompozycja", "została dodana przez użytkownika"), 3 => array("Status kompozycji", "został zmieniony przez użytkownika"),
							4 => array("Kompozycja", "została usunięta przez użytkownika"), 5 => array("Kompozycja", "została zmieniona przez użytkownika"),
							6 => array("Kategoria", "została dodana przez użytkownika"), 7 => array("Status kategorii", "został zmienony przez użytkownika"),
							8 => array("Kategoria", "została usunięta przez użytkownika"), 9 => array("Pozycja menu", "została utworzona przez użytkownika"),
							10 => array("Pozycja menu", "została usunięta przez użytkownika"), 11 => array("Plik", "został utworzony przez użytkownika"),
							12 => array("Folder", "został utworzony przez użytkownika"), 13 => array("Plik", "został przesłany na serwer przez użytkownika"),
							14 => array("Uprawnienia pliku", "Zostały zmienione przez użytkownika"), 15 => array("Plik", "został usunięty przez użytkownika"),
							16 => "Konfiguracja systemu została zmieniona przez użytkownika", 17 => "Konfiguracja strony została zmieniona przez użytkownika",
							18 => "Konfiguracja slidera została zmienona przez użytkownika", 19 => array("Slajd", "został dodany przez użytkownika"),
							20 => array("Slajd", "został usunięty przez użytkownika"), 21 => array("Użytkownik", "został dodany przez użytkownika"),
							22 => array("Dane użytkownika", "zostały zmienione przez użytkownika"), 23 => array("Hasło oraz dane uzytkownika", "zostały zmienione przez użytkownika"),
							24 => array("Konto użytkownika", "zostało usunięte przez użytkownika"), 25 => array("Grupa dostępu", "została stworzona przez użytkownika"),
							26 => array("Dane grupy dostępu", "zostały zmienione przez uzytkownika"), 27 => array("Grupa dostępu", "została usunięta przez użytkownika"),
							28 => "Logi zostały wyczyszczone przez użytkownika", 29 => array("Status pozycji menu", "został zmienony przez użytkownika"),
							30 => array("Pozycja menu", "została ustawiona jako strona domowa przez użytkownika"),
							31 => array("Typ pozycji menu", "został zmieniony przez użytkownika"),
							32 => array("Zawartość pliku", "została zmieniona przez użytkownika"), 33 => "Wylogowano użytkownika",
							34 => array("Kompozycja", "została przeniesiona do kosza przez użytkownika"),
							35 => array("Kompozycja", "została przywrócona z kosza przez użytkownika"),
							36 => array("Nazwa kompozycji", "została zmieniona przez użytkownika"),
							37 => array("Pozycja menu", "została zmieniona przez użytkownika"),
							38 => array("Nazwa folderu/pliku", "została zmieniona przez uzytkownika"),
							39 => array("Użytkownik", "zmienił swoje dane"),
							40 => array("Użytkownik", "zmienił swoje dane oraz hasło"));
				$modal = array("Uwaga", "Czy jesteś pewien że chcesz usunąć logi?", "Usuń", "Anuluj");
				$tabela = array("Treść", "Data", "Wyczyść logi");
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$kody = array(0 => "Pomyślnie zalogowano użytkownika o emailu", 1 => "Błąd podczas logowania", "Else" => "Nieznany kod błędu",
							2 => array("Kompozycja", "została dodana przez użytkownika"), 3 => array("Status kompozycji", "został zmieniony przez użytkownika"),
							4 => array("Kompozycja", "została usunięta przez użytkownika"), 5 => array("Kompozycja", "została zmieniona przez użytkownika"),
							6 => array("Kategoria", "została dodana przez użytkownika"), 7 => array("Status kategorii", "został zmienony przez użytkownika"),
							8 => array("Kategoria", "została usunięta przez użytkownika"), 9 => array("Pozycja menu", "została utworzona przez użytkownika"),
							10 => array("Pozycja menu", "została usunięta przez użytkownika"), 11 => array("Plik", "został utworzony przez użytkownika"),
							12 => array("Folder", "został utworzony przez użytkownika"), 13 => array("Plik", "został przesłany na serwer przez użytkownika"),
							14 => array("Uprawnienia pliku", "Zostały zmienione przez użytkownika"), 15 => array("Plik", "został usunięty przez użytkownika"),
							16 => "Konfiguracja systemu została zmieniona przez użytkownika", 17 => "Konfiguracja strony została zmieniona przez użytkownika",
							18 => "Konfiguracja slidera została zmienona przez użytkownika", 19 => array("Slajd", "został dodany przez użytkownika"),
							20 => array("Slajd", "został usunięty przez użytkownika"), 21 => array("Użytkownik", "został dodany przez użytkownika"),
							22 => array("Dane użytkownika", "zostały zmienione przez użytkownika"), 23 => array("Hasło oraz dane uzytkownika", "zostały zmienione przez użytkownika"),
							24 => array("Konto użytkownika", "zostało usunięte przez użytkownika"), 25 => array("Grupa dostępu", "została stworzona przez użytkownika"),
							26 => array("Dane grupy dostępu", "zostały zmienione przez uzytkownika"), 27 => array("Grupa dostępu", "została usunięta przez użytkownika"),
							28 => "Logi zostały wyczyszczone przez użytkownika", 29 => array("Status pozycji menu", "został zmienony przez użytkownika"),
							30 => array("Pozycja menu", "została ustawiona jako strona domowa przez użytkownika"),
							31 => array("Typ pozycji menu", "został zmieniony przez użytkownika"),
							32 => array("Zawartość pliku", "została zmieniona przez użytkownika"), 33 => "Wylogowano użytkownika",
							34 => array("Kompozycja", "została przeniesiona do kosza przez użytkownika"),
							35 => array("Kompozycja", "została przywrócona z kosza przez użytkownika"),
							36 => array("Nazwa kompozycji", "została zmieniona przez użytkownika"),
							37 => array("Pozycja menu", "została zmieniona przez użytkownika"),
							38 => array("Nazwa folderu/pliku", "została zmieniona przez uzytkownika"),
							39 => array("Użytkownik", "zmienił swoje dane"),
							40 => array("Użytkownik", "zmienił swoje dane oraz hasło"));
				$modal = array("Uwaga", "Czy jesteś pewien że chcesz usunąć logi?", "Usuń", "Anuluj");
				$tabela = array("Treść", "Data", "Wyczyść logi");
			}
			
			$domyslne = array("Header" => $header,
								"Logi" => $query,
								"Kody" => $kody,
								"Modal" => $modal,
								"Tabela" => $tabela);
			
			Index::$smarty->assign("domyslne", $domyslne);
		}
		
		public function paginacja($liczba){
			if(!isset($_POST['strona'])){
				self::$strona_obecna = 0;
			} else {
				self::$strona_obecna = $_POST['strona'];
			}
			
			$liczba_stron = ceil($liczba/self::$liczba_na_strone);
			
			Index::$smarty->assign("ostatnia", $liczba_stron - 1);
			Index::$smarty->assign("obecna", self::$strona_obecna);
			Index::$smarty->assign("paginacja", $liczba_stron);
		}
		
		public function usuwanie(){
			$access = $_SESSION['Dostep'];
			$access = $access[7];
			
			if($access == 5){
				Index::$pdo->query("DELETE FROM `logi`");
				
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 28, '".$_SESSION['Email']."')");
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
	}
	
?>