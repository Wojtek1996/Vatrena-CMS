<?php
	if(isset($_POST['action']) && $_POST['action'] == 'read'){
		$sciezka = $_POST['value'];
		$fp = fopen($sciezka, "r");
		if(filesize($sciezka) <= 0){
			echo "";
		} else {
			$dane = fread($fp, filesize($sciezka));
			echo($dane);
		}
		
		fclose($fp);
	}elseif(isset($_POST['action']) && $_POST['action'] == 'save'){
		$fp = fopen($_POST['sciezka'], "w");
		
		fputs($fp, $_POST['zapisz']);
		
		fclose($fp);
	}
?>