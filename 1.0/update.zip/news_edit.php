<?php
	$news_edit = new News_edit();
	
	/**
	 * 
	 */
	class News_edit {
		
		function __construct() {
			if(isset($_POST['edit_nazwa'])){
				if(!isset($_POST['edit_lang'])){
					$lng = "";
				} else {
					$lng = $_POST['edit_lang'];
				}
				$this->zapis($_POST['edit_id'], $_POST['edit_nazwa'], $_POST['edit_url'], $_POST['edit_opis'], $_POST['edit_data'], $_POST['edit_status'], $_POST['edit_kategoria'], $_POST['edit_tagi'], $lng);
			}
			
			Index::$smarty->assign("location", "news_edit.tpl");
			
			$query = Index::$pdo->query("SELECT * FROM `artykuly` WHERE `ID` = ".$_GET['edit_id']);
			$query = $query->fetch(PDO::FETCH_ASSOC);
			
			if(!isset($_SESSION['jezyk']) || $_SESSION['jezyk'] == 'PL'){
				$header = array("Edycja kompozycji", "edit");
				$status = array("Opublikowany" => 1, "Niepublikowany" => 0);
				$teksty = array("Tytuł", "Url", "Data publikacji", "Status", "Kategoria", "Własne ID", "Zapisz", "Anuluj", "Języki", "Polski", "Angielski", "Niemiecki", "Włoski");
				$jezyk = "pl";
				$warning = array("Bład", "Brak kompozycji o podanym ID", "Zamknij");
			} elseif($_SESSION['jezyk'] == 'EN'){
				$header = array("Edit composition", "edit");
				$status = array("Published" => 1, "Not published" => 0);
				$teksty = array("Title", "Url", "Publication date", "Status", "Category", "Custom ID", "Save", "Cancel", "Languages", "Polish", "English", "German", "Italian");
				$jezyk = "en";
				$warning = array("Error", "No composition with entered ID.", "Close");
			} elseif($_SESSION['jezyk'] == 'DE'){
				$header = array("Edycja kompozycji", "edit");
				$status = array("Opublikowany" => 1, "Niepublikowany" => 0);
				$teksty = array("Tytuł", "Url", "Data publikacji", "Status", "Kategoria", "Własne ID", "Zapisz", "Anuluj", "Języki", "Polski", "Angielski", "Niemiecki", "Włoski");
				$jezyk = "pl";
				$warning = array("Bład", "Brak kompozycji o podanym ID", "Zamknij");
			} elseif($_SESSION['jezyk'] == 'ITA'){
				$header = array("Edycja kompozycji", "edit");
				$status = array("Opublikowany" => 1, "Niepublikowany" => 0);
				$teksty = array("Tytuł", "Url", "Data publikacji", "Status", "Kategoria", "Własne ID", "Zapisz", "Anuluj", "Języki", "Polski", "Angielski", "Niemiecki", "Włoski");
				$jezyk = "pl";
				$warning = array("Bład", "Brak kompozycji o podanym ID", "Zamknij");
			}
			
			$kategorie_query = Index::$pdo->query("SELECT `ID`, `Nazwa` FROM `kategorie`");
			$kategorie_query = $kategorie_query->fetchAll(PDO::FETCH_ASSOC);
			$kategorie = array();
			
			foreach($kategorie_query as $item){
				$kategorie[$item['Nazwa']] = $item['ID'];
			}
			
			$domyslne = array("Header" => $header,
								"Status" => $status,
								"Kategorie" => $kategorie,
								"Wartosci" => $query,
								"Teksty" => $teksty,
								"Jezyk" => $jezyk,
								"Warning" => $warning);
			
			Index::$smarty->assign("domyslne", $domyslne);
		}
		
		public function zapis($id, $tytul, $url, $opis, $data, $status, $kategoria, $tagi, $lang){
			$access = $_SESSION['Dostep'];
			$access = $access[0];
			
			if($access == 2 || $access == 4 || $access == 5){
				$tytul = strip_tags($tytul);
				$url = strip_tags($url);
				$kategoria = strip_tags($kategoria);
				$tagi = strip_tags($tagi);
				$status = strip_tags($status);
				$data = strip_tags($data);
				$imie = strip_tags($_SESSION['Imie']);
				
				if($lang != ""){
					$i = 0;
					$jezyk = "";
					$len = count($lang);
					foreach($lang as $item){
						if($i == $len - 1){
							$jezyk .= $item;
						} else {
							$jezyk .= $item."|";
						}
						
						++$i;
					}
				} else {
					$jezyk = "PL";
				}
				
				$statement = Index::$pdo->prepare("UPDATE `artykuly` SET `Nazwa` = ?, `Obrazek` = ?, `Opis` = ?, `Kategoria` = ?,`Tagi` = ?, `Status` = ?, `Data_publikacji` = ?, `Autor` = ?, `jezyk` = ? WHERE `ID` = ".$id);
				
				$statement->bindParam(1, $tytul, PDO::PARAM_STR);
				$statement->bindParam(2, $url, PDO::PARAM_STR);
				$statement->bindParam(3, $opis, PDO::PARAM_STR);
				$statement->bindParam(4, $kategoria, PDO::PARAM_STR);
				$statement->bindParam(5, $tagi, PDO::PARAM_STR);
				$statement->bindParam(6, $status, PDO::PARAM_INT);
				$statement->bindParam(7, $data, PDO::PARAM_STR);
				$statement->bindParam(8, $imie, PDO::PARAM_STR);
				$statement->bindParam(9, $jezyk, PDO::PARAM_STR);
				$statement->execute();
				
				Index::$pdo->query("INSERT INTO `logi`(`ID`, `Data`, `Kod`, `Zawartosc_dodatkowa`) VALUES (null, '".Index::$time."', 5, '".$tytul."|".$_SESSION['Email']."')");
			} else {
				header("ACCESS_DENIED: 1");
			}
		}
	}
?>